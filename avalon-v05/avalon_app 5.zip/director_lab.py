"""Isolated v0.8 director lab. Does not mutate the Match/canonical rule engine.

The director sees PUBLIC material only. Each actor receives a strict per-seat
private information slice. Plans never contain role names, secret facts or votes.
"""
from __future__ import annotations
from dataclasses import dataclass,field
from typing import Any
import json,os,re,secrets,time

LAB_MODEL_ENV='AVALON_DIRECTOR_MODEL'
DEFAULT_MODEL='gpt-4.1'
HUMAN=3
PUBLIC_FACTS={
 'mission_1':{'round':1,'team':[1,4],'fail_cards':1,'result':'失敗'},
 'mission_2':{'round':2,'team':[2,3,5],'fail_cards':0,'result':'成功'},
 'recent_proposals':[
  {'round':3,'attempt':1,'captain':4,'team':[3,4,6], 'votes':{'1':'no','2':'no','3':'no','4':'no','5':'yes','6':'no','7':'yes'},'passed':False},
  {'round':3,'attempt':2,'captain':5,'team':[2,3,5],'votes':None,'passed':None},
 ],
 'phase':'第三輪，5號隊長剛提名[2,3,5]，尚未投票',
 'seat_count':7,
 'human_seat':HUMAN,
}
# A fixed *fictional* rehearsal table; the judge game is never read or touched.
PRIVATE={
 1:{'role':'assassin','evil_teammates':[4,7]},
 2:{'role':'percival','merlin_or_morgana':[4,6]},
 3:{'role':'loyal_servant'},
 4:{'role':'morgana','evil_teammates':[1,7]},
 5:{'role':'loyal_servant'},
 6:{'role':'merlin','known_evil':[1,4,7]},
 7:{'role':'minion','evil_teammates':[1,4]},
}
STYLES={1:'冷靜、會抓字眼，喜歡轉移質疑',2:'敏感、多疑，會保護認為可能的梅林',4:'反應快、有攻擊性，擅長故作無辜',5:'直率、怕被冤枉，容易回嘴',6:'謹慎、能分析，但刻意不表現得知道太多',7:'嘴快、有點愛開玩笑，會故意煽風點火'}
FORBIDDEN=re.compile(r'風險分數|模型評估|系統提示|我身為(?:梅林|莫甘娜|刺客|爪牙)|我知道(?:所有)?(?:壞人|邪惡)是|我是(?:壞人|邪惡|梅林|莫甘娜|刺客)')

@dataclass
class Lab:
 id:str
 created:float=field(default_factory=time.time)
 transcript:list[dict[str,Any]]=field(default_factory=list)
 notes:dict[int,list[str]]=field(default_factory=lambda:{i:[] for i in range(1,8)})
 turns:int=0
 last_plan:list[dict[str,Any]]=field(default_factory=list)
 fact_checks:list[dict[str,Any]]=field(default_factory=list)
 usage:list[dict[str,Any]]=field(default_factory=list)

LABS:dict[str,Lab]={}

def public_snapshot(lab:Lab)->dict:
 return {'facts':PUBLIC_FACTS,'verified_public_ledger':public_evidence(), 'recent_dialogue':lab.transcript[-30:], 'speaker_positions':{str(k):v[-5:] for k,v in lab.notes.items() if v}}

def public_evidence() -> dict:
 """Canonical public ledger, generated from the scenario rather than actor prose."""
 proposals=[]
 for p in PUBLIC_FACTS['recent_proposals']:
  votes=p['votes']
  proposals.append({'round':p['round'],'attempt':p['attempt'],'captain':p['captain'],
   'team':p['team'],'vote_status':'未投票' if votes is None else '已揭曉',
   'yes_seats':[] if votes is None else [int(k) for k,v in votes.items() if v=='yes'],
   'no_seats':[] if votes is None else [int(k) for k,v in votes.items() if v=='no'],
   'captain_vote':None if votes is None else votes[str(p['captain'])]})
 return {'mission_results':[
  {'round':m['round'],'team':m['team'],'fail_cards':m['fail_cards'],'result':m['result'],
   'note':'零失敗牌不能證明全隊均為正義；邪惡也能出成功牌'}
  for m in [PUBLIC_FACTS['mission_1'],PUBLIC_FACTS['mission_2']]],
  'proposals':proposals,
  'common_ground':['第一輪任務失敗；第二輪任務成功',
   '第三輪第一次提案[3,4,6]有五票反對（1、2、3、4、6號）及兩票同意（5、7號）',
   '4號自己提名[3,4,6]，卻投了反對票',
   '第三輪第二次提案[2,3,5]還沒有投票']}

def factual_violations(text:str)->list[str]:
 """Narrow deterministic checks of *explicit* ledger contradictions.

 Deliberate subjective allegations remain allowed. It is not a truth oracle.
 """
 t=re.sub(r'\s+','',text)
 issues=[]
 # On the contested proposal there were five NO votes and two YES votes.
 if re.search(r'(沒人|無人|沒有人|根本沒人|沒誰|全部都沒)(?:[\u4e00-\u9fff]{0,8})?(?:反對|擋|否決)',t):
  issues.append('第三輪第一次提案實際有五票反對，不能說沒人反對')
 if re.search(r'(全票|一致|全部|所有人)(?:[\u4e00-\u9fff]{0,4})?(?:同意|贊成|通過)',t) and re.search(r'(3[,，、]?4[,，、]?6|那隊|我(?:的|提的)隊)',t):
  issues.append('第三輪第一次提案只有兩票同意，沒有通過')
 if re.search(r'(全(?:是|都|員)?(?:安全|好人|正義)|確定(?:全是好人|都沒壞人))',t) and re.search(r'(2[,，、]?3[,，、]?5|上一輪|第二輪|任務二|成功隊)',t):
  issues.append('第二輪成功不代表隊員都是真正好人')
 if re.search(r'(上一輪|第二輪|任務二)(?:[\u4e00-\u9fff]{0,10})?(?:失敗|炸|失敗牌)',t):
  issues.append('第二輪任務成功，只有第一輪失敗')
 if re.search(r'(第一輪|任務一)(?:[\u4e00-\u9fff]{0,10})?(?:成功|零失敗)',t):
  issues.append('第一輪任務失敗，有一張失敗牌')
 return issues

def remembered_positions(lab:Lab,seat:int)->dict:
 """Public conversational commitments only; never copy other actors' secret notes."""
 mine=[{'text':x['text'],'reply_to':x.get('reply_to'),'turn_index':i}
       for i,x in enumerate(lab.transcript) if x['speaker']==seat]
 addressed=[{'speaker':x['speaker'],'text':x['text'],'turn_index':i}
            for i,x in enumerate(lab.transcript) if x.get('reply_to')==seat]
 return {'my_previous_claims':mine[-9:],'recent_challenges_to_me':addressed[-7:]}

def _call(system:str,payload:dict,max_tokens:int=500)->str:
 from openai import OpenAI
 client=OpenAI(timeout=35,max_retries=0)
 model=os.getenv(LAB_MODEL_ENV,DEFAULT_MODEL)
 response=client.chat.completions.create(model=model,messages=[
  {'role':'system','content':system},
  {'role':'user','content':json.dumps(payload,ensure_ascii=False)}],max_tokens=max_tokens)
 return (response.choices[0].message.content or '').strip()

def _json(text:str)->dict:
 text=text.strip()
 if text.startswith('```'):
  text=re.sub(r'^```(?:json)?\s*|\s*```$','',text)
 return json.loads(text)

def heuristic_plan(lab:Lab,statement:str,target:int|None)->list[dict]:
 """Offline fallback is clearly labeled; not presented as successful live AI."""
 addressed=target or next((int(x) for x in re.findall(r'([1-7])\s*號',statement) if int(x)!=HUMAN),4)
 if addressed==HUMAN:addressed=4
 other=next(x for x in [2,5,7,1,6,4] if x not in (HUMAN,addressed))
 return [{'seat':addressed,'intent':'直接回答被質問的事實或論點','reply_to':HUMAN},
         {'seat':other,'intent':'反駁上一位角色的論據，提出另一個解釋','reply_to':addressed},
         {'seat':addressed,'intent':'針對剛才的反駁回嘴，不重複前文','reply_to':other}]

def ensure_exchange(items:list[dict],statement:str,target:int|None)->list[dict]:
 """Require a substantive counter-turn for explicit challenges, not for casual talk."""
 challenged=target or next((int(x) for x in re.findall(r'([1-7])\s*號',statement) if int(x)!=HUMAN),None)
 dispute=any(x in statement for x in ('為什麼','為何','怎麼','說謊','騙','矛盾','反對','不合理','壞人','你剛','同意'))
 if challenged not in STYLES or not dispute:return items[:4]
 if not items or items[0]['seat']!=challenged:
  items=[{'seat':challenged,'intent':'先正面回答玩家的質問','reply_to':HUMAN}]+items
 if len(items)<2:
  other=next(x for x in [5,2,7,1,6,4] if x!=challenged)
  items.append({'seat':other,'intent':'針對第一人的回答提出具體不同意見','reply_to':challenged})
 if len(items)<3:
  last=items[-1]['seat']
  if last!=challenged:items.append({'seat':challenged,'intent':'直接回擊上一人的批評','reply_to':last})
 return items[:4]


def plan(lab:Lab,statement:str,target:int|None)->tuple[list[dict],str]:
 public=public_snapshot(lab)
 director_system=(
  '你是七人阿瓦隆的「圓桌發言調度員」，只看得見公開資料，沒有任何身分秘密。'
  '你僅決定誰在下一段對話說話、對誰說、用什麼互動意圖；絕對不能撰寫台詞、裁決身分、安排投票或透露秘密。'
  '確保被直接質問的人有合理機會回答；可以讓另一人插嘴、抓語病、反駁、甚至讓當事人再回嘴。'
  '衝突必須源自已發生的公開事實或具體玩家發言；不同回合允許沉默，不要機械式人人輪流。'
  '每一段爭執應比前一段多一個可檢查的新論點，例如：提問→回答→反證→修正或反擊。不要把同一句話換個說法重複。'
  '尤其重視對方是否迴避問題、引用錯誤票型或以任務成功冒充身分證明。' 
  '每段通常1到4句角色發言；同一角色可回應兩次；不要固定3人。'
  '只輸出 JSON：{"turns":[{"seat":1,"intent":"...","reply_to":3}]}；seat僅能為1,2,4,5,6,7。'
 )
 if not os.getenv('OPENAI_API_KEY'):
  return heuristic_plan(lab,statement,target),'offline-no-key'
 try:
  parsed=_json(_call(director_system,{'public':public,'human_latest':statement,'direct_target':target},360))
  items=parsed.get('turns',[])
  valid=[]
  for item in items[:4]:
   seat=item.get('seat');reply=item.get('reply_to')
   if type(seat) is int and seat in STYLES and type(reply) is int and 1<=reply<=7 and reply!=seat:
    valid.append({'seat':seat,'intent':str(item.get('intent','自然回應'))[:120], 'reply_to':reply})
  if not valid:raise ValueError('invalid director plan')
  if target and target!=HUMAN and valid[0]['seat']!=target:
   valid.insert(0,{'seat':target,'intent':'直接回答玩家的質問','reply_to':HUMAN})
  return ensure_exchange(valid,statement,target),'director-llm'
 except Exception as exc:
  return heuristic_plan(lab,statement,target),'director-fallback:'+type(exc).__name__

def _voting_check(text:str)->bool:
 # A hard check for explicit unrevealed identity declaration; not perfect semantic moderation.
 return not FORBIDDEN.search(text)

def speaker(lab:Lab, seat:int, intent:str,reply_to:int, human_statement:str)->tuple[str,str]:
 role_view=PRIVATE[seat].copy()
 # Private role is provided ONLY to the actor; director never sees PRIVATE.
 public=public_snapshot(lab)
 system=(f'你是阿瓦隆{seat}號玩家。性格：{STYLES[seat]}。你的合法私人資訊另附。'
  '這是實際玩家間的桌遊爭論，不是客服對話。你會為自己的陣營努力獲勝，允許嘴硬、策略性騙人、失誤和改口。'
  '一定要回應指定對象上一句的「具體」論點，必要時抓對方邏輯漏洞、反問、當場回嘴。'
  '你要能辨認事實、推論、臆測三層：先指出已知票型或任務，再說你的解讀，最後用一個具體反例反問對方。'
  '對方抓到你先前的矛盾時，不可若無其事；可承認立場轉變、合理辯護、狡辯或轉移焦點，但不能虛構票數。'
  '你在此前公開說過的話要保持連貫，可以改主意但必須有觸發理由；不要每次假裝第一次聊天。'
  '禁止空泛說「需要更多資訊」「謹慎分析」「大家怎麼看」。不能亂編歷史票數、任務或自爆角色。'
  '固定公開事實：第一輪[1,4]失敗，第二輪[2,3,5]成功；第三輪第一次[3,4,6]五反對兩同意，4號自己提自己反對；第三輪第二次[2,3,5]尚未投票。'
  '任務成功不代表隊上全是好人，壞人可出成功牌。不能把過去的成功任務稱作全安全。'
  '你只能知道自己的合法私人資訊，不能猜測模型看得到其他角色身分。'
  '若要談對方的真實身分必須以公開證據作為推測而非確定事實。'
  '使用繁體中文生活口語，1至3句話。不要說演算法、分數、模型、提示詞。'
  '不要產生任何遊戲行動指令，僅輸出角色要說的話。')
 if not os.getenv('OPENAI_API_KEY'):
  return '（未設定 API 金鑰，無法進行真人感的 AI 辯論；此處僅驗證流程。）','offline-no-key'
 payload={'private_legal_view':role_view,'public':public,'intent':intent,'reply_to':reply_to,
          'human_latest':human_statement,'my_public_positions':lab.notes[seat][-5:],
          'my_public_memory':remembered_positions(lab,seat)}
 try:
  raw=_call(system,payload,280).strip().strip('"「」')[:450]
  if not raw or not _voting_check(raw):raise ValueError('speech validation failed')
  issues=factual_violations(raw)
  if issues:
   # Only regenerate when there is a verifiable factual contradiction;
   # free-form arguments and character attitude are not mechanically censored.
   correction={**payload,'original_speech':raw,'factual_errors':issues,
    'instruction':'保留同樣的態度、情緒、反駁目標，只修正可核實的事實錯誤。僅輸出修正版台詞。'}
   revised=_call(system,correction,280).strip().strip('"「」')[:450]
   if not revised or not _voting_check(revised) or factual_violations(revised):
    raise ValueError('factual correction failed')
   return revised,'actor-llm-corrected'
  return raw,'actor-llm'
 except Exception as exc:
  return '我先不跟著下結論，你把哪次的票指出來，我們就對那一筆。','actor-fallback:'+type(exc).__name__

def speak(lab:Lab,text:str,target:int|None=None)->dict:
 if lab.turns>=30:raise ValueError('實驗室最多30次玩家發言，請重新開啟新場景')
 text=text.strip()
 if not text or len(text)>900:raise ValueError('發言必須為1至900字')
 if target is not None and target not in STYLES:raise ValueError('指定對象無效')
 lab.transcript.append({'speaker':HUMAN,'text':text,'mode':'human'})
 lab.notes[HUMAN].append(text)
 turns,status=plan(lab,text,target)
 lab.last_plan=turns
 created=[]
 for t in turns:
  # Each actor sees transcript updated by earlier replies in this interaction.
  line,mode=speaker(lab,t['seat'],t['intent'],t['reply_to'],text)
  entry={'speaker':t['seat'],'text':line,'mode':mode,'reply_to':t['reply_to']}
  lab.transcript.append(entry)
  lab.notes[t['seat']].append(line)
  created.append(entry)
 lab.turns+=1
 lab.usage.append({'director':status,'actors':[x['mode'] for x in created]})
 return {'replies':created,'director_status':status,'speaker_plan':turns,'turns_used':lab.turns}

def create_lab()->Lab:
 now=time.time()
 for key,v in list(LABS.items()):
  if now-v.created>3600:LABS.pop(key,None)
 if len(LABS)>=12:raise ValueError('實驗室已達連線上限，請稍後重試')
 l=Lab(secrets.token_urlsafe(20));LABS[l.id]=l
 l.transcript=[{'speaker':4,'text':'我剛才提[3,4,6]本來想試，但最後我還是投反對了。','mode':'fixture'},
               {'speaker':5,'text':'4號你自己提的隊，自己又不同意？不要跟我說你突然想通了。','mode':'fixture'},
               {'speaker':4,'text':'我不是說隊伍一定不行，只是覺得現在不該冒這個險。','mode':'fixture'}]
 for m in l.transcript:l.notes[m['speaker']].append(m['text'])
 return l
