# Avalon AI v0.7 — 自然圓桌群聊實驗版

保留 v0.6 對局裁判與情報隔離，以公開對話調度器 `groupchat.py` 增加：

1. 真人指定玩家時，該 NPC 先回答；遇到質疑時，其他 NPC 可以插話、原對象可能再次回嘴；短句不強制吵架。
2. NPC 在公開投票後，可根據**已公開的真實票型**主動質疑，對方回應可以透過 LLM 生成。
3. 圓桌衝突記錄與每位 NPC 的公開發言立場會延續，做為後續**對話上下文**。
4. 不改動 v0.6 的隊長輪替、秘密投票、任務規則、梅林偽裝、刺殺結算。
5. 語言模型的輸入仍使用該座位的合法資訊。公開衝突不等於已證明的身分證據；單純的口頭指控不會改寫裁判結論。

## 已知限制

- 這是第一階段的**圓桌原型**；自然度依 LLM 模型、上下文與延遲而異。無金鑰時使用基於事件的備援台詞。
- 衝突的公開記憶目前主要改善對話一致性，不代表自由討論會自動改變所有 NPC 的選人及投票演算法；沿用 v0.6 可驗證矛盾的有限行為證據。
- 使用原先 Railway 環境變數：`AVALON_ACCESS_PASSWORD`（16 字元以上）、`OPENAI_API_KEY`、`AVALON_LLM_MODEL`。不要將金鑰寫進 ZIP 或 GitHub。
- 伺服器仍用記憶體保存遊戲；重啟會遺失進行中的對局。

## 驗證

```bash
python -m unittest discover -p 'test_*.py' -q
```

本版開發時 100 項測試通過。Railway 使用原來的 `Dockerfile` 與相同路徑的 `avalon_app.zip`。

## v0.8 Director Lab (2026-11-14)

A self-contained **debate-only experiment** at `/director-lab` next to the unchanged `/` v0.7 game. It uses a *fictional, fixed mid-game scenario* to test conversational quality without changing canonical Match scoring, selection, ballots, hidden information or results.

- `director_lab.py`: public-only conversation director; individual per-seat legal private slices provided only to the corresponding actor; bounded replies (1–4); counter-response safeguard; in-memory lab sessions.
- `static/director-lab.html`: mobile-first iPhone Safari interface, chat and JSON audit export.
- `test_v08.py`: isolated scenario / role boundary / API route tests.
- `AVALON_DIRECTOR_MODEL` (optional; defaults to `gpt-4.1`): separate model for lab director **and lab actor dialogue**. Existing game's `AVALON_LLM_MODEL` remains unchanged, as do `OPENAI_API_KEY` and `AVALON_ACCESS_PASSWORD`.

No LLM quality was verified live; the test suite mocks/omits external calls. With API key missing, lab visibly labels offline responses rather than claiming human-like output. Chat transcript is in-memory only (1-hour TTL); HTTP Basic auth remains required for all endpoints. Lab is capped at 12 sessions and 30 human turns per session. Every LLM turn consumes paid API tokens; stronger models can increase cost and latency. The uploaded test-branch repo is public: never commit keys/passwords.

## v0.8.1 — Debate logic / fact grounding update

This is a **non-destructive update to the isolated `/director-lab` only**. The full v0.7 game, its NPC selection/voting strategy and referee engine remain unchanged.

- `public_evidence()` derives a verifiable public ledger from the scenario: mission results, the 5–2 split for the disputed proposal, captain self-rejection, and unrevealed second proposal.
- Each NPC receives public ledger plus its own past public statements/challenges, with strict per-seat private role slice only.
- Director and actor instructions push fact→inference→counterexample responses rather than repeating generic challenges.
- `factual_violations()` narrowly detects several known hard contradictions; when triggered a single regeneration requests correction without diluting character tone. This is **not a general-purpose semantic fact verifier** and does not guarantee perfect reasoning. Unrecoverable contradiction safely falls back.
- Export includes public evidence for post-test audit. No new environment variables; use the existing `AVALON_DIRECTOR_MODEL` (`gpt-4.1` default) and OpenAI API key.
- More tokens can be used on turns requiring a correction; usage is billed by the API. The lab still does not affect real game scoring or votes.

Development verification: `python -m unittest discover -p 'test_*.py' -q` passed 118 tests. Live GPT-4.1 quality still requires user playtesting.
