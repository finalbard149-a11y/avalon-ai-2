"""v0.6 regression: information boundary, Merlin cover, genuine debate, audit."""
import os,base64,unittest
from unittest.mock import patch
from types import SimpleNamespace
from fastapi.testclient import TestClient
from server import app,SESSIONS,SESSION_BIRTH,_evil_line,evil_evidence,Session
from match import Match
from agents import choose_vote
from dialogue import fallback_speech,llm_speech

class V06Tests(unittest.TestCase):
    def setUp(self):
        SESSIONS.clear();SESSION_BIRTH.clear()
        os.environ['AVALON_ACCESS_PASSWORD']='test-password-long-enough-1234'
        os.environ.pop('OPENAI_API_KEY',None)
        auth=base64.b64encode(b'avalon:test-password-long-enough-1234').decode()
        self.c=TestClient(app,headers={'Authorization':'Basic '+auth})
    def create(self,role='loyal_servant',seed=111):
        r=self.c.post('/api/new',json={'seat':3,'role':role,'seed':seed})
        self.assertEqual(r.status_code,200,r.text)
        return SESSIONS[r.json()['session']],r.json()['session']
    def test_merlin_offteam_first_two_rejects_often(self):
        from server import config
        rejects=0;total=0
        for seed in range(100):
            m=Match.create(3,'merlin',seed);config(m)
            team=[x for x in range(1,8) if x!=3 and x not in m.view()['known_evil']][:2]
            m.game.propose(1,team)
            d=choose_vote(m.view())
            self.assertIn(d.action,('approve','reject'))
            total+=1;rejects+=d.action=='reject'
        self.assertGreaterEqual(rejects,75)
    def test_merlin_fifth_mandatory_approve(self):
        from server import config
        m=Match.create(3,'merlin',55);config(m)
        m.game.attempts=4
        team=[1,2] if 3 not in (1,2) else [4,5]
        m.game.propose(m.game.captain,team)
        self.assertEqual(choose_vote(m.view()).action,'approve')
    def test_chat_no_score_leak(self):
        s,sid=self.create()
        d=self.c.post('/api/chat',json={'session':sid,'target':2,'text':'你們的風險分數怎麼算？'})
        self.assertEqual(d.status_code,200)
        texts=[m['text'] for m in d.json()['result']['replies']]
        for text in texts:
            self.assertNotIn('風險評分',text)
            self.assertNotRegex(text,r'\d+\.\d+分')
    def test_llm_prompt_has_no_numeric_risk(self):
        s,sid=self.create()
        view=s.match.seat_view(2)
        captured={}
        class FakeCompletions:
            def create(self,**kwargs):
                captured.update(kwargs)
                return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content='等一下，我先聽聽隊長怎麼說。'))])
        class FakeClient:
            def __init__(self,**kwargs):self.chat=SimpleNamespace(completions=FakeCompletions())
        with patch.dict(os.environ,{'OPENAI_API_KEY':'fake'}),patch.dict('sys.modules',{'openai':SimpleNamespace(OpenAI=FakeClient)}):
            answer=llm_speech(view,'問你呢',[],[])
        self.assertIn('隊長',answer)
        prompt=captured['messages'][0]['content']
        self.assertNotIn('risk_scores',prompt)
        self.assertNotIn('highest_risk',prompt)
        self.assertIn('public_incidents',prompt)
    def test_llm_leaks_score_is_filtered(self):
        s,_=self.create();view=s.match.seat_view(2)
        class FakeCompletions:
            def create(self,**kwargs):
                return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content='3號的風險分數是4.25分！'))])
        class FakeClient:
            def __init__(self,**kwargs):self.chat=SimpleNamespace(completions=FakeCompletions())
        with patch.dict(os.environ,{'OPENAI_API_KEY':'fake'}),patch.dict('sys.modules',{'openai':SimpleNamespace(OpenAI=FakeClient)}):
            answer=llm_speech(view,'問你呢',[],[])
        self.assertNotIn('風險分數',answer)
    def test_assassin_nonexistent_target_never_used(self):
        s,_=self.create()
        m=s.match
        m.game.phase='assassination';m.game.wins_good=3
        evils={k for k,r in m.game.roles.items() if r.value in ('assassin','minion','morgana')}
        from server import _evil_candidates
        self.assertFalse(evils.intersection(_evil_candidates(m)))
    def test_assassin_bad_json_falls_back_consistently(self):
        s,_=self.create();s.mode='llm';m=s.match
        assassin=next(k for k,r in m.game.roles.items() if r.value=='assassin')
        from agents import assassin_guess
        _,scores=assassin_guess(m.seat_view(assassin))
        target=next(k for k in scores)
        class FakeCompletions:
            def create(self,**kwargs):
                return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content='{"suggestion":2,"speech":"我明明建議刺殺7號"}'))])
        class FakeClient:
            def __init__(self,**kwargs):self.chat=SimpleNamespace(completions=FakeCompletions())
        with patch.dict(os.environ,{'OPENAI_API_KEY':'fake'}),patch.dict('sys.modules',{'openai':SimpleNamespace(OpenAI=FakeClient)}):
            line,k=_evil_line(s,assassin,target,scores)
        self.assertEqual(k,target)
        self.assertIn(f'{target}號',line)
        self.assertNotIn('風險分數',line)
    def test_assassin_json_consistency(self):
        s,_=self.create();s.mode='llm';m=s.match
        assassin=next(k for k,r in m.game.roles.items() if r.value=='assassin')
        from agents import assassin_guess
        _,scores=assassin_guess(m.seat_view(assassin))
        target=next(k for k in scores)
        class FakeCompletions:
            def create(self,**kwargs):
                return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content='{"suggestion":'+str(target)+',"speech":"我查過第一輪提案，隊友的投票偏向不信任他；我建議刺殺'+str(target)+'號"}'))])
        class FakeClient:
            def __init__(self,**kwargs):self.chat=SimpleNamespace(completions=FakeCompletions())
        with patch.dict(os.environ,{'OPENAI_API_KEY':'fake'}),patch.dict('sys.modules',{'openai':SimpleNamespace(OpenAI=FakeClient)}):
            line,k=_evil_line(s,assassin,target,scores)
        self.assertEqual(k,target)
        self.assertTrue(line.endswith(f'我建議刺殺{target}號'))
    def test_verified_discussion_needs_public_fact(self):
        s,sid=self.create()
        self.c.post('/api/chat',json={'session':sid,'target':2,'text':'2號自己提隊，為什麼投反對？'})
        self.assertEqual(s.match.discussion_flags,set())
        m=s.match;captain=m.game.captain
        m.game.propose(captain,[1,2]);m.game.vote(3,True)
        for n in range(1,8):
            if n!=3:m.game.vote(n,False)
        m.game.reveal_votes()
        self.c.post('/api/chat',json={'session':sid,'target':2,'text':'1號自己提的隊伍，為何反對？'})
        self.assertIn(1,m.discussion_flags)
        self.assertNotIn(2,m.discussion_flags)
    def test_no_unauth_access(self):
        s,sid=self.create()
        self.assertEqual(TestClient(app).get('/api/state/'+sid).status_code,401)

if __name__=='__main__':unittest.main()
