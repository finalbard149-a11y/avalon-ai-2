import unittest
from engine import Game,Role
from match import Match,run_automated
from agents import choose_proposal,choose_vote,percival_zones,accumulated_alerts

ROLES={1:Role.MORGANA,2:Role.MERLIN,3:Role.PERCIVAL,4:Role.LOYAL,5:Role.MINION,6:Role.ASSASSIN,7:Role.LOYAL}

class TestV045(unittest.TestCase):
    def makeview(self,seat):
        view=Game(ROLES).player_view(seat)
        view['_v045_enabled']=True
        return view
    def test_percival_never_nominates_both_thumbs(self):
        game=Game(ROLES)
        for r in range(5):
            game.round_index=r
            v=game.player_view(3);v['_v045_enabled']=True
            t=choose_proposal(v)
            self.assertLessEqual(len(set(t)&{1,2}),1)
            self.assertEqual(len(t),game.public_view()['team_size'])
    def test_percival_low_risk_is_not_truth(self):
        v=self.makeview(3)
        z=percival_zones(v)
        self.assertEqual(z['thumb_candidates'],[1,2])
        self.assertNotIn(3,z['lower_risk'])
        self.assertIn('低風險不等於忠臣',z['note'])
    def test_alert_only_after_two_increases(self):
        v=self.makeview(4)
        v['_risk_increase_counts']={5:1,6:2}
        self.assertEqual(accumulated_alerts(v),{6:2})
    def test_reject_high_risk_even_if_self_in_team(self):
        v=self.makeview(4)
        v['_risk_increase_counts']={5:2}
        v['public']['proposal']=[4,5]
        from unittest.mock import patch
        with patch('agents.suspicion',return_value={1:2,2:2,3:2,4:-100,5:5,6:2,7:2}):
            d=choose_vote(v)
        self.assertEqual(d.action,'reject')
        self.assertIn('v045_high_risk_veto',d.tags)
    def test_fifth_attempt_prioritizes_no_auto_loss(self):
        v=self.makeview(4)
        v['_risk_increase_counts']={5:3}
        v['public']['proposal']=[4,5]
        v['public']['attempt']=5
        self.assertEqual(choose_vote(v).action,'approve')
    def test_speech_trigger_is_two_increments_not_guess(self):
        m=Match.create(human_seat=3,human_role='percival',seed=35)
        m.v045_enabled=True
        # No public votes: no automatic accusation.
        self.assertEqual(m.public_accusations,[])
        # Legal private view only includes the subject's own risk counters.
        m.risk_increase_counts[4]={5:2}
        self.assertEqual(m.seat_view(4)['_risk_increase_counts'],{5:2})
        self.assertEqual(m.seat_view(2)['_risk_increase_counts'],{})
    def test_finished_match_and_audit(self):
        m=run_automated(seed=701,v045_enabled=True,percival_mutual_inference_enabled=True)
        self.assertIn(m.game.final_result,('good','evil'))
        self.assertTrue(m.game.audit())

if __name__=='__main__': unittest.main()
