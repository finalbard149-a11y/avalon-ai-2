"""Conservative guard for *explicit* contradictions of revealed game results.

Does not judge motive, suspicion, or a deliberate interpretation of a ballot.
"""
from __future__ import annotations
import re
from dialogue import public_incidents  # imports dialogue, not its gameplay entrypoints

_NUM={'一':1,'二':2,'三':3,'四':4,'五':5,'1':1,'2':2,'3':3,'4':4,'5':5}

def factual_violations(view:dict,text:str)->list[str]:
    missions=[e for e in public_incidents(view,100) if e['kind']=='mission']
    if not missions:return []
    compact=re.sub(r'\s+','',text)
    problems=[]
    for m in re.finditer(r'第([一二三四五1-5])輪(?:的)?(?:任務)?(?:是|已經|明明|根本)?(成功|失敗|零失敗|沒有失敗牌)',compact):
        idx=_NUM[m.group(1)]
        if idx>len(missions):continue
        actual=missions[idx-1]
        claimed_success=m.group(2) in ('成功','零失敗','沒有失敗牌')
        if claimed_success!=bool(actual['succeeded']):
            problems.append(f'第{idx}輪任務實際是{"成功" if actual["succeeded"] else "失敗"}')
    return problems
