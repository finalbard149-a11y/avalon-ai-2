import unittest
from unittest.mock import patch
from agents import choose_vote
from engine import Game,Role

ROLES={1:Role.MINION,2:Role.MERLIN,3:Role.PERCIVAL,4:Role.LOYAL,5:Role.ASSASSIN,6:Role.MORGANA,7:Role.LOYAL}

class TestPercivalStrategy(unittest.TestCase):
    def makeview(self,role=Role.PERCIVAL,captain=1,team=(1,3),attempt=1):
        game=Game(ROLES,first_captain=captain)
        game.propose(captain,list(team))
        game.attempts=attempt-1
        return game.player_view(3)
    def test_percival_retains_candidates_not_known_evil(self):
        v=self.makeview()
        self.assertEqual(v['known_evil'],[])
        self.assertEqual(v['merlin_or_morgana'],[2,6])
    def test_percival_rejects_suspect_captain_despite_being_selected(self):
        v=self.makeview()
        scores={1:5.7,2:2.4,3:-100,4:1.9,5:2.2,6:4.7,7:2.1}
        with patch('agents.suspicion',return_value=scores):
            decision=choose_vote(v)
        self.assertEqual(decision.action,'reject')
        self.assertIn('on_team_reject_suspect_captain',decision.tags)
    def test_percival_can_approve_low_risk_captain(self):
        v=self.makeview(captain=4,team=(3,4))
        scores={1:5.7,2:2.4,3:-100,4:1.9,5:2.2,6:4.7,7:2.1}
        with patch('agents.suspicion',return_value=scores):
            self.assertEqual(choose_vote(v).action,'approve')
    def test_fifth_attempt_does_not_hard_veto(self):
        v=self.makeview(attempt=5)
        with patch('agents.suspicion',return_value={1:5.7,2:2.4,3:-100,4:1.9,5:2.2,6:4.7,7:2.1}):
            self.assertEqual(choose_vote(v).action,'approve')
if __name__=='__main__':unittest.main()
