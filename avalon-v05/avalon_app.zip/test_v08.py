import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
import director_lab as d
import server

class DirectorLabTests(unittest.TestCase):
 def setUp(self):
  d.LABS.clear()
 def test_public_snapshot_has_no_other_roles(self):
  l=d.create_lab();x=d.public_snapshot(l)
  self.assertNotIn('private',str(x).lower());self.assertNotIn('morgana',str(x).lower());self.assertNotIn('merlin',str(x).lower())
 def test_is_separate_from_game_sessions(self):
  before=len(server.SESSIONS);l=d.create_lab()
  with patch.dict('os.environ',{'OPENAI_API_KEY':''}):r=d.speak(l,'4號你自己提案又反對？',4)
  self.assertEqual(len(server.SESSIONS),before);self.assertEqual(len(r['replies']),3)
 def test_target_replies_first(self):
  l=d.create_lab()
  with patch.dict('os.environ',{'OPENAI_API_KEY':''}):r=d.speak(l,'4號你不覺得自己很可疑嗎',4)
  self.assertEqual(r['replies'][0]['speaker'],4)
 def test_private_role_not_in_director_payload(self):
  l=d.create_lab();record=[]
  def fake(system,payload,max_tokens):
   record.append(payload)
   return '{"turns":[{"seat":4,"intent":"回答","reply_to":3}]}'
  with patch.dict('os.environ',{'OPENAI_API_KEY':'mock'}),patch.object(d,'_call',side_effect=fake):
   d.plan(l,'4號回答',4)
  self.assertNotIn('private_legal_view',str(record))
  self.assertNotIn('assassin',str(record));self.assertNotIn('merlin',str(record))
 def test_bad_director_json_fallback(self):
  l=d.create_lab()
  with patch.dict('os.environ',{'OPENAI_API_KEY':'mock'}),patch.object(d,'_call',return_value='no json'):
   items,status=d.plan(l,'你好',None)
  self.assertTrue(items);self.assertIn('fallback',status)
 def test_unsafe_actor_text_is_blocked(self):
  l=d.create_lab()
  with patch.dict('os.environ',{'OPENAI_API_KEY':'mock'}),patch.object(d,'_call',return_value='我是梅林'):
   speech,status=d.speaker(l,6,'回答',3,'你好')
  self.assertTrue(status.startswith('actor-fallback'))
 def test_api_private_middleware(self):
  with patch.dict('os.environ',{'AVALON_ACCESS_PASSWORD':'a'*20,'OPENAI_API_KEY':''}):
   import base64
   token=base64.b64encode(('avalon:'+('a'*20)).encode()).decode()
   c=TestClient(server.app,headers={'Authorization':'Basic '+token})
   page=c.get('/director-lab');self.assertEqual(page.status_code,200)
   new=c.post('/api/director-lab/new',json={});self.assertEqual(new.status_code,200)
   r=c.post('/api/director-lab/chat',json={'lab_id':new.json()['lab_id'],'text':'4號，別裝了','target':4})
   self.assertEqual(r.status_code,200)
   self.assertEqual(r.json()['replies'][0]['speaker'],4)
 def test_reject_invalid_target(self):
  l=d.create_lab()
  with self.assertRaises(ValueError):d.speak(l,'hello',3)

if __name__=='__main__':unittest.main()
