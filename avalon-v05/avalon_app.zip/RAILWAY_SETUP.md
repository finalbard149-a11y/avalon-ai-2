# iPhone 更新 v0.5.1（不修改正式網站）

用 Safari 開啟 GitHub 倉庫 `finalbard149-a11y/avalon-ai-2` → 切換分支 `avalon-v05-private-test` → 打開 `avalon-v05` 資料夾 → 刪除舊的 `avalon_app.zip`（**必須確保在測試分支**）→ Upload files 上傳新版 `avalon_app.zip` → Commit changes。既有 Dockerfile 不用變動。

Railway 專案 `avalon-ai-2` 的 `avalon-v05-test` 服務已連接測試分支，自動重新部署後使用：
https://avalon-v05-test-production.up.railway.app/

GitHub 公開倉庫不應包含 API 金鑰、登入密碼或其他私人資訊。它們只放 Railway 私人 Variables。
