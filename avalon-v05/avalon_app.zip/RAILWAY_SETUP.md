# iPhone + Railway private test

1. Upload `avalon_app.zip` and the separate `Dockerfile` to a new `avalon-v05` directory in a GitHub branch, then deploy that branch as a separate Railway service with root directory `/avalon-v05`.
2. Railway service > Variables: `AVALON_ACCESS_PASSWORD` (at least 16 characters, distinct from OpenAI key), `OPENAI_API_KEY` (secret only here), `AVALON_LLM_MODEL` (optional, default `gpt-4o-mini`).
3. Keep `OPENAI_API_KEY` out of GitHub, code files, screenshots and chat.
4. Open HTTPS Railway domain in Safari. HTTP Basic prompt: user `avalon`; password is `AVALON_ACCESS_PASSWORD`.
5. Don't publicly distribute your password or private game link. Limit API billing in OpenAI dashboard.
6. Sessions are in-memory and last up to six hours; do not use as production multiuser app.

This version does not yet make free-text chat alter NPC votes or trust state.
