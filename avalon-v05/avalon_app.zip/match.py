"""Complete seven-seat match controller: one human + six isolated rule-based NPCs.
Human input ALWAYS first for ballot or mission card, NPC decisions sealed afterwards.
For production, replace in-process NPC calls with isolated service invocation.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import random
import secrets
from typing import Any
from engine import Game, Role, RuleViolation, ROLE_COUNTS
from agents import choose_proposal, choose_vote, choose_mission, assassin_guess, PERSONAS, suspicious_approvals, suspicion
from behavior_evidence import public_behavior

@dataclass
class Match:
    game: Game
    human_seat: int = 3
    activity: list[dict[str, Any]] = field(default_factory=list)
    npc_decisions: list[dict[str, Any]] = field(default_factory=list)
    last_reveal: dict[str,Any]|None = None
    nomination_model_enabled: bool = True
    behavioral_evidence_enabled: bool = True
    behavior_weight_multiplier: float = 2.0
    reasoning_trace: list[dict[str,Any]] = field(default_factory=list)
    cross_evidence_enabled: bool = True
    merlin_multi_evil_enabled: bool = False
    merlin_multi_evil_pct: int = 18
    percival_mutual_inference_enabled: bool = False
    v045_enabled: bool = False
    v046_enabled: bool = False
    v046_merlin_cover_enabled: bool = True
    v046_percival_veto_enabled: bool = True
    simulated_human: bool = False  # real human never receives an automatic public statement
    risk_increase_counts: dict[int,dict[int,int]] = field(default_factory=dict)
    public_accusations: list[dict[str,Any]] = field(default_factory=list)

    @classmethod
    def create(cls, human_seat=3, human_role=None, seed=None):
        if human_seat not in range(1,8):raise RuleViolation('human seat must be 1..7')
        rng=random.Random(seed) if seed is not None else random.SystemRandom()
        pool=[r for role,count in ROLE_COUNTS.items() for r in [role]*count]
        if human_role:
            role=Role(human_role)
            pool.remove(role)
            pool=[role]+pool
            rest=pool[1:];rng.shuffle(rest)
            order=[human_seat]+[x for x in range(1,8) if x!=human_seat]
            roles={s:r for s,r in zip(order,[role]+rest)}
        else:
            rng.shuffle(pool);roles={i+1:r for i,r in enumerate(pool)}
        return cls(Game(roles,first_captain=1),human_seat)

    def seat_view(self, seat):
        view=self.game.player_view(seat)
        view['_nomination_model_enabled']=self.nomination_model_enabled
        view['_behavior_evidence_enabled']=self.behavioral_evidence_enabled
        view['_behavior_weight_multiplier']=self.behavior_weight_multiplier
        view['_cross_evidence_enabled']=self.cross_evidence_enabled
        view['_merlin_multi_evil_enabled']=self.merlin_multi_evil_enabled
        view['_merlin_multi_evil_pct']=self.merlin_multi_evil_pct
        view['_percival_mutual_inference_enabled']=self.percival_mutual_inference_enabled
        view['_v045_enabled']=self.v045_enabled
        view['_v046_enabled']=self.v046_enabled
        view['_v046_merlin_cover_enabled']=self.v046_merlin_cover_enabled
        view['_v046_percival_veto_enabled']=self.v046_percival_veto_enabled
        view['_risk_increase_counts']=dict(self.risk_increase_counts.get(seat,{}))
        return view

    def view(self):
        return self.seat_view(self.human_seat)

    def public(self):
        p=self.game.public_view().copy()
        # The host only provides public information and own legal view.
        return p

    def auto_propose_if_npc(self):
        if self.game.phase!='proposal' or self.game.captain==self.human_seat:return None
        leader=self.game.captain
        view=self.seat_view(leader)
        team=choose_proposal(view)
        self._npc(leader,'proposal',team,'根據可見的任務及投票紀錄選擇。')
        self.game.propose(leader,team)
        return {'captain':leader,'team':team}

    def human_propose(self,team):
        self.game.propose(self.human_seat,team)

    def _npc(self,seat,action,value,reason):
        self.npc_decisions.append({'seat':seat,'action':action,'value':value,'reason':reason,
                                   'mission':self.game.round_index+1,'attempt':self.game.attempts+1})

    def human_vote(self,approve: bool):
        if self.game.phase!='voting':raise RuleViolation('Not voting')
        # Record pre-ballot public-state assessment before any NPC vote is revealed.
        before={s:suspicion(self.seat_view(s)) for s in range(1,8) if (s != self.human_seat or self.simulated_human) and self.game.roles[s] not in (Role.MERLIN, Role.ASSASSIN, Role.MORGANA, Role.MINION)}
        self.game.vote(self.human_seat,approve)
        for s in range(1,8):
            if s==self.human_seat:continue
            view=self.seat_view(s)
            d=choose_vote(view)
            self._npc(s,'vote',d.action,d.reason)
            self.game.vote(s,d.action=='approve')
        voting_round=self.game.round_index+1; voting_attempt=self.game.attempts+1
        result=self.game.reveal_votes()
        after={s:suspicion(self.seat_view(s)) for s in before}
        prop=self.game._prior_proposal(self.game.events[-1]) if False else None
        for s in before:
            view=self.seat_view(s)
            relevant=[q for q in suspicious_approvals(view) if q['round']==voting_round and q['attempt']==voting_attempt]
            from cross_evidence import evaluate as cross_evaluate
            cross=cross_evaluate(view)
            self.reasoning_trace.append({'cross_flags': [f for f in cross['cross_flags'] if f['round']==voting_round and f['attempt']==voting_attempt],
                'selection_counts':cross['selected_count'], 'seat':s,'at_seq':len(self.game.events)-1,
                'round':voting_round,'attempt':voting_attempt,'before_evil_scores':before[s],
                'after_evil_scores':after[s], 'new_challenges':relevant})
        if self.v045_enabled:
            # Use only public ballots and each player's legally available view.
            for s in before:
                if self.game.roles[s] not in (Role.LOYAL, Role.PERCIVAL):
                    continue
                counts=self.risk_increase_counts.setdefault(s,{})
                for target, old in before[s].items():
                    if target==s:continue
                    new=after[s].get(target,old)
                    # This is a rise in model risk, not evidence of actual guilt.
                    if new-old >= 0.12:
                        counts[target]=counts.get(target,0)+1
                eligible=[x for x,c in counts.items() if c>=2 and after[s].get(x,0)>=3.15]
                if eligible:
                    who=max(eligible,key=lambda x:(after[s][x],counts[x],-x))
                    if not any(a['speaker']==s for a in self.public_accusations):
                        phrase=f'我知道誰是壞人了！我認為 {who} 號非常可疑，請大家重新檢查他的選人與投票。'
                        statement={'speaker':s,'target':who,'text':phrase,
                                   'risk_increases':counts[who], 'risk_score':round(after[s][who],3),
                                   'round':voting_round,'attempt':voting_attempt}
                        self.public_accusations.append(statement)
                        self.game._log('public_statement',statement)
                        self.activity.append({'type':'speech',**statement})
        self.last_reveal={'type':'vote','result':result}
        return result

    def human_mission(self,fail=False):
        if self.game.phase!='mission' or self.human_seat not in self.game.proposal:
            raise RuleViolation('Human not on mission')
        self.game.mission_card(self.human_seat,fail)
        return self._complete_mission()

    def _complete_mission(self):
        if self.game.phase!='mission':raise RuleViolation('Not mission')
        for s in self.game.proposal:
            if s in self.game.commitments:continue
            view=self.seat_view(s)
            d=choose_mission(view)
            self._npc(s,'mission',d.action,d.reason)
            self.game.mission_card(s,d.action=='fail')
        result=self.game.reveal_mission()
        self.last_reveal={'type':'mission','result':result}
        return result

    def auto_mission_if_no_human(self):
        if self.game.phase=='mission' and self.human_seat not in self.game.proposal:
            return self._complete_mission()
        return None

    def assassinate(self,target=None):
        if self.game.phase!='assassination':raise RuleViolation('Not assassination')
        assassin=next(s for s,r in self.game.roles.items() if r==Role.ASSASSIN)
        if assassin==self.human_seat:
            if target is None:raise RuleViolation('Human assassin must choose a target')
            self._npc(assassin,'assassination',target,'真人刺客的決策')
        else:
            default,scores=assassin_guess(self.seat_view(assassin))
            candidates=[seat for seat in range(1,8) if seat not in self.seat_view(assassin)['evil_teammates']]
            if target is not None and target not in candidates:raise RuleViolation('刺客只能從依法未知的正義候選座位刺殺')
            target=default if target is None else target
            self._npc(assassin,'assassination',target,'依合法公開投票與邪惡討論提出的候選名單決策。')
        result=self.game.assassinate(assassin,target)
        self.last_reveal={'type':'assassination','target':target,'result':result}
        return {'assassin':assassin,'target':target,**result}

    def audit(self):
        record=self.game.audit()
        record['npc_decisions']=self.npc_decisions
        record['reasoning_trace']=self.reasoning_trace
        record['public_accusations']=self.public_accusations
        return record


def run_automated(seed=0,human_role='percival',nomination_model_enabled=True,behavioral_evidence_enabled=True,behavior_weight_multiplier=2.0,cross_evidence_enabled=True,merlin_multi_evil_enabled=False,percival_mutual_inference_enabled=False,merlin_multi_evil_pct=18,v045_enabled=False,v046_enabled=False,v046_merlin_cover_enabled=True,v046_percival_veto_enabled=True):
    """Simulation smoke test with a simulated human following legal basic strategy."""
    m=Match.create(3,human_role,seed)
    m.nomination_model_enabled=nomination_model_enabled
    m.behavioral_evidence_enabled=behavioral_evidence_enabled
    m.behavior_weight_multiplier=behavior_weight_multiplier
    m.cross_evidence_enabled=cross_evidence_enabled
    m.merlin_multi_evil_enabled=merlin_multi_evil_enabled
    m.percival_mutual_inference_enabled=percival_mutual_inference_enabled
    m.merlin_multi_evil_pct=merlin_multi_evil_pct
    m.v045_enabled=v045_enabled
    m.v046_enabled=v046_enabled
    m.v046_merlin_cover_enabled=v046_merlin_cover_enabled
    m.v046_percival_veto_enabled=v046_percival_veto_enabled
    m.simulated_human=True
    for step in range(100):
        if m.game.phase=='finished':return m
        if m.game.phase=='proposal':
            if m.game.captain==3:
                m.human_propose(choose_proposal(m.view()))
            else:m.auto_propose_if_npc()
        elif m.game.phase=='voting':
            # Seat 3 is simulated in this runner; save its actual policy decision
            # before the host reveals the seven ballots. Real humans are never
            # replaced or logged as an NPC by this path.
            d = choose_vote(m.view())
            m._npc(3, 'vote', d.action, d.reason)
            m.human_vote(d.action=='approve')
        elif m.game.phase=='mission':
            if 3 in m.game.proposal:
                m.human_mission(False)
            else:m.auto_mission_if_no_human()
        elif m.game.phase=='assassination':
            if m.game.roles[3]==Role.ASSASSIN:
                target,_=assassin_guess(m.view())
                m.assassinate(target)
            else:m.assassinate()
    raise AssertionError('Simulation did not terminate')
