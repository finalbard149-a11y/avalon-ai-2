import unittest
from unittest.mock import patch
import director_lab as d

class LogicDepthTests(unittest.TestCase):
 def setUp(self):d.LABS.clear()
 def test_public_evidence_counts_votes(self):
  e=d.public_evidence()['proposals'][0]
  self.assertEqual(e['no_seats'],[1,2,3,4,6])
  self.assertEqual(e['yes_seats'],[5,7])
  self.assertEqual(e['captain_vote'],'no')
 def test_unrevealed_votes_stay_unrevealed(self):
  e=d.public_evidence()['proposals'][1]
  self.assertIsNone(e['captain_vote'])
  self.assertEqual(e['yes_seats'],[])
 def test_detect_no_one_opposed(self):
  self.assertTrue(d.factual_violations('根本沒人擋你那隊'))
 def test_detect_all_safe_false_inference(self):
  self.assertTrue(d.factual_violations('上一輪[2,3,5]全安全'))
 def test_detect_second_mission_failed_misstatement(self):
  self.assertTrue(d.factual_violations('第二輪任務失敗'))
 def test_allow_speculative_argument(self):
  self.assertEqual(d.factual_violations('我懷疑4號在刻意帶風向，但也可能只是判斷失誤'),[])
 def test_rewrite_only_verified_error(self):
  l=d.create_lab();calls=[]
  def fake(system,payload,max_tokens):
   calls.append(payload)
   return '根本沒人擋你那隊' if len(calls)==1 else '明明有五個人反對，你還是選擇自己反對，到底是怎樣？'
  with patch.dict('os.environ',{'OPENAI_API_KEY':'fake'}),patch.object(d,'_call',side_effect=fake):
   line,status=d.speaker(l,5,'抓住論證問題',4,'剛才怎麼回事')
  self.assertEqual(status,'actor-llm-corrected')
  self.assertEqual(len(calls),2)
  self.assertIn('factual_errors',calls[1])
  self.assertIn('五個人',line)
 def test_refuse_bad_regeneration(self):
  l=d.create_lab()
  with patch.dict('os.environ',{'OPENAI_API_KEY':'fake'}),patch.object(d,'_call',return_value='根本沒人擋你那隊'):
   _,status=d.speaker(l,5,'回答',4,'你的投票')
  self.assertTrue(status.startswith('actor-fallback'))
 def test_actor_payload_has_only_own_private_role(self):
  l=d.create_lab();payload=[]
  def fake(system,arg,max_tokens):
   payload.append(arg);return '我看到的是4號自己投反對，這怎麼說得過去？'
  with patch.dict('os.environ',{'OPENAI_API_KEY':'fake'}),patch.object(d,'_call',side_effect=fake):
   d.speaker(l,5,'質疑',4,'答話')
  self.assertEqual(payload[0]['private_legal_view']['role'],'loyal_servant')
  self.assertNotIn('known_evil',payload[0]['private_legal_view'])
  self.assertIn('verified_public_ledger',payload[0]['public'])
 def test_memory_refers_to_earlier_public_statements(self):
  l=d.create_lab();l.transcript.append({'speaker':5,'text':'我說過反對這個提案','mode':'actor-llm'})
  memory=d.remembered_positions(l,5)
  self.assertIn('反對這個提案',memory['my_previous_claims'][-1]['text'])
