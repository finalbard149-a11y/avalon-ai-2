"""Seven-player public-evidence NPC policies. No access to full Game or hidden role map.

Personality/preferences are fixed per seat. All entry points accept solely a seat view.
Rule-based baseline, NOT LLM agents; human-quality social deduction is a future step.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import combinations
import hashlib
import random
from npc_policy import Decision, decide_vote, decide_mission
from nomination_inference import posterior, nomination_explanation
from behavior_evidence import public_behavior, behavior_penalty
from cross_evidence import evaluate as cross_evaluate, adjusted_probability
from percival_inference import candidate_morgana_probabilities

PERSONAS = {
 1: ('沈岳','自信、直言、擅長反駁'), 2: ('林澈','謹慎、重視證據'),
 3: ('周衡','質疑權威、偏好邏輯'), 4: ('顧言','溫和而警覺'),
 5: ('葉青','善於試探、冷靜'), 6: ('韓森','果斷、懷疑沉默者'),
 7: ('許洛','保守、重視成功隊伍')}

def public_history(view):
    return view['public']['public_events']

def events_by_type(view, typ):
    return [e for e in public_history(view) if e['type'] == typ]

def completed_team_results(view):
    proposals={}
    out=[]
    for e in public_history(view):
        if e['type']=='proposal':
            proposals[(e['payload']['round'], e['payload']['attempt'])] = e['payload']['team']
        elif e['type']=='mission_revealed':
            p=e['payload']
            # Instead, take the latest accepted proposal in the event stream (sequential game invariant).
            previous=[x for x in public_history(view) if x['seq']<e['seq'] and x['type']=='proposal']
            if previous:
                out.append((previous[-1]['payload']['team'],p['succeeded'],p['fail_cards'],p['threshold']))
    return out

def last_proposal_before(view, seq):
    x=[e for e in public_history(view) if e['seq']<seq and e['type']=='proposal']
    return x[-1]['payload'] if x else {'round':0,'attempt':0}

def suspicion(view):
    """Seat-wise posterior over legal three-evil combinations, based only on PUBLIC evidence.

    Failed missions prove at least the revealed number of evil seats were present.
    Successful missions (including zero FAIL cards) do NOT prove members are good.
    This is a small logical constraint solver, not ground-truth access.
    """
    seat=view['seat']; role=view['role']; allies=set(view['evil_teammates']); known=set(view['known_evil'])
    results=completed_team_results(view)
    candidates=[]
    for bad in combinations(range(1,8),3):
        bad=set(bad)
        if view['side']=='good' and seat in bad: continue
        if view['side']=='evil' and bad != allies: continue
        if role=='merlin' and bad != known:continue
        possible=set(view['merlin_or_morgana'])
        if role=='percival' and len(bad.intersection(possible))!=1:continue
        if any(len(bad.intersection(team))<fails for team,success,fails,threshold in results):continue
        candidates.append(bad)
    if not candidates:
        # Defensive behavior for contradictory game logs: no invented certainty.
        return {s:(-100 if s==seat else 0) for s in range(1,8)}
    scores={s:6.0*sum(s in bad for bad in candidates)/len(candidates) for s in range(1,8)}
    # Calibrate only a small amount using public vote/proposal alignment.
    for e in events_by_type(view,'votes_revealed'):
        prop=last_proposal_before(view,e['seq']); team=set(prop['team'])
        for raw,val in e['payload']['votes'].items():
            voter=int(raw)
            if voter==seat:continue
            if val=='yes' and voter not in team:scores[voter]+=0.04
    if view.get('_nomination_model_enabled', True) and view['side']=='good' and role not in ('merlin',):
        inferred=posterior(view, use_nominations=True)
        # Proposal relation evidence added to the same scale as the mission solver;
        # replace rather than double count original mission constraints.
        scores={s:6.0*(adjusted_probability(view,s,behavior_penalty(view,s,inferred[s])) if view.get("_cross_evidence_enabled",True) else behavior_penalty(view,s,inferred[s])) if view.get("_behavior_evidence_enabled",True) else 6.0*inferred[s] for s in range(1,8)}
        scores[seat]=-100
        # Percival inherits all loyal-servant evidence, then adds *only* the
        # two lawful Merlin/Morgana candidate seats and publicly observed
        # directional nomination / vote behavior. Never access true roles.
        if role=='percival' and view.get('_percival_mutual_inference_enabled',False):
            role_signal=candidate_morgana_probabilities(view)
            a,b=view['merlin_or_morgana']
            # Keep pair mutually exclusive and avoid interpreting this
            # heuristic as certainty. A bounded behavioural update, not a law.
            old=(scores[a]/6.0 - scores[b]/6.0)
            desired=(role_signal[a] - role_signal[b])
            shift=max(-0.95,min(0.95,0.85*(desired-old)))
            scores[a]=max(.15,min(5.85,scores[a]+3.0*shift))
            scores[b]=max(.15,min(5.85,scores[b]-3.0*shift))
    return scores

def percival_zones(view):
    """Heuristic buckets from PERCIVAL'S legal view, not actual character truth.

    Two thumb candidates: one Merlin, one Morgana; they are NOT both evil.
    High-risk and lower-risk are *probabilistic* labels, not guaranteed identities.
    """
    if view['role']!='percival':
        raise ValueError('Percival only')
    pair=set(view['merlin_or_morgana']); own=view['seat']
    scores=suspicion(view)
    candidates=[x for x in range(1,8) if x not in pair and x!=own]
    rises={int(k):int(v) for k,v in view.get('_risk_increase_counts',{}).items()}
    high=[x for x in candidates if scores[x]>=3.25 or rises.get(x,0)>=2]
    low=[x for x in candidates if x not in high and rises.get(x,0)==0 and scores[x]<3.25]
    uncertain=[x for x in candidates if x not in high and x not in low]
    return {'thumb_candidates':sorted(pair),'high_risk':sorted(high),
            'lower_risk':sorted(low),'uncertain':sorted(uncertain),'self':own,
            'scores':{x:round(scores[x],3) for x in range(1,8)},
            'note':'低風險不等於忠臣；拇指兩人是梅林與莫甘娜，不可視為兩個壞人。'}


def accumulated_alerts(view):
    """Private risk observations computed from successive PUBLIC vote reveals.
    Populated by the match controller; never contains hidden role truth.
    """
    raw=view.get('_risk_increase_counts',{})
    return {int(s):int(v) for s,v in raw.items() if int(v)>=2 and int(s)!=view['seat']}


def choose_proposal(view):
    public=view['public']; size=public['team_size']; seat=view['seat']; role=view['role']
    suspects=suspicion(view)
    teams=list(combinations(range(1,8),size))
    known_evil=set(view['known_evil']); allies=set(view['evil_teammates'])
    results=completed_team_results(view)
    alerts=accumulated_alerts(view)
    zones=percival_zones(view) if role=="percival" and view.get("_v045_enabled",False) else None
    best_team=None; best_score=-1e20
    # Experimental Merlin disguise: sometimes deliberately nominate multiple
    # known evil players (never exactly one). Only in early single-fail rounds,
    # and NEVER if evil already has two mission wins. The intent is to conceal
    # Merlin's perfect-knowledge signature, NOT to guarantee better win rate.
    if (role=='merlin' and view.get('_merlin_multi_evil_enabled',False)
        and public['mission'] in (2,3) and public['wins_evil']<2
        and size>=3 and len(known_evil)>=2):
        # Stable, reproducible decision by public round/attempt/seat. No secret
        # seed or RNG state is exposed to the NPC.
        signal=int(hashlib.sha256(f"merlin-cover:{seat}:{public['mission']}:{public['attempt']}:{len(public['public_events'])}".encode()).hexdigest()[:8],16) % 100
        if signal < int(view.get('_merlin_multi_evil_pct',18)):
            bad=sorted(known_evil)
            group=[seat,bad[signal % len(bad)],bad[(signal+1)%len(bad)]]
            if len(set(group))==3:
                # For larger teams, fill only with good seats known to Merlin.
                for candidate in range(1,8):
                    if len(group)>=size:break
                    if candidate not in known_evil and candidate not in group:group.append(candidate)
                return sorted(group)
    for team in teams:
        ts=set(team)
        # Hard restriction requested: Percival never nominates both thumb candidates.
        if zones is not None and len(ts.intersection(zones['thumb_candidates'])) >= 2:
            continue
        val=0.0
        if view['side']=='good':
            if seat in ts:val+=3.5
            if role=='merlin' and known_evil.intersection(ts):
                val-=10000  # NEVER propose known evil when avoidable.
            val-=sum(suspects[s] for s in ts)*1.8
            if zones is not None:
                # Prefer lower-risk non-thumb seats before betting on thumb identities.
                val+=2.1*len(ts.intersection(zones['lower_risk']))
                val-=3.8*len(ts.intersection(zones['high_risk']))
                val-=1.0*len(ts.intersection(zones['thumb_candidates']))
            if view.get('_v045_enabled',False):
                val-=2.7*sum(1 for s in ts if s in alerts and suspects[s]>=3.15)
            for prev,succeeded,failed,threshold in results:
                if succeeded and failed==0:
                    val+=0.5*len(ts.intersection(prev))
        else:
            included=len(ts.intersection(allies))
            if public['mission']==4:
                val+= (9 if included >= 2 else -6)
            else:
                val+= (9 if included >= 1 else -10)
            if seat in ts:val+=1
            val-=max(0,included-1)*0.6  # avoid obviously stacking evil
        val+=((int(hashlib.sha256((str(seat)+str(team)).encode()).hexdigest()[:6],16)%1000)/1000)*0.03
        if val>best_score:best_score=val;best_team=team
    return list(best_team)

def suspicious_approvals(view):
    """Post-reveal suspect questions based exclusively on public ballots."""
    return public_behavior(view)['challenges']


def choose_vote(view):
    team=view['public']['proposal']
    base=decide_vote(view,team)
    # Merlin's role-knowledge hard veto and evil tactical policy take priority.
    # All good players auto-approve on fifth attempt as a safety policy.
    # No approval means an immediate loss, even if one knows the team is bad.
    if view['public']['attempt']==5 and view['side']=='good':
        return Decision('approve','第五次提案：正義投反對將直接導致邪惡勝利，因此強制同意。',('fifth_attempt','good_mandatory_approve'))
    if view.get('_v046_enabled', False):
        if view['role'] == 'percival' and view.get('_v046_percival_veto_enabled', True):
            # Both thumb candidates together necessarily include Morgana, but
            # Percival does not know WHICH one. Even if Percival is on team,
            # reject when another attempt remains.
            if len(set(team).intersection(view['merlin_or_morgana'])) == 2:
                return Decision('reject',
                    '我雖然可能在隊伍內，但兩位拇指候選者必含莫甘娜；仍有下一次提案機會，我反對。',
                    ('v046_percival_double_thumb_veto', 'legal_private_knowledge'))
        if view['role'] == 'merlin' and view.get('_v046_merlin_cover_enabled', True):
            public = view['public']
            evil_count = len(set(team).intersection(view['known_evil']))
            # Early or good is tied/ahead: occasionally accepting a known-risk
            # own-seat team masks Merlin's almost perfect voting signature.
            # Never deliberately approve an immediate third evil mission win.
            threshold = 2 if public['mission'] == 4 else 1
            terminal = public['wins_evil'] >= 2 and evil_count >= threshold
            situational_cover = (public['mission'] <= 2 or
                                  public['wins_good'] >= public['wins_evil'])
            if view['seat'] in team and evil_count and situational_cover and not terminal:
                return Decision('approve',
                    '我在隊伍裡，現階段仍有調整空間；願意承擔這次任務的風險。',
                    ('v046_merlin_own_team_cover', 'nonterminal_only'))
    if view['role']=='merlin' or view['side']=='evil':
        return base
    scores=suspicion(view)
    alerts=accumulated_alerts(view) if view.get('_v045_enabled',False) else {}
    # Two or more *separate* rises in risk + current elevated score:
    # reject teams containing a publicly identified suspect.
    if view.get('_v045_enabled',False) and view['public']['attempt'] != 5:
        high_alerts={s for s in alerts if scores[s] >= 3.15}
        if high_alerts.intersection(team):
            return Decision('reject',
                            '我已經公開指出可疑對象；這隊仍含高風險玩家，我反對。',
                            ('repeated_risk_evidence','v045_high_risk_veto'))
    teamrisk=sum(scores[s] for s in team)
    all_teams=list(combinations(range(1,8),len(team)))
    alternatives=sorted(sum(scores[s] for s in t) for t in all_teams)
    cutoff=alternatives[max(0,int(len(alternatives)*0.30)-1)]
    median=alternatives[len(alternatives)//2]
    on_team=view['seat'] in team
    history=completed_team_results(view)
    previous_zero_fail=any(succeeded and fails==0 and set(team)==set(prior)
                           for prior,succeeded,fails,threshold in history)
    # Both loyal servants and Percival inherit the same public-evidence analysis.
    # Percival additionally restricts role hypotheses to exactly one evil among
    # the two Merlin/Morgana candidates (already enforced in posterior()).
    # Suspicious captains are NOT automatically trusted just because they selected us.
    captain=view['public']['captain']
    captain_risk=scores[captain]
    peer_risks=[scores[x] for x in range(1,8) if x!=view['seat']]
    # Require a substantial relative signal; avoid confusing a weak suspicion
    # with certainty. On attempt 5 we already avoid a terminal auto-reject.
    peer_sorted=sorted(peer_risks)
    high_captain_risk=(captain!=view['seat'] and
                       captain_risk>=peer_sorted[-2] and
                       captain_risk>sum(peer_risks)/len(peer_risks)+0.65)
    if on_team and high_captain_risk and not previous_zero_fail:
        return Decision('reject',
                        '我雖然在隊伍裡，但隊長在公開證據下屬高風險，應讓下一位隊長重新提案。',
                        ('on_team_reject_suspect_captain','public_evidence','new_captain'))
    if on_team:
        if teamrisk<=median+0.8:
            return Decision('approve','我能確認自己是好人，且此隊風險不高於其他選擇太多。',
                            ('self_knowledge','relative_team_risk'))
        return Decision('reject','即使我在隊內，其他人員的公開風險仍過高。',('team_risk',))
    # Not on team: default NO, unless a defensible *public* justification exists.
    # An exact zero-fail repeat is weak evidence, not an identity certificate.
    if previous_zero_fail and teamrisk<=cutoff:
        return Decision('approve','我未入隊；但這是先前零失敗牌的原隊伍，且相對公開風險低。',
                        ('off_team_exception','zero_fail_repeat','relative_team_risk'))
    if view['public']['attempt']==4 and teamrisk<=cutoff:
        return Decision('approve','已到第四次提案，若再否決只剩最後一次；目前公開風險相對低。',
                        ('off_team_exception','rejection_pressure','relative_team_risk'))
    return Decision('reject','我不在隊伍內，也沒有足夠的公開證據支持同意；請提案者說明選人依據。',
                    ('off_team_default_reject','challenge_rationale'))

def choose_mission(view):
    return decide_mission(view)

def assassin_guess(view):
    """Assassin cannot read Merlin's seat. Rank PUBLIC behavior: early correctness + accuracy."""
    if view['role']!='assassin':raise ValueError('assassin only')
    allies=set(view['evil_teammates']); candidates=[s for s in range(1,8) if s not in allies]
    score={s:0.0 for s in candidates}
    evil=allies # Assassin knows its teammates.
    for e in events_by_type(view,'votes_revealed'):
        prop=last_proposal_before(view,e['seq']); team=set(prop['team']);
        bad=len(team.intersection(evil))>0
        round_no=prop['round'];
        for raw,yesno in e['payload']['votes'].items():
            s=int(raw)
            if s in score:
                if (yesno=='no' and bad) or (yesno=='yes' and not bad):
                    score[s]+= 0.9 if round_no<=2 else 0.5
                elif (yesno=='yes' and bad):
                    score[s]-=0.35
    for e in events_by_type(view,'proposal'):
        p=e['payload'];s=p['captain'];
        if s in score:
            score[s] += 0.8 if not evil.intersection(p['team']) else -0.3
    # Public allegations are observable to the assassin as well. A correct
    # accusation might expose Merlin, or might be loyal/Percival deduction.
    for e in events_by_type(view,'public_statement'):
        p=e['payload'];speaker=p['speaker'];target=p['target']
        if speaker in score:
            score[speaker]+=0.25 if target in evil else -0.15
    return max(candidates,key=lambda s:(score[s],-s)),score
