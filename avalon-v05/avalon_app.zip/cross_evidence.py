"""Explainable public-only nomination/ballot cross-checks.

Do not read roles, known evil, or teammates. A suspicious captain is evidence,
NOT a logical identification. Public, revealed ballots only.
"""
from collections import Counter,defaultdict
from math import exp, log


def evaluate(view):
    events=view['public']['public_events']
    last=None; history=[]
    for e in events:
        if e['type']=='proposal':last=e['payload']
        elif e['type']=='votes_revealed' and last:
            votes={int(s):v for s,v in e['payload']['votes'].items()}
            team=set(last['team'])
            history.append(dict(round=last['round'],attempt=last['attempt'],captain=last['captain'],team=team,
                                votes=votes,off_yes=[s for s,v in votes.items() if v=='yes' and s not in team],
                                insider_no=[s for s,v in votes.items() if v=='no' and s in team]))
    # Weighted opportunities: a captain choosing own teammate is less surprising than an independent outsider.
    picked=Counter();offers=Counter(); ties=defaultdict(list); evidence=[]; captain_signal=Counter()
    for record in history:
        c=record['captain']
        for s in range(1,8):
            if s==c:continue
            offers[s]+=1
            if s in record['team']:
                picked[s]+=1
                ties[s].append(c)
    # Captains 1,2,3 all pick 4; the record from captain 2 differs:
    # chosen teammate 4 rejects while off-team spectators approve. This is
    # a reason to INVESTIGATE captain 2, not proof captain 2 is evil.
    for h in history:
        suspicious=h['insider_no']
        if not suspicious or not h['off_yes'] or h['attempt']==5:continue
        for teammate in suspicious:
            comparators=[x for x in history if x is not h and x['round']==h['round']
                         and teammate in x['team'] and x['captain']!=h['captain'] and not x['off_yes']]
            if not comparators:continue
            # One captain signal per distinct on-team dissenter, capped below.
            severity=min(1.0,0.40+0.15*len(h['off_yes'])+0.12*min(len(comparators),2))
            captain_signal[h['captain']]+=severity
            evidence.append({'type':'dissent_vs_offteam_support','round':h['round'],
                    'attempt':h['attempt'],'captain':h['captain'],'dissenting_member':teammate,
                    'outside_approvers':h['off_yes'],
                    'other_captains':[x['captain'] for x in comparators],
                    'severity':round(severity,3),
                    'explanation':f'{teammate}號曾被其他隊長選中，但在{h["captain"]}號提案時場內反對；'
                                  f'同時{h["off_yes"]}場外同意，需質問{h["captain"]}號選人及支持依據。'})
    return {'selected_count':dict(picked),'selection_opportunities':dict(offers),
            'selected_by':dict(ties),'captain_signal':dict(captain_signal), 'cross_flags':evidence}


def adjusted_probability(view, candidate, probability):
    data=evaluate(view)
    if candidate==view['seat'] or view['role']=='merlin':return probability
    severity=min(1.4,data['captain_signal'].get(candidate,0))
    if not severity:return probability
    p=min(.999,max(.001, probability))
    # Evidence is capped to avoid uncalibrated overconfidence and correlation.
    z=log(p/(1-p))+0.65*severity
    return 1/(1+exp(-z))
