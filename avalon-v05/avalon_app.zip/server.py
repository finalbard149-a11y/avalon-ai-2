"""Avalon v0.5 local-first browser chat bridge.
Not production hosting: sessions live in-process, no authentication or persistence.
"""
from __future__ import annotations
from dataclasses import dataclass,field
import json,os,re,secrets,time,hmac,base64
from pathlib import Path
from typing import Any
from fastapi import FastAPI,HTTPException,Request
from fastapi.responses import FileResponse,PlainTextResponse
from pydantic import BaseModel,Field
from match import Match
from engine import RuleViolation
from agents import assassin_guess, PERSONAS
from dialogue import Conversation, fallback_speech, llm_speech, public_incidents, direct_question
from groupchat import TableDynamics, choose_speakers, vote_dispute

ROOT=Path(__file__).resolve().parent
app=FastAPI(title='Avalon v0.7 Living Roundtable')
SESSIONS:dict[str,'Session']={}
SESSION_BIRTH:dict[str,float]={}
SESSION_TTL_SECONDS=6*60*60

@app.middleware('http')
async def require_password_and_no_cache(request:Request,call_next):
    # The secret is configured only server-side in Railway; NEVER embed in HTML or JS.
    password=os.environ.get('AVALON_ACCESS_PASSWORD','')
    if not password or len(password)<16:
        return PlainTextResponse('Private deployment not configured',status_code=503)
    auth=request.headers.get('authorization','')
    valid=False
    if auth.startswith('Basic '):
        try:
            credential=base64.b64decode(auth[6:],validate=True).decode('utf-8')
            user,sep,supplied=credential.partition(':')
            valid=bool(sep) and hmac.compare_digest(user,'avalon') and hmac.compare_digest(supplied,password)
        except (ValueError,UnicodeDecodeError):
            pass
    if not valid:
        return PlainTextResponse('Authentication required',status_code=401,headers={'WWW-Authenticate':'Basic realm="Avalon Private Test", charset="UTF-8"','Cache-Control':'no-store'})
    response=await call_next(request)
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'"
    return response


@dataclass
class Session:
    match:Match
    talk:Conversation=field(default_factory=Conversation)
    dynamics:TableDynamics=field(default_factory=TableDynamics)
    mode:str='fallback'
    evil_revealed:bool=False
    evil_discussion:list[dict[str,Any]]=field(default_factory=list)
    evil_recommendations:dict[int,int]=field(default_factory=dict)

class Create(BaseModel):
    seat:int=Field(default=3,ge=1,le=7)
    role:str='percival'
    seed:int|None=None
class Chat(BaseModel):
    session:str
    text:str=Field(min_length=1,max_length=1500)
    target:int|None=Field(default=None,ge=1,le=7)
class Team(BaseModel):
    session:str
    team:list[int]
class Vote(BaseModel):
    session:str
    approve:bool
class Mission(BaseModel):
    session:str
    fail:bool=False
class Action(BaseModel):
    session:str
    target:int|None=None

def get(sid:str)->Session:
    if sid in SESSIONS and time.time()-SESSION_BIRTH.get(sid,0)>SESSION_TTL_SECONDS:
        SESSIONS.pop(sid,None);SESSION_BIRTH.pop(sid,None)
    if sid not in SESSIONS:raise HTTPException(404,'找不到對局，或伺服器已重新啟動')
    return SESSIONS[sid]

def config(m:Match):
    m.nomination_model_enabled=True
    m.behavioral_evidence_enabled=True
    m.behavior_weight_multiplier=2.0
    m.cross_evidence_enabled=True
    m.percival_mutual_inference_enabled=True
    m.v045_enabled=True
    m.v046_enabled=True
    m.v046_merlin_cover_enabled=True
    m.v046_percival_veto_enabled=True
    m.v06_merlin_early_cover_enabled=True

def state(s:Session)->dict[str,Any]:
    m=s.match
    pub=m.public(); own=m.view()
    # Strictly no full role table unless finished.
    return {'public':pub,'your_role':own['role'],'your_seat':m.human_seat,
       'your_private':{'known_evil':own['known_evil'],'evil_teammates':own['evil_teammates'],
                       'merlin_or_morgana':own['merlin_or_morgana']},
       'dialogue':s.talk.messages[-120:], 'table_dynamics':{'frictions':[{'a':a,'b':b,'count':v} for (a,b),v in s.dynamics.frictions.items()]}, 'mode':s.mode,'npc_names':{str(k):v[0] for k,v in PERSONAS.items()},
       'audit':m.audit() if m.game.phase=='finished' else None,
       'evil_revealed':s.evil_revealed,
       'evil_seats':sorted(k for k,r in m.game.roles.items() if r.value in ('assassin','minion','morgana')) if s.evil_revealed else [],
       'evil_roles':{str(k):r.value for k,r in m.game.roles.items() if r.value in ('assassin','minion','morgana')} if s.evil_revealed else {},
       'evil_discussion':s.evil_discussion,
       'history':make_history(m),
       'finale':finale(s) if m.game.phase=='finished' else None}

def make_history(m:Match)->list[dict[str,Any]]:
    """Public event stream joined into chronological proposal/vote/mission records.
    Never expose a card->seat mapping or unrevealed ballots."""
    events=m.game.public_view()['public_events']
    rows=[];current=None
    for ev in events:
        t=ev['type'];v=ev['payload']
        if t=='proposal':
            current={'round':v['round'],'attempt':v['attempt'],'captain':v['captain'],
                     'team':v['team'],'votes':None,'passed':None,'mission':None}
            rows.append(current)
        elif t=='votes_revealed' and current is not None:
            current['votes']={str(k):val for k,val in v['votes'].items()}
            current['passed']=v['passed'];current['yes']=v['yes']
        elif t=='mission_revealed' and current is not None:
            current['mission']={'success':v['succeeded'],'success_cards':v['success_cards'],
                                'fail_cards':v['fail_cards'],'threshold':v['threshold']}
    return rows


def finale(s:Session)->dict[str,Any]:
    m=s.match
    if m.game.phase!='finished':return {}
    assassination=next((e['payload'] for e in reversed(m.game.events) if e['type']=='assassination'),None)
    finish=next((e['payload'] for e in reversed(m.game.events) if e['type']=='finished'),{})
    declaration=next((e['payload'] for e in reversed(m.game.events) if e['type']=='assassin_declaration'),None)
    return {'winner':m.game.final_result,'reason':finish.get('reason'),'declaration':declaration,
            'roles':{str(k):r.value for k,r in sorted(m.game.roles.items())},
            'assassination':assassination,
            'role_nonce':m.game.game_nonce,'role_commitment':m.game.role_commitment}


def _evil_candidates(m:Match)->list[int]:
    evil=set(next(m.seat_view(k)['evil_teammates'] for k,r in m.game.roles.items() if r.value=='assassin'))
    return [k for k in range(1,8) if k not in evil]


def evil_evidence(m:Match, seat:int, candidates:list[int])->dict[int,list[str]]:
    """Evidence available to an evil seat, no Merlin role table or risk decimals."""
    view=m.seat_view(seat);history=public_incidents(view,120)
    allies=set(view['evil_teammates']);result={k:[] for k in candidates}
    for ev in history:
        if ev['kind']=='vote':
            team=set(ev['team']);contains_bad=bool(team.intersection(allies))
            for candidate in candidates:
                ballot=ev['votes'].get(str(candidate))
                if ((ballot=='no' and contains_bad) or (ballot=='yes' and not contains_bad)):
                    result[candidate].append(f'第{ev["round"]}輪第{ev["attempt"]}次，{candidate}號投了{"反對" if ballot=="no" else "同意"}，隊伍{sorted(team)}')
        elif ev['kind']=='mission':
            for candidate in candidates:
                if candidate in ev['team'] and ev['fail_cards']==0:
                    result[candidate].append(f'{candidate}號參與了零失敗牌的隊伍{ev["team"]}')
    return {k:v[-4:] for k,v in result.items()}


def _evil_line(s:Session,seat:int,guess:int,scores:dict)->tuple[str,int]:
    """Both words and recommendation come from one validated decision.
    Never generate prose with one recommendation and save a different value."""
    m=s.match;view=m.seat_view(seat)
    candidates=_evil_candidates(m)
    facts=evil_evidence(m,seat,candidates)
    previous=s.evil_discussion[-4:]
    rival=next((int(p['suggestion']) for p in reversed(previous) if p['suggestion']!=guess),None)
    if rival is None:rival=next((k for k in sorted(candidates,key=lambda x:(-scores[x],x)) if k!=guess),guess)
    pos=facts.get(guess) or []
    evidence=pos[-1] if pos else f'{guess}號在公開投票中沒有明顯的自相矛盾'
    opening=('我的第一個人選' if not previous else '我聽完前面意見後的選擇')
    fallback=f'{opening}是{guess}號。{evidence}；但{rival}號也不能排除，我想比較兩人在關鍵提案的立場。'
    if s.mode!='llm' or s.talk.llm_used>=80:return fallback,guess
    try:
        from openai import OpenAI
        prompt=('你是七人阿瓦隆邪惡陣營的'+str(seat)+'號，個性是'+PERSONAS[seat][1]+'。'
            '現在三次任務成功，邪惡陣營公開身分並密議梅林。'
            '你只能使用真正發生的公開投票、組隊、任務結果以及邪惡隊友合法知識。'
            '其他好人中誰是梅林仍未知，絕不能讀取真正身分。'
            '此次必須比較至少兩個候選人，引用至少一條明確事件。'
            '要回應前一位邪惡隊友提出的假設，可以同意也可以反駁，但不能全部照抄。'
            '不要使用分數、小數點、系統評估、模型分析、機率值，也不要自稱已經知道梅林。'
            '請只輸出JSON，格式為 {"suggestion":整數座號,"speech":"最多三句繁體中文口語推理"}。'
            'speech 最後一句一定要用「我建議刺殺X號」明確結尾，且 X 必須等於 suggestion。'
            '候選只許從合法候選座位選。')
        legal={'my_role':view['role'],'allies':view['evil_teammates'],
               'candidates':candidates,'candidate_evidence':facts,
               'previous_arguments':previous,'baseline_preference':guess,
               'previous_votes':public_incidents(view,35)}
        result=OpenAI(timeout=18,max_retries=0).chat.completions.create(
            model=os.getenv('AVALON_LLM_MODEL','gpt-4o-mini'),
            messages=[{'role':'system','content':prompt},{'role':'user','content':json.dumps(legal,ensure_ascii=False)}],
            response_format={'type':'json_object'},temperature=0.6,max_tokens=350)
        s.talk.llm_used+=1
        obj=json.loads(result.choices[0].message.content or '{}')
        choice=int(obj['suggestion']);speech=str(obj['speech']).strip()
        if choice not in candidates or len(speech)>900 or len(speech)<15:
            raise ValueError('Invalid suggestion')
        if re.search(r'風險分數|風險評分|系統評分|模型分析|\d+\.\d+分',speech):
            raise ValueError('Internal evaluation leaked')
        # Force consistency at the server boundary: ignore contradictory output.
        if not speech.endswith(f'我建議刺殺{choice}號'):
            raise ValueError('Speech and structured suggestion diverged')
        return speech,choice
    except Exception:
        return fallback,guess

def out(s:Session, result:Any=None):
    x=state(s)
    if result is not None:x['result']=result
    return x

@app.get('/')
def index():return FileResponse(ROOT/'static'/'index.html')

@app.post('/api/new')
def new(req:Create):
    try:
        # Avoid unbounded in-memory sessions during private testing.
        now=time.time()
        for old,birth in list(SESSION_BIRTH.items()):
            if now-birth>SESSION_TTL_SECONDS:
                SESSION_BIRTH.pop(old,None);SESSIONS.pop(old,None)
        if len(SESSIONS)>=20:raise HTTPException(429,'測試對局數已滿，請稍後再試')
        m=Match.create(req.seat,req.role,req.seed);config(m)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    sid=secrets.token_urlsafe(24)
    session=Session(m,mode='llm' if os.getenv('OPENAI_API_KEY') else 'fallback')
    SESSIONS[sid]=session
    SESSION_BIRTH[sid]=time.time()
    return {'session':sid,**out(session)}

@app.get('/api/state/{sid}')
def status(sid:str):return out(get(sid))

@app.post('/api/chat')
def chat(req:Chat):
    s=get(req.session);m=s.match
    if m.game.phase=='finished':raise HTTPException(400,'對局已結束')
    if req.target==m.human_seat:raise HTTPException(400,'不能指定自己為 NPC')
    seq=len(m.game.events)
    # Literal speech is untrusted; never sent to the game-rule engine as commands.
    s.talk.append(m.human_seat,req.text,'human',seq)
    # Bounded player testimony for dialogue continuity, not as proof of identities.
    if hasattr(m.game,'_log'):
        m.game._log('chat_statement',{'speaker':m.human_seat,'text':req.text[:1500]})
    # ONLY fact-checked challenges, never free-form allegations, change future
    # loyalist strategy. Never override fifth-attempt or secret-role logic.
    if any(word in req.text for word in ('為什麼','為何','怎麼','自己提','自己組')) and any(word in req.text for word in ('反對','不同意','否決')):
        for target in {int(x) for x in re.findall(r'([1-7])\s*號',req.text)}:
            relevant=[h for h in make_history(m) if h['captain']==target and h['votes'] and h['votes'].get(str(target))=='no']
            if relevant:
                m.discussion_flags.add(target)
                m.game._log('verified_discussion_challenge',{'speaker':m.human_seat,'target':target,
                    'round':relevant[-1]['round'],'attempt':relevant[-1]['attempt'],
                    'basis':'captain_rejected_own_proposal'})
    s.dynamics.note(m.human_seat,req.text)
    targets=choose_speakers(m.human_seat,req.text,m.public(),s.dynamics,req.target)
    generated=[]
    prompt=req.text
    for seat,intent in targets:
        view=m.seat_view(seat)
        if s.mode=='llm' and s.talk.llm_used<80:
            try:
                sentence=llm_speech(view,prompt,s.talk.visible_for(seat),
                    s.talk.private_memory[seat],intent=intent,table_context=s.dynamics.view(seat))
                mode='llm';s.talk.llm_used+=1
            except Exception:
                sentence=fallback_speech(view,prompt,intent=intent);mode='fallback-error'
        else:
            sentence=fallback_speech(view,prompt,intent=intent);mode='fallback'
        direct=direct_question(view,prompt)
        if direct and ('為何' in prompt or '為什麼' in prompt or '自己提' in prompt) and intent=='answer':
            sentence=direct if mode!='llm' else direct+' '+sentence[:300]
        msg=s.talk.append(seat,sentence,mode,seq)
        s.dynamics.note(seat,sentence)
        if hasattr(m.game,'_log'):
            m.game._log('chat_statement',{'speaker':seat,'text':sentence[:900]})
        generated.append(msg)
        prompt=f'{seat}號剛才說：「{sentence[:450]}」。你要{ {"challenge":"質疑或反駁", "rebut":"回應剛才的質疑", "interject":"自然插話", "answer":"回答"}[intent] }。原本玩家發言：「{req.text[:350]}」'
    return out(s,{'replies':generated})

@app.post('/api/advance')
def advance(req:Action):
    s=get(req.session);m=s.match
    try:
        if m.game.phase=='proposal':
            if m.game.captain==m.human_seat:raise RuleViolation('輪到你當隊長，請自行提案')
            result=m.auto_propose_if_npc()
        elif m.game.phase=='mission':
            if m.human_seat in (m.game.proposal or []):raise RuleViolation('請先提交你的任務牌')
            result=m.auto_mission_if_no_human()
        elif m.game.phase=='assassination':raise RuleViolation('請先讓邪惡現身、進行討論，才能選擇刺殺')
        else:raise RuleViolation('這個階段不能自動推進；請自行投票')
        return out(s,result)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))

@app.post('/api/propose')
def propose(req:Team):
    s=get(req.session)
    try:s.match.human_propose(req.team)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,{'team':req.team})

@app.post('/api/vote')
def vote(req:Vote):
    s=get(req.session)
    try:result=s.match.human_vote(req.approve)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    # Event-based table disagreement. Every line refers to a revealed ballot;
    # it can be challenged later and never exposes unrevealed votes.
    rows=make_history(s.match)
    if rows and rows[-1].get('votes'):
        turns=vote_dispute(rows,s.match.human_seat)
        for i,(speaker,line,kind) in enumerate(turns):
            seq=len(s.match.game.events)
            # The initial provocation is an audited public fact. A later reply
            # may be generated from the responding seat's own legal view.
            mode='npc-'+kind
            if i>0 and s.mode=='llm' and s.talk.llm_used<80:
                try:
                    preceding=turns[i-1]
                    situation=f'{preceding[0]}號剛才說：「{preceding[1]}」。你要直接回應他的質問或反擊，只談公開已發生的事。'
                    line=llm_speech(s.match.seat_view(speaker),situation,
                        s.talk.visible_for(speaker),s.talk.private_memory[speaker],
                        intent='rebut',table_context=s.dynamics.view(speaker))
                    s.talk.llm_used+=1
                    mode='llm-spontaneous'
                except Exception:
                    pass
            s.talk.append(speaker,line,mode,seq)
            s.dynamics.note(speaker,line)
            s.match.game._log('chat_statement',{'speaker':speaker,'text':line[:900]})
    return out(s,result)

@app.post('/api/mission')
def mission(req:Mission):
    s=get(req.session)
    try:result=s.match.human_mission(req.fail)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    if s.match.game.phase!='finished':
        last=next((r for r in reversed(make_history(s.match)) if r.get('mission')),None)
        if last and last['mission']['fail_cards']:
            speaker=next((x for x in range(1,8) if x!=s.match.human_seat and x not in last['team']),None)
            if speaker:
                line=f'剛剛{last["team"]}出了{last["mission"]["fail_cards"]}張失敗牌。先不要急著認定所有人都壞，我想問問選這隊的理由。'
                seq=len(s.match.game.events)
                s.talk.append(speaker,line,'npc-provocation',seq)
                s.dynamics.note(speaker,line)
                s.match.game._log('chat_statement',{'speaker':speaker,'text':line})
    return out(s,result)

@app.post('/api/evil-reveal')
def evil_reveal(req:Action):
    s=get(req.session);m=s.match
    if m.game.phase!='assassination':raise HTTPException(400,'尚未進入刺殺階段')
    if not s.evil_revealed:
        s.evil_revealed=True
        m.game._log('evil_reveal',{'evil_seats':sorted(k for k,r in m.game.roles.items() if r.value in ('assassin','morgana','minion'))})
    return out(s,{'evil_revealed':True})

@app.post('/api/evil-discuss')
def evil_discuss(req:Action):
    s=get(req.session);m=s.match
    if m.game.phase!='assassination' or not s.evil_revealed:raise HTTPException(400,'請先讓邪惡玩家現身')
    evil=sorted(k for k,r in m.game.roles.items() if r.value in ('assassin','morgana','minion'))
    if len(s.evil_discussion)>=6:raise HTTPException(400,'討論已完成，請進行刺殺')
    seat=evil[len(s.evil_discussion)%len(evil)]
    if seat==m.human_seat:
        # A human evil participant supplies their own advice; no invented NPC speech.
        return out(s,{'human_evil_turn':True,'seat':seat})
    assassin=next(k for k,r in m.game.roles.items() if r.value=='assassin')
    _,scores=assassin_guess(m.seat_view(assassin))
    candidates=_evil_candidates(m)
    # Each seat considers same public evidence but personality-dependent tie break;
    # all recommendations are committed before target selection.
    ranked=sorted(candidates,key=lambda k:(-scores[k],abs(k-seat),k))
    # Different evil players may favor a competing candidate if the public evidence is close.
    # This is a preference based on legal candidate scores, not on hidden Merlin identity.
    guess=ranked[1] if seat!=assassin and len(ranked)>1 and scores[ranked[0]]-scores[ranked[1]]<1.1 and seat%2==0 else ranked[0]
    text,guess=_evil_line(s,seat,guess,scores)
    msg={'seat':seat,'text':text,'suggestion':guess,'round':len(s.evil_discussion)//len(evil)+1}
    s.evil_discussion.append(msg);s.evil_recommendations[seat]=guess
    m.game._log('evil_discussion',msg)
    return out(s,{'discussion':msg})

class EvilSpeak(BaseModel):
    session:str
    text:str=Field(min_length=1,max_length=1200)
    suggestion:int=Field(ge=1,le=7)

@app.post('/api/evil-speak')
def evil_speak(req:EvilSpeak):
    s=get(req.session);m=s.match
    if m.game.phase!='assassination' or not s.evil_revealed or m.game.roles[m.human_seat].value not in ('assassin','morgana','minion'):
        raise HTTPException(400,'只有邪惡玩家可以參與刺殺密議')
    evil=sorted(k for k,r in m.game.roles.items() if r.value in ('assassin','morgana','minion'))
    if len(s.evil_discussion)>=6 or evil[len(s.evil_discussion)%len(evil)]!=m.human_seat:raise HTTPException(400,'尚未輪到你發言')
    if req.suggestion not in _evil_candidates(m):raise HTTPException(400,'不能選已知邪惡隊友')
    msg={'seat':m.human_seat,'text':req.text,'suggestion':req.suggestion,'round':len(s.evil_discussion)//len(evil)+1}
    s.evil_discussion.append(msg);s.evil_recommendations[m.human_seat]=req.suggestion
    m.game._log('evil_discussion',msg)
    return out(s,{'discussion':msg})

@app.post('/api/evil-finalize')
def evil_finalize(req:Action):
    s=get(req.session);m=s.match
    if m.game.phase!='assassination' or not s.evil_revealed or len(s.evil_discussion)<3:raise HTTPException(400,'至少完成三名邪惡玩家的一輪討論')
    assassin=next(k for k,r in m.game.roles.items() if r.value=='assassin')
    if assassin==m.human_seat:
        if req.target is None:raise HTTPException(400,'你是刺客，請自行選擇刺殺目標')
        target=req.target
    else:
        original,scores=assassin_guess(m.seat_view(assassin))
        votes={k:0 for k in scores}
        for k in s.evil_recommendations.values():
            if k in votes:votes[k]+=1
        target=max(scores,key=lambda k:(scores[k]+0.45*votes[k],-k))
    assassin_view=m.seat_view(assassin)
    facts=evil_evidence(m,assassin,_evil_candidates(m))
    evidence=(facts.get(target) or ['比較各候選人過往提案、投票與隊伍表現'])[-1]
    declaration={'assassin':assassin,'target':target,
                 'text':f'我決定刺殺{target}號。關鍵理由：{evidence}。',
                 'supporting_recommendations':dict(s.evil_recommendations)}
    m.game._log('assassin_declaration',declaration)
    try:
        result=m.assassinate(target)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,{'assassination':result,'declaration':declaration})
