"""Avalon v0.5 local-first browser chat bridge.
Not production hosting: sessions live in-process, no authentication or persistence.
"""
from __future__ import annotations
from dataclasses import dataclass,field
import json,os,re,secrets,time,hmac,base64
from pathlib import Path
from typing import Any
from fastapi import FastAPI,HTTPException,Request
from fastapi.responses import FileResponse,PlainTextResponse
from pydantic import BaseModel,Field
from match import Match
from engine import RuleViolation
from agents import PERSONAS
from dialogue import Conversation, fallback_speech, llm_speech

ROOT=Path(__file__).resolve().parent
app=FastAPI(title='Avalon v0.5 Conversational Prototype')
SESSIONS:dict[str,'Session']={}
SESSION_BIRTH:dict[str,float]={}
SESSION_TTL_SECONDS=6*60*60

@app.middleware('http')
async def require_password_and_no_cache(request:Request,call_next):
    # The secret is configured only server-side in Railway; NEVER embed in HTML or JS.
    password=os.environ.get('AVALON_ACCESS_PASSWORD','')
    if not password or len(password)<16:
        return PlainTextResponse('Private deployment not configured',status_code=503)
    auth=request.headers.get('authorization','')
    valid=False
    if auth.startswith('Basic '):
        try:
            credential=base64.b64decode(auth[6:],validate=True).decode('utf-8')
            user,sep,supplied=credential.partition(':')
            valid=bool(sep) and hmac.compare_digest(user,'avalon') and hmac.compare_digest(supplied,password)
        except (ValueError,UnicodeDecodeError):
            pass
    if not valid:
        return PlainTextResponse('Authentication required',status_code=401,headers={'WWW-Authenticate':'Basic realm="Avalon Private Test", charset="UTF-8"','Cache-Control':'no-store'})
    response=await call_next(request)
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'"
    return response


@dataclass
class Session:
    match:Match
    talk:Conversation=field(default_factory=Conversation)
    mode:str='fallback'

class Create(BaseModel):
    seat:int=Field(default=3,ge=1,le=7)
    role:str='percival'
    seed:int|None=None
class Chat(BaseModel):
    session:str
    text:str=Field(min_length=1,max_length=1500)
    target:int|None=Field(default=None,ge=1,le=7)
class Team(BaseModel):
    session:str
    team:list[int]
class Vote(BaseModel):
    session:str
    approve:bool
class Mission(BaseModel):
    session:str
    fail:bool=False
class Action(BaseModel):
    session:str
    target:int|None=None

def get(sid:str)->Session:
    if sid in SESSIONS and time.time()-SESSION_BIRTH.get(sid,0)>SESSION_TTL_SECONDS:
        SESSIONS.pop(sid,None);SESSION_BIRTH.pop(sid,None)
    if sid not in SESSIONS:raise HTTPException(404,'找不到對局，或伺服器已重新啟動')
    return SESSIONS[sid]

def config(m:Match):
    m.nomination_model_enabled=True
    m.behavioral_evidence_enabled=True
    m.behavior_weight_multiplier=2.0
    m.cross_evidence_enabled=True
    m.percival_mutual_inference_enabled=True
    m.v045_enabled=True
    m.v046_enabled=True
    m.v046_merlin_cover_enabled=True
    m.v046_percival_veto_enabled=True

def state(s:Session)->dict[str,Any]:
    m=s.match
    pub=m.public(); own=m.view()
    # Strictly no full role table unless finished.
    return {'public':pub,'your_role':own['role'],'your_seat':m.human_seat,
       'your_private':{'known_evil':own['known_evil'],'evil_teammates':own['evil_teammates'],
                       'merlin_or_morgana':own['merlin_or_morgana']},
       'dialogue':s.talk.messages[-100:], 'mode':s.mode,'npc_names':{str(k):v[0] for k,v in PERSONAS.items()},
       'audit':m.audit() if m.game.phase=='finished' else None}

def out(s:Session, result:Any=None):
    x=state(s)
    if result is not None:x['result']=result
    return x

@app.get('/')
def index():return FileResponse(ROOT/'static'/'index.html')

@app.post('/api/new')
def new(req:Create):
    try:
        # Avoid unbounded in-memory sessions during private testing.
        now=time.time()
        for old,birth in list(SESSION_BIRTH.items()):
            if now-birth>SESSION_TTL_SECONDS:
                SESSION_BIRTH.pop(old,None);SESSIONS.pop(old,None)
        if len(SESSIONS)>=20:raise HTTPException(429,'測試對局數已滿，請稍後再試')
        m=Match.create(req.seat,req.role,req.seed);config(m)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    sid=secrets.token_urlsafe(24)
    session=Session(m,mode='llm' if os.getenv('OPENAI_API_KEY') else 'fallback')
    SESSIONS[sid]=session
    SESSION_BIRTH[sid]=time.time()
    return {'session':sid,**out(session)}

@app.get('/api/state/{sid}')
def status(sid:str):return out(get(sid))

@app.post('/api/chat')
def chat(req:Chat):
    s=get(req.session);m=s.match
    if m.game.phase=='finished':raise HTTPException(400,'對局已結束')
    if req.target==m.human_seat:raise HTTPException(400,'不能指定自己為 NPC')
    seq=len(m.game.events)
    # Literal speech is untrusted; never sent to the game-rule engine as commands.
    s.talk.append(m.human_seat,req.text,'human',seq)
    matches=re.findall(r'([1-7])\s*號',req.text)
    target=req.target if req.target is not None else (int(matches[0]) if matches and int(matches[0])!=m.human_seat else None)
    targets=[target] if target else [seat for seat in (m.game.captain,1,2,4,5,6,7) if seat!=m.human_seat][:2]
    # Up to 2 speakers per user turn to bound latency/cost.
    targets=list(dict.fromkeys(t for t in targets if t!=m.human_seat))[:2]
    generated=[]
    for seat in targets:
        view=m.seat_view(seat)
        if s.mode=='llm':
            try:
                sentence=llm_speech(view,req.text,s.talk.visible_for(seat),s.talk.private_memory[seat])
                mode='llm';s.talk.llm_used+=1
            except Exception:
                sentence=fallback_speech(view,req.text);mode='fallback-error'
        else:
            sentence=fallback_speech(view,req.text);mode='fallback'
        generated.append(s.talk.append(seat,sentence,mode,seq))
    return out(s,{'replies':generated})

@app.post('/api/advance')
def advance(req:Action):
    s=get(req.session);m=s.match
    try:
        if m.game.phase=='proposal':
            if m.game.captain==m.human_seat:raise RuleViolation('輪到你當隊長，請自行提案')
            result=m.auto_propose_if_npc()
        elif m.game.phase=='mission':
            if m.human_seat in (m.game.proposal or []):raise RuleViolation('請先提交你的任務牌')
            result=m.auto_mission_if_no_human()
        elif m.game.phase=='assassination':result=m.assassinate(req.target)
        else:raise RuleViolation('這個階段不能自動推進；請自行投票')
        return out(s,result)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))

@app.post('/api/propose')
def propose(req:Team):
    s=get(req.session)
    try:s.match.human_propose(req.team)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,{'team':req.team})

@app.post('/api/vote')
def vote(req:Vote):
    s=get(req.session)
    try:result=s.match.human_vote(req.approve)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,result)

@app.post('/api/mission')
def mission(req:Mission):
    s=get(req.session)
    try:result=s.match.human_mission(req.fail)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,result)
