"""Avalon v0.5 local-first browser chat bridge.
Not production hosting: sessions live in-process, no authentication or persistence.
"""
from __future__ import annotations
from dataclasses import dataclass,field
import json,os,re,secrets,time,hmac,base64
from pathlib import Path
from typing import Any
from fastapi import FastAPI,HTTPException,Request
from fastapi.responses import FileResponse,PlainTextResponse
from pydantic import BaseModel,Field
from match import Match
from engine import RuleViolation
from agents import assassin_guess, PERSONAS
from dialogue import Conversation, fallback_speech, llm_speech

ROOT=Path(__file__).resolve().parent
app=FastAPI(title='Avalon v0.5 Conversational Prototype')
SESSIONS:dict[str,'Session']={}
SESSION_BIRTH:dict[str,float]={}
SESSION_TTL_SECONDS=6*60*60

@app.middleware('http')
async def require_password_and_no_cache(request:Request,call_next):
    # The secret is configured only server-side in Railway; NEVER embed in HTML or JS.
    password=os.environ.get('AVALON_ACCESS_PASSWORD','')
    if not password or len(password)<16:
        return PlainTextResponse('Private deployment not configured',status_code=503)
    auth=request.headers.get('authorization','')
    valid=False
    if auth.startswith('Basic '):
        try:
            credential=base64.b64decode(auth[6:],validate=True).decode('utf-8')
            user,sep,supplied=credential.partition(':')
            valid=bool(sep) and hmac.compare_digest(user,'avalon') and hmac.compare_digest(supplied,password)
        except (ValueError,UnicodeDecodeError):
            pass
    if not valid:
        return PlainTextResponse('Authentication required',status_code=401,headers={'WWW-Authenticate':'Basic realm="Avalon Private Test", charset="UTF-8"','Cache-Control':'no-store'})
    response=await call_next(request)
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'"
    return response


@dataclass
class Session:
    match:Match
    talk:Conversation=field(default_factory=Conversation)
    mode:str='fallback'
    evil_revealed:bool=False
    evil_discussion:list[dict[str,Any]]=field(default_factory=list)
    evil_recommendations:dict[int,int]=field(default_factory=dict)

class Create(BaseModel):
    seat:int=Field(default=3,ge=1,le=7)
    role:str='percival'
    seed:int|None=None
class Chat(BaseModel):
    session:str
    text:str=Field(min_length=1,max_length=1500)
    target:int|None=Field(default=None,ge=1,le=7)
class Team(BaseModel):
    session:str
    team:list[int]
class Vote(BaseModel):
    session:str
    approve:bool
class Mission(BaseModel):
    session:str
    fail:bool=False
class Action(BaseModel):
    session:str
    target:int|None=None

def get(sid:str)->Session:
    if sid in SESSIONS and time.time()-SESSION_BIRTH.get(sid,0)>SESSION_TTL_SECONDS:
        SESSIONS.pop(sid,None);SESSION_BIRTH.pop(sid,None)
    if sid not in SESSIONS:raise HTTPException(404,'找不到對局，或伺服器已重新啟動')
    return SESSIONS[sid]

def config(m:Match):
    m.nomination_model_enabled=True
    m.behavioral_evidence_enabled=True
    m.behavior_weight_multiplier=2.0
    m.cross_evidence_enabled=True
    m.percival_mutual_inference_enabled=True
    m.v045_enabled=True
    m.v046_enabled=True
    m.v046_merlin_cover_enabled=True
    m.v046_percival_veto_enabled=True

def state(s:Session)->dict[str,Any]:
    m=s.match
    pub=m.public(); own=m.view()
    # Strictly no full role table unless finished.
    return {'public':pub,'your_role':own['role'],'your_seat':m.human_seat,
       'your_private':{'known_evil':own['known_evil'],'evil_teammates':own['evil_teammates'],
                       'merlin_or_morgana':own['merlin_or_morgana']},
       'dialogue':s.talk.messages[-100:], 'mode':s.mode,'npc_names':{str(k):v[0] for k,v in PERSONAS.items()},
       'audit':m.audit() if m.game.phase=='finished' else None,
       'evil_revealed':s.evil_revealed,
       'evil_seats':sorted(k for k,r in m.game.roles.items() if r.value in ('assassin','minion','morgana')) if s.evil_revealed else [],
       'evil_roles':{str(k):r.value for k,r in m.game.roles.items() if r.value in ('assassin','minion','morgana')} if s.evil_revealed else {},
       'evil_discussion':s.evil_discussion,
       'history':make_history(m),
       'finale':finale(s) if m.game.phase=='finished' else None}

def make_history(m:Match)->list[dict[str,Any]]:
    """Public event stream joined into chronological proposal/vote/mission records.
    Never expose a card->seat mapping or unrevealed ballots."""
    events=m.game.public_view()['public_events']
    rows=[];current=None
    for ev in events:
        t=ev['type'];v=ev['payload']
        if t=='proposal':
            current={'round':v['round'],'attempt':v['attempt'],'captain':v['captain'],
                     'team':v['team'],'votes':None,'passed':None,'mission':None}
            rows.append(current)
        elif t=='votes_revealed' and current is not None:
            current['votes']={str(k):val for k,val in v['votes'].items()}
            current['passed']=v['passed'];current['yes']=v['yes']
        elif t=='mission_revealed' and current is not None:
            current['mission']={'success':v['succeeded'],'success_cards':v['success_cards'],
                                'fail_cards':v['fail_cards'],'threshold':v['threshold']}
    return rows


def finale(s:Session)->dict[str,Any]:
    m=s.match
    if m.game.phase!='finished':return {}
    assassination=next((e['payload'] for e in reversed(m.game.events) if e['type']=='assassination'),None)
    finish=next((e['payload'] for e in reversed(m.game.events) if e['type']=='finished'),{})
    return {'winner':m.game.final_result,'reason':finish.get('reason'),
            'roles':{str(k):r.value for k,r in sorted(m.game.roles.items())},
            'assassination':assassination,
            'role_nonce':m.game.game_nonce,'role_commitment':m.game.role_commitment}


def _evil_candidates(m:Match)->list[int]:
    evil=set(next(m.seat_view(k)['evil_teammates'] for k,r in m.game.roles.items() if r.value=='assassin'))
    return [k for k in range(1,8) if k not in evil]


def _evil_line(s:Session,seat:int,guess:int,score:dict)->str:
    view=s.match.seat_view(seat)
    leader=sorted(score.items(),key=lambda kv:(-kv[1],kv[0]))[:2]
    rationale=f'我傾向 {guess} 號。候選評分最高的兩人是 '+ '、'.join(f'{k}號 {v:.2f}分' for k,v in leader)+'。但可能是派西維爾在掩護梅林。'
    if s.mode!='llm' or s.talk.llm_used>=80:return rationale
    try:
        from openai import OpenAI
        import json
        prompt=('你是七人阿瓦隆邪惡陣營的 '+str(seat)+' 號。現在三次任務成功，公開現身後邪惡密議刺殺梅林。'
                '用自己的合法邪惡情報和公開記錄做真實推理。不可自稱知道真梅林。'
                '不要直接宣告刺殺已結算。輸出 1 至 3 句精簡繁體中文，具體評論候選者並回應已有意見。'
                '\n私有角色視角：'+json.dumps({'role':view['role'],'evil_teammates':view['evil_teammates'],
                'public_evidence':__import__('dialogue').reason_snapshot(view),
                'candidate_scores':score,'my_preference':guess,'previous_discussion':s.evil_discussion[-4:]},ensure_ascii=False))
        answer=OpenAI(timeout=18,max_retries=0).chat.completions.create(
            model=os.getenv('AVALON_LLM_MODEL','gpt-4o-mini'),
            messages=[{'role':'system','content':prompt},{'role':'user','content':'請發言、比較梅林假設並提出你目前的刺殺對象'}],temperature=0.7,max_tokens=180)
        s.talk.llm_used+=1
        return (answer.choices[0].message.content or rationale).strip()[:900]
    except Exception:
        return rationale

def out(s:Session, result:Any=None):
    x=state(s)
    if result is not None:x['result']=result
    return x

@app.get('/')
def index():return FileResponse(ROOT/'static'/'index.html')

@app.post('/api/new')
def new(req:Create):
    try:
        # Avoid unbounded in-memory sessions during private testing.
        now=time.time()
        for old,birth in list(SESSION_BIRTH.items()):
            if now-birth>SESSION_TTL_SECONDS:
                SESSION_BIRTH.pop(old,None);SESSIONS.pop(old,None)
        if len(SESSIONS)>=20:raise HTTPException(429,'測試對局數已滿，請稍後再試')
        m=Match.create(req.seat,req.role,req.seed);config(m)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    sid=secrets.token_urlsafe(24)
    session=Session(m,mode='llm' if os.getenv('OPENAI_API_KEY') else 'fallback')
    SESSIONS[sid]=session
    SESSION_BIRTH[sid]=time.time()
    return {'session':sid,**out(session)}

@app.get('/api/state/{sid}')
def status(sid:str):return out(get(sid))

@app.post('/api/chat')
def chat(req:Chat):
    s=get(req.session);m=s.match
    if m.game.phase=='finished':raise HTTPException(400,'對局已結束')
    if req.target==m.human_seat:raise HTTPException(400,'不能指定自己為 NPC')
    seq=len(m.game.events)
    # Literal speech is untrusted; never sent to the game-rule engine as commands.
    s.talk.append(m.human_seat,req.text,'human',seq)
    matches=re.findall(r'([1-7])\s*號',req.text)
    target=req.target if req.target is not None else (int(matches[0]) if matches and int(matches[0])!=m.human_seat else None)
    targets=[target] if target else [seat for seat in (m.game.captain,1,2,4,5,6,7) if seat!=m.human_seat][:2]
    # Up to 2 speakers per user turn to bound latency/cost.
    targets=list(dict.fromkeys(t for t in targets if t!=m.human_seat))[:2]
    generated=[]
    for seat in targets:
        view=m.seat_view(seat)
        if s.mode=='llm' and s.talk.llm_used<80:
            try:
                sentence=llm_speech(view,req.text,s.talk.visible_for(seat),s.talk.private_memory[seat])
                mode='llm';s.talk.llm_used+=1
            except Exception:
                sentence=fallback_speech(view,req.text);mode='fallback-error'
        else:
            sentence=fallback_speech(view,req.text);mode='fallback'
        generated.append(s.talk.append(seat,sentence,mode,seq))
    return out(s,{'replies':generated})

@app.post('/api/advance')
def advance(req:Action):
    s=get(req.session);m=s.match
    try:
        if m.game.phase=='proposal':
            if m.game.captain==m.human_seat:raise RuleViolation('輪到你當隊長，請自行提案')
            result=m.auto_propose_if_npc()
        elif m.game.phase=='mission':
            if m.human_seat in (m.game.proposal or []):raise RuleViolation('請先提交你的任務牌')
            result=m.auto_mission_if_no_human()
        elif m.game.phase=='assassination':raise RuleViolation('請先讓邪惡現身、進行討論，才能選擇刺殺')
        else:raise RuleViolation('這個階段不能自動推進；請自行投票')
        return out(s,result)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))

@app.post('/api/propose')
def propose(req:Team):
    s=get(req.session)
    try:s.match.human_propose(req.team)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,{'team':req.team})

@app.post('/api/vote')
def vote(req:Vote):
    s=get(req.session)
    try:result=s.match.human_vote(req.approve)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,result)

@app.post('/api/mission')
def mission(req:Mission):
    s=get(req.session)
    try:result=s.match.human_mission(req.fail)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,result)

@app.post('/api/evil-reveal')
def evil_reveal(req:Action):
    s=get(req.session);m=s.match
    if m.game.phase!='assassination':raise HTTPException(400,'尚未進入刺殺階段')
    if not s.evil_revealed:
        s.evil_revealed=True
        m.game._log('evil_reveal',{'evil_seats':sorted(k for k,r in m.game.roles.items() if r.value in ('assassin','morgana','minion'))})
    return out(s,{'evil_revealed':True})

@app.post('/api/evil-discuss')
def evil_discuss(req:Action):
    s=get(req.session);m=s.match
    if m.game.phase!='assassination' or not s.evil_revealed:raise HTTPException(400,'請先讓邪惡玩家現身')
    evil=sorted(k for k,r in m.game.roles.items() if r.value in ('assassin','morgana','minion'))
    if len(s.evil_discussion)>=6:raise HTTPException(400,'討論已完成，請進行刺殺')
    seat=evil[len(s.evil_discussion)%len(evil)]
    if seat==m.human_seat:
        # A human evil participant supplies their own advice; no invented NPC speech.
        return out(s,{'human_evil_turn':True,'seat':seat})
    assassin=next(k for k,r in m.game.roles.items() if r.value=='assassin')
    _,scores=assassin_guess(m.seat_view(assassin))
    candidates=_evil_candidates(m)
    # Each seat considers same public evidence but personality-dependent tie break;
    # all recommendations are committed before target selection.
    ranked=sorted(candidates,key=lambda k:(-scores[k],abs(k-seat),k))
    # Different evil players may favor a competing candidate if the public evidence is close.
    # This is a preference based on legal candidate scores, not on hidden Merlin identity.
    guess=ranked[1] if seat!=assassin and len(ranked)>1 and scores[ranked[0]]-scores[ranked[1]]<1.1 and seat%2==0 else ranked[0]
    text=_evil_line(s,seat,guess,scores)
    msg={'seat':seat,'text':text,'suggestion':guess,'round':len(s.evil_discussion)//len(evil)+1}
    s.evil_discussion.append(msg);s.evil_recommendations[seat]=guess
    m.game._log('evil_discussion',msg)
    return out(s,{'discussion':msg})

class EvilSpeak(BaseModel):
    session:str
    text:str=Field(min_length=1,max_length=1200)
    suggestion:int=Field(ge=1,le=7)

@app.post('/api/evil-speak')
def evil_speak(req:EvilSpeak):
    s=get(req.session);m=s.match
    if m.game.phase!='assassination' or not s.evil_revealed or m.game.roles[m.human_seat].value not in ('assassin','morgana','minion'):
        raise HTTPException(400,'只有邪惡玩家可以參與刺殺密議')
    evil=sorted(k for k,r in m.game.roles.items() if r.value in ('assassin','morgana','minion'))
    if len(s.evil_discussion)>=6 or evil[len(s.evil_discussion)%len(evil)]!=m.human_seat:raise HTTPException(400,'尚未輪到你發言')
    if req.suggestion not in _evil_candidates(m):raise HTTPException(400,'不能選已知邪惡隊友')
    msg={'seat':m.human_seat,'text':req.text,'suggestion':req.suggestion,'round':len(s.evil_discussion)//len(evil)+1}
    s.evil_discussion.append(msg);s.evil_recommendations[m.human_seat]=req.suggestion
    m.game._log('evil_discussion',msg)
    return out(s,{'discussion':msg})

@app.post('/api/evil-finalize')
def evil_finalize(req:Action):
    s=get(req.session);m=s.match
    if m.game.phase!='assassination' or not s.evil_revealed or len(s.evil_discussion)<3:raise HTTPException(400,'至少完成三名邪惡玩家的一輪討論')
    assassin=next(k for k,r in m.game.roles.items() if r.value=='assassin')
    if assassin==m.human_seat:
        if req.target is None:raise HTTPException(400,'你是刺客，請自行選擇刺殺目標')
        target=req.target
    else:
        original,scores=assassin_guess(m.seat_view(assassin))
        votes={k:0 for k in scores}
        for k in s.evil_recommendations.values():
            if k in votes:votes[k]+=1
        target=max(scores,key=lambda k:(scores[k]+0.45*votes[k],-k))
    try:
        result=m.assassinate(target)
    except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
    return out(s,{'assassination':result})
