"""v0.7 public conversation scheduler.

Only public votes, missions and the public transcript are used for routing.
The scheduler has no access to game.roles, Merlin identity or numerical risk.
It chooses *who* talks; each NPC's private legal view is assembled elsewhere.
"""
from __future__ import annotations
import re
from dataclasses import dataclass,field

SEAT_RE=re.compile(r'(?<!\d)([1-7])\s*號')
DISPUTE=('為什麼','為何','怎麼','你剛','不合理','說謊','騙','矛盾','反對','同意','壞人','胡說','不信','怪','懷疑','隊伍','投票')

@dataclass
class TableDynamics:
    frictions:dict[tuple[int,int],int]=field(default_factory=dict)
    positions:dict[int,list[str]]=field(default_factory=lambda:{s:[] for s in range(1,8)})
    exchanges:int=0

    def note(self,speaker:int,text:str):
        if not 1<=speaker<=7:return
        item=text.strip()[:220]
        if item:
            self.positions[speaker].append(item)
            self.positions[speaker]=self.positions[speaker][-7:]
        if any(w in text for w in DISPUTE):
            for match in SEAT_RE.finditer(text):
                other=int(match.group(1))
                if other!=speaker:
                    key=tuple(sorted((speaker,other)))
                    self.frictions[key]=min(7,self.frictions.get(key,0)+1)
        self.exchanges+=1

    def tension(self,a:int,b:int)->int:
        return self.frictions.get(tuple(sorted((a,b))),0)

    def view(self,seat:int)->dict:
        # Publicly said text only, never private role or suspicion scores.
        return {'previous_public_positions':self.positions[seat][-5:],
                'visible_conflicts':[{'with':b if a==seat else a,'intensity':n}
                    for (a,b),n in self.frictions.items() if seat in (a,b) and n>0][-5:]}


def choose_speakers(human:int,text:str,public:dict,dynamics:TableDynamics,target:int|None=None)->list[tuple[int,str]]:
    """Choose 1–3 organic turns with different intents, not all seats every time."""
    mentioned=[int(x) for x in SEAT_RE.findall(text) if int(x)!=human]
    primary=target if target and target!=human else (mentioned[0] if mentioned else None)
    phase=public.get('phase','');captain=public.get('captain')
    if primary is None:
        primary=next((n for n in (captain,((human+dynamics.exchanges)%7)+1) if n and n!=human),1 if human!=1 else 2)
    speakers=[(primary,'answer')]
    if phase in ('finished','assassination'):return speakers
    conflict=any(w in text for w in DISPUTE)
    potential=[]
    for seat in range(1,8):
        if seat in (human,primary):continue
        score=3*dynamics.tension(seat,primary)+2*(seat in mentioned)
        if seat==captain:score+=1
        # Avoid same reactive cast every single turn, while still deterministic.
        score+=((dynamics.exchanges+seat*3)%5)/10
        potential.append((score,seat))
    potential.sort(reverse=True)
    if conflict and potential:
        challenger=potential[0][1]
        speakers.append((challenger,'challenge'))
        # In live arguments, the original target may rebut, rather than a
        # third NPC delivering a generic monologue.
        if len(text)>12 and (dynamics.exchanges+primary)%3!=0:
            speakers.append((primary,'rebut'))
    elif len(text)>18 and potential and (dynamics.exchanges+primary)%3==0:
        speakers.append((potential[0][1],'interject'))
    return speakers[:3]


def vote_dispute(history:list[dict],human:int)->list[tuple[int,str,str]]:
    """Return 0–2 fact-grounded provocations after a ballot reveal."""
    if not history or not history[-1].get('votes'):return []
    h=history[-1];v=h['votes'];captain=h['captain'];team=h['team']
    turns=[]
    if v.get(str(captain))=='no' and captain!=human:
        opponent=next((s for s in range(1,8) if s!=human and s!=captain and v.get(str(s))=='yes'),None)
        if opponent:
            turns.append((opponent,f'{captain}號，你自己提了{team}，結果自己投反對？這不就前後矛盾嗎？','provocation'))
            turns.append((captain,f'你抓我這票很合理，但我當時確實猶豫了。先別急著替我定罪，我們也看看整桌是怎麼投的。','rebut'))
            return turns
    yes=[s for s in range(1,8) if v.get(str(s))=='yes' and s!=human]
    no=[s for s in range(1,8) if v.get(str(s))=='no' and s!=human]
    if yes and no:
        speaker=no[(h['attempt']+h['round'])%len(no)]
        other=yes[(h['attempt']+speaker)%len(yes)]
        turns.append((speaker,f'{other}號，你這次投同意，但我對{team}有疑問。你到底信誰？講個具體理由吧。','provocation'))
        # Second turn is answer, not another repeated accusation.
        if (h['round']+h['attempt'])%2==0:
            turns.append((other,f'我同意不代表我能保證隊伍安全。你反對有你的理由，但也別把一張同意票直接當成身分證明。','rebut'))
    return turns
