"""Public evidence for unexplained off-team approval. Not a guilt oracle.

This evidence only becomes visible AFTER votes are revealed. We distinguish
an unexplained approval from plausible exceptions (fifth attempt, repeated
zero-fail team), and treat repeated correlated votes with diminishing weight.
No role truth, secret teammate lists, or pre-reveal ballots are read.
"""
from collections import defaultdict


def public_behavior(view):
    events=view['public']['public_events']; last=None; zero_fail=set()
    counts=defaultdict(int); challenges=[]
    for e in events:
        p=e['payload'];typ=e['type']
        if typ=='proposal':last=p
        elif typ=='votes_revealed' and last:
            team=tuple(sorted(last['team']))
            for raw,v in p['votes'].items():
                voter=int(raw)
                if v!='yes' or voter in team:continue
                exceptional=last['attempt']==5 or team in zero_fail
                if exceptional:continue
                counts[voter]+=1
                challenges.append({'voter':voter,'round':last['round'],
                   'attempt':last['attempt'],'team':list(team),
                   'observation':'未入隊卻同意，且沒有第五次提案或重複零失敗隊伍的公開例外',
                   'question':f'{voter}號，你不在 {list(team)} 裡仍投同意；請指出支持這支隊伍的具體公開證據。',
                   'caveat':'這是需要解釋的訊號，不等於邪惡身分證明'})
        elif typ=='mission_revealed' and last and p['fail_cards']==0:
            zero_fail.add(tuple(sorted(last['team'])))
    return {'counts':dict(counts),'challenges':challenges}


def behavior_penalty(view, candidate, evil_probability):
    """A gentle evidence update. Unexplained off-team approval is more likely
    under an assumed evil seat than a loyal seat, *conditional on our behavioral
    model*. We do not claim those likelihoods come from real human data.
    """
    own=view['seat']; info=public_behavior(view)
    if own==candidate or view['role']=='merlin':return evil_probability
    count=info['counts'].get(candidate,0)
    if not count:return evil_probability
    # Capped log-odds increment (not independently multiply identical votes).
    from math import log, exp
    p=max(0.001,min(0.999,evil_probability))
    multiplier = float(view.get("_behavior_weight_multiplier", 2.0))
    if not (0 <= multiplier <= 4):
        raise ValueError("behavior evidence multiplier must be within 0..4")
    # Double the v0.4.1 log-likelihood adjustment, preserving saturation/diminishing returns.
    delta=multiplier*min(1.15,0.55+0.24*(count-1))
    logit=log(p/(1-p))+delta
    return 1/(1+exp(-logit))
