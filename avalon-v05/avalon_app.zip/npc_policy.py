"""Isolated decision policy: accepts ONLY a single seat's player_view dict.

Deterministic baseline, NOT a separately running LLM. No omniscience or human-level
social reasoning yet. Decisions include an auditable public-facing explanation.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Decision:
    action: str
    reason: str
    tags: tuple[str, ...] = ()


def decide_vote(view: dict[str, Any], team: list[int]) -> Decision:
    seat = view['seat']
    role = view['role']
    public = view['public']
    mission = public['mission']
    attempt = public['attempt']
    wins_evil = public['wins_evil']
    known = set(view['known_evil'])
    on_team = seat in team

    # Lethal condition: an evil card can end the mission match now.
    # One fail needed except fourth mission (two fails needed).
    lethal = (wins_evil == 2 and mission != 4) or (wins_evil == 2 and mission == 4 and len(known.intersection(team)) >= 2)

    if role == 'merlin':
        evil_count = len(known.intersection(team))
        if evil_count and lethal:
            return Decision('reject', '公開理由：這支隊伍的風險在決勝局太高，應重新組隊。',
                            ('merlin_known_evil', 'terminal_risk', 'hard_veto'))
        if evil_count:
            return Decision('reject', '公開理由：我比較信任其他提案組合。', ('merlin_known_evil',))
        if attempt == 5:
            return Decision('approve', '公開理由：避免第五次否決直接失敗。', ('no_known_evil',))
        return Decision('approve', '公開理由：現有資訊支持這個組合。', ('no_known_evil',))

    if view['side'] == 'evil':
        evil_on_team = len(set(view['evil_teammates']).intersection(team))
        if mission == 4:
            # Need >=2 failure cards to fail this particular mission.
            approve = evil_on_team >= 2 or (on_team and attempt == 5)
        else:
            approve = evil_on_team >= 1
        return Decision('approve' if approve else 'reject',
                        '公開理由：我認為這支隊伍有值得利用的資訊。' if approve else '公開理由：我對這個組合仍有疑問。',
                        ('evil_strategy_baseline',))

    # Uninformed good player: NEVER consume hidden roles/evil membership.
    # This deliberately simple heuristic will be replaced by evidence-based beliefs.
    if on_team:
        return Decision('approve', '公開理由：我能確認自己在隊伍裡，願意承擔責任。', ('self_knowledge',))
    if attempt == 5:
        return Decision('approve', '公開理由：這是第五次提案，不能再否決。', ('fifth_proposal',))
    return Decision('reject', '公開理由：我更傾向一支包含自己的隊伍。', ('uninformed_baseline',))


def decide_mission(view: dict[str, Any]) -> Decision:
    """Only chosen team members should be asked for mission cards."""
    if view['public']['phase'] != 'mission' or view['seat'] not in (view['public']['proposal'] or []):
        raise ValueError('Player is not on an active mission')
    if view['side'] == 'good':
        return Decision('success', '正義玩家只能出成功牌。', ('rule',))
    team = view['public']['proposal']
    evil_on_team = len(set(view['evil_teammates']).intersection(team))
    mission = view['public']['mission']
    # For the 4th mission, a lone evil submission cannot make it fail.
    if mission == 4 and evil_on_team == 1:
        return Decision('success', '單獨一位邪惡不足以使第四輪失敗，選擇掩護。', ('strategic_cover',))
    return Decision('fail', '提交失敗牌以爭取邪惡陣營勝利。', ('evil_plays_to_win',))


def decide_assassination(view: dict[str, Any], public_suspicions: dict[int, float]) -> Decision:
    if view['role'] != 'assassin':
        raise ValueError('Assassin only')
    eligible = [seat for seat in range(1, 8) if seat not in view['evil_teammates']]
    if not eligible:
        raise ValueError('No valid target')
    # Deliberate explicit scoring input rather than fabricated omniscience.
    target = max(eligible, key=lambda s: (public_suspicions.get(s, 0.0), -s))
    return Decision(str(target), '依公開言行推測梅林；不是讀取真實梅林身分。', ('public_evidence_only',))
