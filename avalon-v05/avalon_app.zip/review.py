"""Generate reproducible COMPLETE chronological audits. No invented NPC conversations."""
import argparse, csv, json, random, statistics
from pathlib import Path
from match import run_automated
from agents import assassin_guess

ROLE_CN={'merlin':'梅林','percival':'派西維爾','loyal_servant':'忠臣','assassin':'刺客','morgana':'莫甘娜','minion':'邪惡爪牙'}

def make_record(seed,behavior=True):
    m=run_automated(seed=seed,behavioral_evidence_enabled=behavior)
    audit=m.audit();assert audit['ok']
    game=m.game
    decisions={(d['mission'],d['attempt'],d['seat'],d['action']):d for d in m.npc_decisions}
    by_event={}
    for trace in m.reasoning_trace:
        by_event.setdefault(trace['at_seq'],[]).append(trace)
    history=[]; prop=None
    for e in game.events:
        typ=e['type'];p=e['payload'];seq=e['seq']
        if typ=='proposal':
            prop={'round':p['round'],'attempt':p['attempt'],'captain':p['captain'],'team':p['team'], 'event_seq':seq}
            history.append(prop)
        elif typ=='votes_revealed':
            prop['votes']={str(k):v for k,v in p['votes'].items()}
            prop['passed']=p['passed'];prop['yes']=p['yes']
            prop['reason_by_seat']={str(seat):next((d['reason'] for d in m.npc_decisions if d['mission']==prop['round'] and d['attempt']==prop['attempt'] and d['seat']==seat and d['action']=='vote'),None) for seat in range(1,8)}
            # Human simulated policy is not logged by match; do not fabricate it.
            prop['reason_by_seat']['3']='（自動模擬的人類代理；本版未記錄投票時的原始理由）'
            prop['trace']=by_event.get(seq,[])
        elif typ=='mission_revealed':
            prop['mission']={'success_cards':p['success_cards'],'fail_cards':p['fail_cards'],'threshold':p['threshold'],'succeeded':p['succeeded']}
    assassin=[e['payload'] for e in game.events if e['type']=='assassination']
    score=None
    if assassin:
        seat=assassin[0]['assassin'];target,scores=assassin_guess(m.seat_view(seat))
        score={str(k):round(v,3) for k,v in scores.items()}
    return {'seed':seed,'winner':game.final_result,'reason':game.events[-1]['payload']['reason'],'roles':audit['roles'],'turns':history,'assassination':assassin[0] if assassin else None,'assassin_public_scores':score,'audit_hash':audit['final_event_hash'],'audit_ok':True}


def report(records,out):
    with (out/'all_games.json').open('w',encoding='utf-8') as f:json.dump(records,f,ensure_ascii=False,indent=2)
    with (out/'all_votes_and_missions.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(['seed','round','attempt','captain','team','passed','yes']+[f'seat{s}_vote' for s in range(1,8)]+['success_cards','fail_cards','threshold','mission_succeeded','winner'])
        for r in records:
            for t in r['turns']:
                m=t.get('mission',{})
                w.writerow([r['seed'],t['round'],t['attempt'],t['captain'],'-'.join(map(str,t['team'])),t['passed'],t['yes']]+[t['votes'][str(s)] for s in range(1,8)]+[m.get('success_cards'),m.get('fail_cards'),m.get('threshold'),m.get('succeeded'),r['winner']])
    with (out/'npc_reasoning_changes.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(['seed','round','attempt','observer','target','before_score','after_score','delta','new_question'])
        for r in records:
            for t in r['turns']:
                for trace in t.get('trace',[]):
                    questions={q['voter']:q['question'] for q in trace['new_challenges']}
                    for target in range(1,8):
                        b=trace['before_evil_scores'].get(target,trace['before_evil_scores'].get(str(target)))
                        a=trace['after_evil_scores'].get(target,trace['after_evil_scores'].get(str(target)))
                        w.writerow([r['seed'],t['round'],t['attempt'],trace['seat'],target,round(b,5),round(a,5),round(a-b,5),questions.get(target,'')])
    for r in records:
        lines=[f'# Seed {r["seed"]} 完整對局覆盤（v0.4.3）','',f'**勝方：{r["winner"]}；結束原因：{r["reason"]}**','',
          '## 賽後公開身分','',', '.join(f'{seat} 號：{ROLE_CN[role]}' for seat,role in r['roles'].items()),'',
          '以下是程式實際生成的事件、決策理由及忠臣觀察分數，不是事後編造的 NPC 對話。','']
        for t in r['turns']:
            lines += [f'## 第 {t["round"]} 輪・第 {t["attempt"]} 次提案','',
              f'**隊長 {t["captain"]}；隊伍 {", ".join(map(str,t["team"]))}**','',
              '| 玩家 | 本隊成員 | 表決 | 當時記錄理由 |','|---|---|---|---|']
            for s in range(1,8):
                v=t['votes'][str(s)];reason=t['reason_by_seat'][str(s)] or '（無已保存理由）'
                lines.append(f'| {s} | {"是" if s in t["team"] else "否"} | {"同意" if v=="yes" else "反對"} | {reason} |')
            lines += ['',f'**結果：{t["yes"]} 同意、{7-t["yes"]} 反對；{"通過" if t["passed"] else "否決"}。**','']
            if 'mission' in t:
                m=t['mission']; lines += [f'**任務：{m["success_cards"]} 張成功、{m["fail_cards"]} 張失敗；門檻 {m["threshold"]} 張失敗；{"成功" if m["succeeded"] else "失敗"}。**','']
            if t.get('trace'):
                flags=t['trace'][0].get('cross_flags',[])
                if flags:
                    lines+=['### 公開交叉比對警訊','']
                    for flag in flags:
                        lines+=['- '+flag['explanation']+'（證據訊號，不是角色身分證明）']
                    lines+=['']
                counts=t['trace'][0].get('selection_counts',{})
                if counts:
                    lines+=['**截至這次表決，其他隊長選中各玩家次數：** '+', '.join(f'{x}號 {counts.get(x,counts.get(str(x),0))} 次' for x in range(1,8)),'']
                lines += ['### 投票揭曉後：忠臣如何更新懷疑','', '| 觀察者 | 被觀察者 | 風險分數（前→後） | 新質問 |','|---|---|---|---|']
                for tr in t['trace']:
                    q={a['voter']:a['question'] for a in tr['new_challenges']}
                    targets=[s for s in range(1,8) if s!=tr['seat'] and (abs(tr['after_evil_scores'].get(str(s),tr['after_evil_scores'].get(s))-tr['before_evil_scores'].get(str(s),tr['before_evil_scores'].get(s)))>1e-6 or s in q)]
                    if not targets:lines.append(f'| {tr["seat"]} | — | 無變化 | — |')
                    for s in targets:
                        before=tr['before_evil_scores'].get(str(s),tr['before_evil_scores'].get(s));after=tr['after_evil_scores'].get(str(s),tr['after_evil_scores'].get(s))
                        lines.append(f'| {tr["seat"]} | {s} | {before:.3f} → {after:.3f} | {q.get(s,"—")} |')
                lines += ['','*分數是啟發式風險分數，不是經真實玩家資料校準的機率。*','']
        if r['assassination']:
            a=r['assassination']; lines += ['## 刺殺階段','',
              f'刺客 {a["assassin"]} 號選擇 {a["target"]} 號，{"命中梅林" if a["hit"] else "未命中梅林"}。','',
              '依公開提名與投票計算的梅林嫌疑分數：', '',
              '| 候選人 | 分數 |','|---|---:|']
            for s,score in sorted(r['assassin_public_scores'].items(),key=lambda x:-x[1]):lines.append(f'| {s} | {score:.3f} |')
            lines+=['','*目前沒有邪惡 NPC 之間的自然語言刺殺討論，這是演算法評分紀錄。*','']
        else:lines+=['## 刺殺階段','', '未進入刺殺階段。','']
        (out/f'seed_{r["seed"]}_full_review.md').write_text('\n'.join(lines),encoding='utf-8')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=300);ap.add_argument('--count',type=int,default=100);ap.add_argument('--sample',type=int,default=5);ap.add_argument('--out',default='review_output');args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    records=[make_record(seed) for seed in range(args.start,args.start+args.count)]
    sampled=random.Random(20261113).sample(records,min(args.sample,len(records)))
    report(records,out)
    # Full markdown all games is large; keep only sampled markdown + full machine-readable for 100.
    keep={r['seed'] for r in sampled}
    for r in records:
        if r['seed'] not in keep:(out/f'seed_{r["seed"]}_full_review.md').unlink()
    summary={'count':len(records),'good_wins':sum(r['winner']=='good' for r in records),'evil_wins':sum(r['winner']=='evil' for r in records),'assassinations':sum(r['assassination'] is not None for r in records),'sampled_seeds':sorted(keep),'all_audits_passed':True}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False))

if __name__=='__main__':main()
