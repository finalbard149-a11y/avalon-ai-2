"""Bayesian *hypothesis* scorer for nomination relationships, not a true-role oracle.

For each possible set of three evil seats, compute how likely observed captains'
team selections would be under explicitly assumed behavioural models. Captains
are not assumed infallible. Duplicate/copied teams are down-weighted. Never
access Game.roles or hidden data outside the requesting player's legal view.
"""
from __future__ import annotations
from itertools import combinations
from functools import lru_cache
from math import exp, log

SEATS = tuple(range(1, 8))
ALL_BAD = tuple(combinations(SEATS, 3))

@lru_cache(maxsize=None)
def team_probabilities(bad: tuple[int, ...], captain: int, size: int, mission: int):
    """P(team | assumed evil set, captain), with mixtures over good captain roles.

    This is a chosen *strategy model* (calibration required), not human data:
    Merlin favours no evil; Percival moderately favours safety; uninformed
    loyal servants prefer self-inclusion; evil captains tend to include
    themselves and avoid extra evil for single-fail missions, but favour a
    second evil on round 4 (two fails required).
    """
    b=set(bad)
    teams=list(combinations(SEATS, size))
    if captain in b:
        def weight(t):
            e=len(b.intersection(t))
            self_bonus=3.5 if captain in t else 0.05
            if mission == 4:
                return self_bonus * (5 if e>=2 else 0.18)
            return self_bonus * (7 if e==1 else 0.6 if e==2 else 0.12)
        weights=[weight(t) for t in teams]
    else:
        # Latent roles for a good captain, not certainty that captain is Merlin.
        # The 4 good seats contain one Merlin, one Percival and two loyal servants.
        def weight(t):
            e=len(b.intersection(t)); self_bonus=3.5 if captain in t else 0.25
            merlin=self_bonus * exp(-2.8*e)
            percival=self_bonus * exp(-0.9*e)
            loyal=self_bonus * exp(-0.3*e)
            return 0.25*merlin + 0.25*percival + 0.5*loyal
        weights=[weight(t) for t in teams]
    norm=sum(weights)
    return {t:w/norm for t,w in zip(teams,weights)}


def posterior(view, use_nominations=True):
    """Return per-seat P(evil | permitted private information, public evidence).

    Proposal history reweights candidate evil sets. Mission fail-card counts
    are hard constraints. No zero-fail success is treated as proof of all good.
    """
    own=view['seat']; role=view['role']; side=view['side']
    known=set(view['known_evil']); allies=set(view['evil_teammates'])
    candidate_pair=set(view['merlin_or_morgana'])
    events=view['public']['public_events']
    missions=[]; proposals=[]
    last_prop=None
    for event in events:
        t=event['type']; payload=event['payload']
        if t=='proposal':
            last_prop=payload
            proposals.append(payload)
        elif t=='mission_revealed' and last_prop:
            missions.append((set(last_prop['team']),payload['fail_cards']))
    hypotheses=[]
    log_likelihood=[]
    for evil in ALL_BAD:
        b=set(evil)
        if side=='good' and own in b: continue
        if side=='evil' and b!=allies: continue
        if role=='merlin' and b!=known: continue
        if role=='percival' and len(candidate_pair.intersection(b))!=1: continue
        if any(len(b.intersection(team))<fail_count for team,fail_count in missions): continue
        score=0.
        if use_nominations:
            seen_teams={}
            for p in proposals:
                size=len(p['team'])
                team=tuple(sorted(p['team']))
                key=(p['round'],team)
                # Copied proposals aren't independent observations.
                repetition=seen_teams.get(key,0)
                weight=1.0 if repetition==0 else 0.15
                seen_teams[key]=repetition+1
                # Capped likelihood contribution avoids overconfidence from
                # an uncalibrated behavioural model.
                prob=team_probabilities(evil,p['captain'],size,p['round'])[team]
                score+=weight*min(1.6,max(-1.6,log(prob)+3.7))
        hypotheses.append(evil);log_likelihood.append(score)
    if not hypotheses:
        raise ValueError('Public game evidence conflicts with all legal role assignments')
    maximum=max(log_likelihood)
    weights=[exp(min(100,x-maximum)) for x in log_likelihood]
    norm=sum(weights)
    probabilities={seat:sum(w for b,w in zip(hypotheses,weights) if seat in b)/norm for seat in SEATS}
    return probabilities


def nomination_explanation(view):
    """Observable evidence suitable for NPC scrutiny without hidden roles."""
    events=view['public']['public_events']
    props=[e['payload'] for e in events if e['type']=='proposal']
    counts={s:0 for s in SEATS}; offers={s:0 for s in SEATS}
    for p in props:
        captain=p['captain']; team=set(p['team'])
        for s in SEATS:
            if s!=captain:
                offers[s]+=1
                if s in team:counts[s]+=1
    posterior_probs=posterior(view)
    return {'proposals_observed':len(props),
            'selection_count':counts,
            'selection_opportunities':offers,
            'evil_probability':{s:round(posterior_probs[s],3) for s in SEATS},
            'note':'提名是可解釋但有噪聲的證據；非提名也不能直接證明邪惡。'}
