"""Interactive terminal game, one human at seat 3 by default."""
import argparse
import json
from match import Match
from engine import RuleViolation
from agents import PERSONAS

def get_choice(prompt,valid):
    while True:
        s=input(prompt).strip().lower()
        if s in valid:return s
        print('請重新輸入：',', '.join(valid))

def main():
    ap=argparse.ArgumentParser(description='七人阿瓦隆 v0.2 - 完整 CLI 對局')
    ap.add_argument('--seat',type=int,default=3)
    ap.add_argument('--role',choices=['merlin','percival','loyal_servant','assassin','morgana','minion'],default='percival')
    ap.add_argument('--seed',type=int,default=None,help='只用於可重現測試；正常遊玩不指定')
    args=ap.parse_args()
    match=Match.create(args.seat,args.role,args.seed)
    own=match.view()
    print('\n=== 七人阿瓦隆 v0.2 ===')
    print('角色承諾（請於開局保留）：',match.game.role_commitment)
    print('你是',args.seat,'號，身分：',own['role'])
    if own['known_evil']:print('梅林已知邪惡：',own['known_evil'])
    if own['merlin_or_morgana']:print('派西維爾看見的候選人：',own['merlin_or_morgana'])
    if own['evil_teammates']:print('邪惡同夥：',own['evil_teammates'])
    try:
        while match.game.phase!='finished':
            g=match.game
            if g.phase=='proposal':
                print(f'\n第 {g.round_index+1} 輪｜嘗試 {g.attempts+1}/5｜隊長 {g.captain}｜正義 {g.wins_good} : 邪惡 {g.wins_evil}')
                if g.captain == args.seat:
                    while True:
                        raw=input(f'你的提案（需 {g.public_view()["team_size"]} 人，逗號分隔座號）：')
                        try:
                            team=[int(x) for x in raw.replace('，',',').split(',')]
                            match.human_propose(team);break
                        except (ValueError,RuleViolation) as exc:print('無效隊伍：',exc)
                else:
                    result=match.auto_propose_if_npc()
                    print(f'隊長 {result["captain"]} 提案：{result["team"]}')
            elif g.phase=='voting':
                print('目前隊伍：',list(g.proposal))
                approve=get_choice('你的秘密組隊票 [y=同意/n=反對]：',{'y','n'})=='y'
                result=match.human_vote(approve)
                print('公開選票：',result['votes'],'｜同意',result['yes'],'｜', '通過' if result['passed'] else '否決')
            elif g.phase=='mission':
                if args.seat in g.proposal:
                    if own['side']=='evil':
                        fail=get_choice('你的任務牌 [s=成功/f=失敗]：',{'s','f'})=='f'
                    else:
                        print('你是正義玩家，提交成功牌。');fail=False
                    result=match.human_mission(fail)
                else:
                    print('你未入隊。其他隊員提交任務牌中……')
                    result=match.auto_mission_if_no_human()
                print('任務結果：', '成功' if result['success'] else '失敗',
                      f'｜失敗牌 {result["fails"]}｜正義 {result["wins_good"]} : 邪惡 {result["wins_evil"]}')
            elif g.phase=='assassination':
                if own['role']=='assassin':
                    target=int(get_choice('你是刺客！選擇刺殺座位 1-7：',{str(i) for i in range(1,8)}))
                    result=match.assassinate(target)
                else:
                    print('刺客正在依公開資訊推理……');result=match.assassinate()
                print('刺殺座位：',result['target'],'｜是否命中梅林：',result['hit_merlin'])
        print('\n=== 遊戲結束 ===')
        report=match.audit()
        print('獲勝陣營：',report['winner'])
        print('公布角色：',report['roles'])
        print('身分封存驗證：',report['ok'])
        path='avalon_audit.json'
        with open(path,'w',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
        print('賽後稽核紀錄：',path)
    except (EOFError,KeyboardInterrupt):
        print('\n已離開；本 CLI 暫不支援中途存檔。')

if __name__=='__main__':main()
