"""Seven-player Avalon rules referee, stdlib-only prototype.

Trust boundary: call player_view for NPC; never pass GameState or assignments to an NPC.
This is a *single-process* demonstration, not a secure multi-tenant service.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from hashlib import sha256
import json
import secrets
from typing import Any


class Role(str, Enum):
    MERLIN = 'merlin'
    PERCIVAL = 'percival'
    LOYAL = 'loyal_servant'
    ASSASSIN = 'assassin'
    MORGANA = 'morgana'
    MINION = 'minion'


EVIL = {Role.ASSASSIN, Role.MORGANA, Role.MINION}
ROLE_COUNTS = {Role.MERLIN: 1, Role.PERCIVAL: 1, Role.LOYAL: 2,
               Role.ASSASSIN: 1, Role.MORGANA: 1, Role.MINION: 1}
TEAM_SIZES = (2, 3, 3, 4, 4)


def canonical(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def digest(obj: Any) -> str:
    return sha256(canonical(obj).encode('utf-8')).hexdigest()


class RuleViolation(ValueError):
    pass


@dataclass
class Game:
    roles: dict[int, Role]
    first_captain: int = 1
    game_nonce: str = field(default_factory=lambda: secrets.token_hex(32))
    turn_index: int = 0
    round_index: int = 0
    attempts: int = 0
    wins_good: int = 0
    wins_evil: int = 0
    phase: str = 'proposal'
    proposal: tuple[int, ...] | None = None
    commitments: dict[int, dict[str, str]] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)
    final_result: str | None = None
    private_mission_proofs: list[dict[str, Any]] = field(default_factory=list)

    def __post_init__(self):
        if set(self.roles) != set(range(1, 8)):
            raise RuleViolation('Exactly seats 1..7 required')
        if any(list(self.roles.values()).count(role) != n for role, n in ROLE_COUNTS.items()):
            raise RuleViolation('Invalid role distribution')
        if self.first_captain not in self.roles:
            raise RuleViolation('Invalid initial captain')
        self._log('game_created', {'role_commitment': self.role_commitment,
                                   'first_captain': self.first_captain})

    @property
    def role_commitment(self) -> str:
        # Per-game nonce prevents dictionary reconstruction of the seven-role assignment.
        return digest({'roles': {str(k): v.value for k, v in sorted(self.roles.items())},
                       'nonce': self.game_nonce})

    @property
    def captain(self) -> int:
        return ((self.first_captain - 1 + self.turn_index) % 7) + 1

    def _log(self, typ: str, payload: dict[str, Any]) -> None:
        previous = self.events[-1]['hash'] if self.events else '0' * 64
        entry = {'seq': len(self.events), 'type': typ, 'payload': payload, 'previous_hash': previous}
        entry['hash'] = digest(entry)
        self.events.append(entry)

    def public_view(self) -> dict[str, Any]:
        return {'phase': self.phase, 'mission': self.round_index + 1,
                'attempt': self.attempts + 1, 'captain': self.captain,
                'team_size': TEAM_SIZES[min(self.round_index, 4)],
                'wins_good': self.wins_good, 'wins_evil': self.wins_evil,
                'proposal': list(self.proposal) if self.proposal else None,
                'public_events': [e for e in self.events if e['type'] not in ('sealed_ballot', 'sealed_mission')],
                'role_commitment': self.role_commitment}

    def player_view(self, seat: int) -> dict[str, Any]:
        if seat not in self.roles:
            raise RuleViolation('Invalid seat')
        role = self.roles[seat]
        known_evil = sorted(s for s, r in self.roles.items() if r in EVIL) if role == Role.MERLIN else []
        evil_teammates = sorted(s for s, r in self.roles.items() if r in EVIL) if role in EVIL else []
        percival_candidates = sorted(s for s, r in self.roles.items() if r in (Role.MERLIN, Role.MORGANA)) if role == Role.PERCIVAL else []
        return {'seat': seat, 'role': role.value, 'side': 'evil' if role in EVIL else 'good',
                'known_evil': known_evil, 'evil_teammates': evil_teammates,
                'merlin_or_morgana': percival_candidates,
                'public': self.public_view()}

    def propose(self, captain: int, seats: list[int] | tuple[int, ...]):
        if self.phase != 'proposal' or captain != self.captain:
            raise RuleViolation('Not this captain/proposal phase')
        if (len(seats) != TEAM_SIZES[self.round_index] or len(set(seats)) != len(seats)
                or any(s not in self.roles for s in seats)):
            raise RuleViolation('Invalid team size/members')
        self.proposal = tuple(sorted(seats))
        self.phase = 'voting'
        self.commitments = {}
        self._log('proposal', {'captain': captain, 'team': list(self.proposal),
                               'round': self.round_index + 1, 'attempt': self.attempts + 1})

    def _seal(self, seat: int, choice: str, salt: str, kind: str):
        if seat not in self.roles or seat in self.commitments:
            raise RuleViolation('Invalid or duplicate submission')
        if not isinstance(salt, str) or len(salt) < 16:
            raise RuleViolation('Use a high-entropy salt')
        self.commitments[seat] = {'choice': choice, 'salt': salt,
                                  'commitment': digest({'seat': seat, 'choice': choice, 'salt': salt,
                                                        'kind': kind, 'round': self.round_index + 1,
                                                        'attempt': self.attempts + 1})}
        self._log('sealed_ballot' if kind == 'vote' else 'sealed_mission',
                  {'seat': seat, 'commitment': self.commitments[seat]['commitment']})

    def vote(self, seat: int, approve: bool, salt: str | None = None):
        if self.phase != 'voting':
            raise RuleViolation('Not voting phase')
        self._seal(seat, 'yes' if approve else 'no', salt or secrets.token_hex(32), 'vote')

    def reveal_votes(self) -> dict[str, Any]:
        if self.phase != 'voting' or set(self.commitments) != set(self.roles):
            raise RuleViolation('All seven votes required')
        revealed = {s: x['choice'] for s, x in sorted(self.commitments.items())}
        yes = sum(v == 'yes' for v in revealed.values())
        passed = yes >= 4
        proofs = self._proofs()
        self._log('votes_revealed', {'votes': revealed, 'proofs': proofs,
                                    'yes': yes, 'passed': passed})
        self.commitments = {}
        if passed:
            self.phase = 'mission'
        else:
            self.attempts += 1
            self.turn_index += 1
            self.proposal = None
            if self.attempts == 5:
                self._finish('evil', 'five_rejections')
            else:
                self.phase = 'proposal'
        return {'votes': revealed, 'yes': yes, 'passed': passed,
                'next_captain': self.captain if self.phase == 'proposal' else None,
                'phase': self.phase}

    def mission_card(self, seat: int, fail: bool, salt: str | None = None):
        if self.phase != 'mission' or self.proposal is None or seat not in self.proposal:
            raise RuleViolation('Not an eligible mission member')
        if fail and self.roles[seat] not in EVIL:
            raise RuleViolation('Good players cannot fail a mission')
        self._seal(seat, 'fail' if fail else 'success', salt or secrets.token_hex(32), 'mission')

    def reveal_mission(self) -> dict[str, Any]:
        if self.phase != 'mission' or self.proposal is None or set(self.commitments) != set(self.proposal):
            raise RuleViolation('All team mission cards required')
        fails = sum(v['choice'] == 'fail' for v in self.commitments.values())
        threshold = 2 if self.round_index == 3 else 1  # 7-player fourth mission only
        succeeded = fails < threshold
        proofs = self._proofs()
        self.private_mission_proofs.append({'round': self.round_index + 1,
                                            'attempt': self.attempts + 1,
                                            'proofs': proofs})
        # Identity-free mission reveals: no seat->card mapping in public log.
        self._log('mission_revealed', {'round': self.round_index + 1,
                                       'success_cards': len(self.proposal) - fails,
                                       'fail_cards': fails, 'threshold': threshold,
                                       'succeeded': succeeded,
                                       'sealed_card_commitments': [p['commitment'] for p in proofs]})
        self.commitments = {}
        self.wins_good += int(succeeded)
        self.wins_evil += int(not succeeded)
        if self.wins_evil == 3:
            self._finish('evil', 'three_failed_missions')
        elif self.wins_good == 3:
            self.phase = 'assassination'
            self._log('assassination_begins', {})
        else:
            self.round_index += 1
            self.attempts = 0
            self.turn_index += 1
            self.phase = 'proposal'
        self.proposal = None
        return {'success': succeeded, 'fails': fails, 'threshold': threshold,
                'wins_good': self.wins_good, 'wins_evil': self.wins_evil, 'phase': self.phase}

    def assassinate(self, assassin_seat: int, target: int) -> dict[str, Any]:
        if self.phase != 'assassination' or self.roles.get(assassin_seat) != Role.ASSASSIN or target not in self.roles:
            raise RuleViolation('Only assassin may target a valid seat at assassination')
        hit = self.roles[target] == Role.MERLIN
        self._log('assassination', {'assassin': assassin_seat, 'target': target, 'hit': hit})
        self._finish('evil' if hit else 'good', 'assassination_hit' if hit else 'assassination_missed')
        return {'hit_merlin': hit, 'winner': self.final_result}

    def _finish(self, winner: str, reason: str):
        self.final_result = winner
        self.phase = 'finished'
        self._log('finished', {'winner': winner, 'reason': reason})

    def _proofs(self) -> list[dict[str, Any]]:
        return [{'seat': s, 'choice': x['choice'], 'salt': x['salt'],
                 'commitment': x['commitment']} for s, x in sorted(self.commitments.items())]

    def audit(self) -> dict[str, Any]:
        """After game only: sealed role reveal and tamper-evident event chain.
        Audit is *not* independent external timestamping / proof of original precommit.
        """
        if self.phase != 'finished':
            raise RuleViolation('Only reveal roles after match finished')
        prev = '0' * 64
        for e in self.events:
            payload = {k: e[k] for k in ('seq', 'type', 'payload', 'previous_hash')}
            if e['previous_hash'] != prev or digest(payload) != e['hash']:
                raise RuleViolation('Event chain corrupted')
            prev = e['hash']
        opened_commitment = self.events[0]['payload']['role_commitment']
        if self.role_commitment != opened_commitment:
            raise RuleViolation('Role reveal mismatches opening commitment')
        for e in self.events:
            if e['type'] == 'mission_revealed':
                matches = [item for item in self.private_mission_proofs
                           if item['round'] == e['payload']['round']]
                if len(matches) != 1:
                    raise RuleViolation('Missing mission card proofs')
                item = matches[0]
                proof_commitments = [p['commitment'] for p in item['proofs']]
                if proof_commitments != e['payload']['sealed_card_commitments']:
                    raise RuleViolation('Mission card commitment list changed')
                for p in item['proofs']:
                    expected = digest({'seat': p['seat'], 'choice': p['choice'],
                                       'salt': p['salt'], 'kind': 'mission',
                                       'round': item['round'], 'attempt': item['attempt']})
                    if expected != p['commitment']:
                        raise RuleViolation('Mission card commitment mismatch')
                failed = sum(p['choice'] == 'fail' for p in item['proofs'])
                if failed != e['payload']['fail_cards']:
                    raise RuleViolation('Mission card tally mismatch')
            if e['type'] == 'votes_revealed':
                for proof in e['payload']['proofs']:
                    expected = digest({'seat': proof['seat'], 'choice': proof['choice'],
                                       'salt': proof['salt'], 'kind': 'vote',
                                       'round': self._prior_proposal(e)['round'],
                                       'attempt': self._prior_proposal(e)['attempt']})
                    if proof['commitment'] != expected:
                        raise RuleViolation('Vote commitment mismatch')
        return {'ok': True, 'winner': self.final_result, 'role_commitment': self.role_commitment,
                'role_nonce': self.game_nonce, 'roles': {str(s): r.value for s, r in sorted(self.roles.items())},
                'event_count': len(self.events), 'final_event_hash': prev}

    def _prior_proposal(self, reveal_event: dict[str, Any]) -> dict[str, Any]:
        for e in reversed(self.events[:reveal_event['seq']]):
            if e['type'] == 'proposal':
                return e['payload']
        raise RuleViolation('Missing proposal for vote reveal')
