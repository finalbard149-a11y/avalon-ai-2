"""The v0.5.1 mobile history, evil discussion and final reveal tests."""
import os,base64,unittest
from fastapi.testclient import TestClient
from server import app,SESSIONS
from engine import Role

class ReleaseTests(unittest.TestCase):
    def setUp(self):
        os.environ['AVALON_ACCESS_PASSWORD']='test-password-long-enough-1234'
        os.environ.pop('OPENAI_API_KEY',None)
        auth=base64.b64encode(b'avalon:test-password-long-enough-1234').decode()
        self.client=TestClient(app,headers={'Authorization':'Basic '+auth})
        res=self.client.post('/api/new',json={'seat':3,'role':'loyal_servant','seed':431})
        self.assertEqual(res.status_code,200,res.text)
        self.sid=res.json()['session'];self.session=SESSIONS[self.sid]
    def post(self,path,**kwargs):
        return self.client.post('/api/'+path,json={'session':self.sid,**kwargs})
    def test_private_auth_required(self):
        unauth=TestClient(app)
        self.assertEqual(unauth.get('/').status_code,401)
        self.assertEqual(unauth.get('/api/state/'+self.sid).status_code,401)
    def test_pre_reveal_no_hidden_roles(self):
        s=self.client.get('/api/state/'+self.sid).json()
        self.assertIsNone(s['audit']);self.assertIsNone(s['finale'])
        self.assertEqual(s['evil_seats'],[])
        self.assertFalse(s['evil_revealed'])
    def test_history_retains_votes_and_mission(self):
        res=self.post('advance');self.assertEqual(res.status_code,200)
        self.assertIsNone(res.json()['history'][0]['votes'])
        r=self.post('vote',approve=True);self.assertEqual(r.status_code,200)
        record=r.json()['history'][0]
        self.assertEqual(set(record['votes']),set(str(i) for i in range(1,8)))
        self.assertEqual(record['votes']['3'],'yes')
        if record['passed']:
            if 3 in record['team']:r=self.post('mission',fail=False)
            else:r=self.post('advance')
            self.assertEqual(r.status_code,200,r.text)
            self.assertEqual(r.json()['history'][0]['mission']['success_cards']+r.json()['history'][0]['mission']['fail_cards'],2)
        else:self.assertIsNone(record['mission'])
    def stage_assassination(self):
        m=self.session.match
        m.game.phase='assassination';m.game.wins_good=3
        m.game._log('assassination_begins',{})
    def test_cannot_bypass_discussion(self):
        self.stage_assassination()
        self.assertEqual(self.post('advance').status_code,400)
        self.assertEqual(self.post('evil-finalize').status_code,400)
        self.assertEqual(self.post('evil-discuss').status_code,400)
    def test_reveal_discuss_finalize_and_audit(self):
        self.stage_assassination()
        r=self.post('evil-reveal');self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(len(r.json()['evil_seats']),3)
        self.assertIsNone(r.json()['finale'])
        for idx in range(3):
            r=self.post('evil-discuss');self.assertEqual(r.status_code,200,r.text)
            self.assertEqual(len(r.json()['evil_discussion']),idx+1)
            self.assertIsNone(r.json()['audit'])
        r=self.post('evil-finalize');self.assertEqual(r.status_code,200,r.text)
        data=r.json()
        self.assertEqual(data['public']['phase'],'finished')
        self.assertEqual(len(data['finale']['roles']),7)
        self.assertIn('target',data['finale']['assassination'])
        self.assertTrue(data['audit']['ok'])
        self.assertEqual(len(data['evil_discussion']),3)
    def test_human_evil_speaks_not_impersonated(self):
        r=self.client.post('/api/new',json={'seat':3,'role':'assassin','seed':17})
        self.assertEqual(r.status_code,200,r.text)
        sid=r.json()['session'];m=SESSIONS[sid].match
        m.game.phase='assassination';m.game.wins_good=3;m.game._log('assassination_begins',{})
        self.client.post('/api/evil-reveal',json={'session':sid})
        for _ in range(3):
            state=self.client.get('/api/state/'+sid).json()
            seat=state['evil_seats'][len(state['evil_discussion'])]
            x=self.client.post('/api/evil-discuss',json={'session':sid})
            if seat==3:
                self.assertTrue(x.json()['result']['human_evil_turn'])
                self.assertEqual(len(x.json()['evil_discussion']),len(state['evil_discussion']))
                target=next(s for s in range(1,8) if s not in state['evil_seats'])
                x=self.client.post('/api/evil-speak',json={'session':sid,'text':'我認為此人值得懷疑', 'suggestion':target})
            self.assertEqual(x.status_code,200,x.text)
        r=self.client.post('/api/evil-finalize',json={'session':sid})
        self.assertEqual(r.status_code,400)  # Human assassin must submit target
        target=next(s for s in range(1,8) if s not in self.client.get('/api/state/'+sid).json()['evil_seats'])
        r=self.client.post('/api/evil-finalize',json={'session':sid,'target':target})
        self.assertEqual(r.status_code,200,r.text)

if __name__=='__main__':unittest.main()
