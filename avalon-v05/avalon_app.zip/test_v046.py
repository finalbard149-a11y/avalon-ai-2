import unittest
from engine import Game, Role
from agents import choose_vote
from match import run_automated

ROLES={1:Role.MORGANA,2:Role.MERLIN,3:Role.PERCIVAL,4:Role.LOYAL,5:Role.MINION,6:Role.ASSASSIN,7:Role.LOYAL}

class TestV046(unittest.TestCase):
    def view(self,seat,team,mission=1,attempt=1,good=0,evil=0):
        v=Game(ROLES).player_view(seat)
        v['_v046_enabled']=True
        v['public'].update(proposal=team,mission=mission,attempt=attempt,wins_good=good,wins_evil=evil)
        return v
    def test_merlin_early_self_with_one_evil_approves(self):
        v=self.view(2,[1,2],mission=1)
        d=choose_vote(v)
        self.assertEqual(d.action,'approve')
        self.assertIn('v046_merlin_own_team_cover',d.tags)
    def test_merlin_tied_self_with_evil_approves(self):
        v=self.view(2,[1,2,4],mission=3,good=1,evil=1)
        self.assertEqual(choose_vote(v).action,'approve')
    def test_merlin_advantage_self_with_evil_approves(self):
        v=self.view(2,[1,2,4],mission=3,good=2,evil=0)
        self.assertEqual(choose_vote(v).action,'approve')
    def test_merlin_losing_self_with_evil_rejects(self):
        v=self.view(2,[1,2,4],mission=3,good=0,evil=2)
        self.assertEqual(choose_vote(v).action,'reject')
    def test_merlin_terminal_even_tied_rejects(self):
        v=self.view(2,[1,2,4,7],mission=5,good=2,evil=2)
        self.assertEqual(choose_vote(v).action,'reject')
    def test_merlin_off_team_with_evil_rejects(self):
        v=self.view(2,[1,4],mission=1)
        self.assertEqual(choose_vote(v).action,'reject')
    def test_merlin_4th_with_one_evil_not_terminal(self):
        v=self.view(2,[1,2,4,7],mission=4,good=1,evil=2)
        # losing state, no situational cover
        self.assertEqual(choose_vote(v).action,'reject')
    def test_percival_self_double_thumb_veto(self):
        v=self.view(3,[1,2,3],mission=2)
        d=choose_vote(v)
        self.assertEqual(d.action,'reject')
        self.assertIn('v046_percival_double_thumb_veto',d.tags)
    def test_percival_off_team_double_thumb_veto(self):
        v=self.view(3,[1,2],mission=1)
        self.assertEqual(choose_vote(v).action,'reject')
    def test_percival_not_double_thumb_uses_normal_evidence(self):
        v=self.view(3,[2,3],mission=1)
        self.assertNotIn('v046_percival_double_thumb_veto',choose_vote(v).tags)
    def test_attempt_5_no_auto_loss_good(self):
        for s,t in [(2,[1,2,4,7]),(3,[1,2,3,7]),(4,[1,4,5,7])]:
            v=self.view(s,t,mission=5,attempt=5,good=2,evil=2)
            self.assertEqual(choose_vote(v).action,'approve')
    def test_finished_and_audit(self):
        m=run_automated(seed=923,v045_enabled=True,v046_enabled=True,percival_mutual_inference_enabled=True)
        self.assertTrue(m.game.audit())

if __name__=='__main__':unittest.main()
