import unittest
from engine import Game, Role
from agents import choose_vote, suspicion
from nomination_inference import posterior,nomination_explanation

ROLES={1:Role.MINION,2:Role.MERLIN,3:Role.PERCIVAL,4:Role.LOYAL,
       5:Role.ASSASSIN,6:Role.MORGANA,7:Role.LOYAL}

class NominationTests(unittest.TestCase):
    def test_repeated_nomination_changes_belief(self):
        view=Game(ROLES).player_view(4)
        for seq,(captain,team) in enumerate([(1,[1,2]),(5,[2,5]),(6,[2,6])],1):
            view['public']['public_events'].append({'seq':seq,'type':'proposal',
                'payload':{'captain':captain,'team':team,'round':1,'attempt':seq}})
        baseline=posterior(view,use_nominations=False)
        updated=posterior(view,use_nominations=True)
        self.assertLess(updated[2],baseline[2])
        self.assertLess(updated[2],updated[3])
    def test_omissions_are_not_hard_evil_proofs(self):
        view=Game(ROLES).player_view(4)
        view['public']['public_events'].append({'seq':1,'type':'proposal',
            'payload':{'captain':1,'team':[1,2],'round':1,'attempt':1}})
        result=posterior(view)
        self.assertTrue(all(0<=v<=1 for v in result.values()))
        self.assertGreater(result[3],0)
        self.assertLess(result[3],1)
    def test_no_hidden_roles_in_input_or_explanation(self):
        view=Game(ROLES).player_view(4)
        self.assertNotIn('roles',view)
        self.assertEqual(view['known_evil'],[])
        p=nomination_explanation(view)
        self.assertNotIn('roles',p)
        self.assertEqual(p['proposals_observed'],0)
    def test_merlin_final_hard_veto_unchanged(self):
        game=Game(ROLES)
        game.round_index=4;game.wins_good=2;game.wins_evil=2
        game.propose(1,[1,2,3,7])
        view=game.player_view(2);view['_nomination_model_enabled']=True
        self.assertEqual(choose_vote(view).action,'reject')
    def test_reason_from_public_proposal_counts(self):
        game=Game(ROLES);game.propose(1,[1,2])
        v=game.player_view(4)
        report=nomination_explanation(v)
        self.assertEqual(report['selection_count'][2],1)
        self.assertEqual(report['selection_count'][6],0)
        self.assertEqual(report['selection_opportunities'][2],1)

if __name__=='__main__':unittest.main()
