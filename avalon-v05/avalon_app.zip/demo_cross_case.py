"""Inspect the user's 1/2/3 captains -> 4 nominated special case."""
import json
from test_v043 import scenario, public_case
from cross_evidence import evaluate, adjusted_probability
v=scenario(events=public_case())
x=evaluate(v)
print(json.dumps({'selected_count':x['selected_count'],'selected_by':x['selected_by'],
                  'cross_flags':x['cross_flags'],
                  'example_prior_for_captain_2':.5,
                  'example_posterior_for_captain_2':round(adjusted_probability(v,2,.5),4),
                  'note':'Only illustrative 50% prior, not a calibrated posterior based on all game evidence.'},ensure_ascii=False,indent=2))
