import unittest
from unittest.mock import patch
from engine import Game, Role
from agents import choose_proposal, suspicion
from percival_inference import candidate_morgana_probabilities

ROLES={1:Role.MORGANA,2:Role.MERLIN,3:Role.PERCIVAL,4:Role.LOYAL,5:Role.MINION,6:Role.ASSASSIN,7:Role.LOYAL}

def evs(props):
    events=[]
    for i,(c,team,votes) in enumerate(props):
        events.append({'seq':i*2,'type':'proposal','payload':{'captain':c,'team':team,'round':1,'attempt':i+1}})
        events.append({'seq':i*2+1,'type':'votes_revealed','payload':{'votes':votes,'passed':False}})
    return events

class TestExperimentalPolicies(unittest.TestCase):
    def test_merlin_multi_evil_when_triggered(self):
        g=Game(ROLES)
        g.round_index=1
        g.turn_index=1
        v=g.player_view(2)
        v['_merlin_multi_evil_enabled']=True
        v['_merlin_multi_evil_pct']=100
        team=choose_proposal(v)
        self.assertEqual(len(team),3)
        self.assertIn(2,team)
        self.assertEqual(len(set(team).intersection({1,5,6})),2)
    def test_never_one_evil_in_experimental_merlin_proposal(self):
        g=Game(ROLES)
        for r in range(5):
            g.round_index=r
            for evil_wins in (0,1,2):
                g.wins_evil=evil_wins
                v=g.player_view(2)
                v['_merlin_multi_evil_enabled']=True
                v['_merlin_multi_evil_pct']=100
                team=choose_proposal(v)
                self.assertNotEqual(len(set(team).intersection({1,5,6})),1)
    def test_no_multi_evil_when_evil_has_two_wins(self):
        g=Game(ROLES);g.round_index=2;g.wins_evil=2
        v=g.player_view(2);v['_merlin_multi_evil_enabled']=True;v['_merlin_multi_evil_pct']=100
        self.assertEqual(len(set(choose_proposal(v)).intersection({1,5,6})),0)
    def test_percival_candidate_inference_direction(self):
        g=Game(ROLES)
        v=g.player_view(3)
        votes={str(s):'no' for s in range(1,8)}
        votes['1']='yes'
        v['public']['public_events']=evs([(1,[1,2],votes),(2,[2,4],votes)])
        p=candidate_morgana_probabilities(v)
        self.assertGreater(p[1],p[2])
    def test_percival_candidate_inference_reverses(self):
        g=Game(ROLES)
        v=g.player_view(3)
        votes={str(s):'no' for s in range(1,8)}
        votes['2']='yes'
        v['public']['public_events']=evs([(2,[1,2],votes),(1,[1,4],votes)])
        p=candidate_morgana_probabilities(v)
        self.assertGreater(p[2],p[1])
    def test_percival_does_not_gain_true_roles(self):
        g=Game(ROLES)
        v=g.player_view(3)
        self.assertEqual(v['known_evil'],[])
        self.assertEqual(v['merlin_or_morgana'],[1,2])
        self.assertEqual(candidate_morgana_probabilities(v),{1:.5,2:.5})
    def test_low_evidence_never_certainty(self):
        g=Game(ROLES);v=g.player_view(3)
        votes={str(s):'yes' for s in range(1,8)}
        v['public']['public_events']=evs([(1,[1,2],votes)]*10)
        p=candidate_morgana_probabilities(v)
        self.assertGreater(p[1],0.0);self.assertLess(p[1],1.0)

if __name__=='__main__':unittest.main()
