"""Public-only LLM conversation director for real Avalon matches.

The director routes conversational turns; it never submits votes, changes
Match or sees a private seat view. A deterministic scheduler is the fallback.
"""
from __future__ import annotations
import json, os, re
from groupchat import choose_speakers, DISPUTE

VALID_INTENTS={'answer','challenge','rebut','interject'}


def _grounded_public(public:dict)->dict:
    """Explicit allowlist prevents leaking unexposed ballots and role tables."""
    keys=('mission','attempt','phase','captain','proposal','wins_good','wins_evil')
    events=[]
    for event in public.get('public_events',[]):
        if event.get('type') in ('proposal','votes_revealed','mission_revealed'):
            events.append({'type':event['type'],'payload':event['payload']})
    return {'state':{key:public.get(key) for key in keys},'verified_events':events[-45:]}


def direct_turns(human:int, text:str, public:dict, dynamics, target:int|None=None,
                 history:list[dict]|None=None)->tuple[list[tuple[int,str]],str]:
    fallback=choose_speakers(human,text,public,dynamics,target)
    if not os.getenv('OPENAI_API_KEY') or os.getenv('AVALON_GAME_DIRECTOR','1')=='0':
        return fallback,'rule-based'
    from openai import OpenAI
    system=(
        '你是七人阿瓦隆「正式對局」的公開對話導演。只負責安排 NPC 下一段對話的座位與意圖；'
        '絕不可寫台詞、提交投票、改變隊伍、推理隱藏的真實角色或更動規則。'
        '你只能看到目前公開事件與發言，不知道各座位身分。'
        '當真人指定一名 NPC，第一個回答必須是該 NPC。針對質疑可安排其他人挑戰、當事人回嘴；'
        '通常1至3個回應，最多4個。不要讓 NPC 都輪流說套話，也不要虛構前幾局。'
        '輸出純JSON：{"turns":[{"seat":4,"intent":"answer"},{"seat":5,"intent":"challenge"}]}。'
        'seat只能1至7但不能是真人座位，intent只能answer/challenge/rebut/interject。'
    )
    payload={'public':_grounded_public(public),'human_seat':human,
             'human_latest':text[:900],'direct_target':target,
             'recent_public_dialogue':[{'speaker':x['speaker'],'text':x['text'][:320]}
                   for x in (history or [])[-16:]]}
    try:
        response=OpenAI(timeout=18,max_retries=0).chat.completions.create(
            model=os.getenv('AVALON_DIRECTOR_MODEL','gpt-4.1'),
            messages=[{'role':'system','content':system},
                      {'role':'user','content':json.dumps(payload,ensure_ascii=False)}],
            temperature=0.35,max_tokens=260)
        raw=(response.choices[0].message.content or '').strip()
        if raw.startswith('```'):
            raw=re.sub(r'^```(?:json)?\s*|\s*```$','',raw)
        turns=json.loads(raw)['turns']
        if not isinstance(turns,list):raise ValueError('bad turns')
        result=[]
        for item in turns[:4]:
            if not isinstance(item,dict):continue
            seat=item.get('seat');intent=item.get('intent')
            if type(seat) is int and 1<=seat<=7 and seat!=human and intent in VALID_INTENTS:
                result.append((seat,intent))
        if not result:raise ValueError('no valid turns')
        if target and target!=human and result[0][0]!=target:
            result=[(target,'answer')]+[p for p in result if p[0]!=target][:3]
        # Explicit disputes need at least one exchange, never forced into silence.
        if any(w in text for w in DISPUTE) and len(result)==1:
            for seat,intent in fallback:
                if seat!=result[0][0]:
                    result.append((seat,'challenge'));break
        return result[:4],'director-llm'
    except Exception:
        return fallback,'director-fallback'
