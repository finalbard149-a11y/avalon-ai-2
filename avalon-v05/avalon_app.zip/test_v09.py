import unittest
from unittest.mock import patch, MagicMock
from types import SimpleNamespace
from groupchat import TableDynamics
from game_director import direct_turns, _grounded_public
from game_fact_guard import factual_violations
from match import Match
from server import Session, state, chat, Chat
import server
from history_guard import guard_response

class IntegrationV09Tests(unittest.TestCase):
 def setUp(self):
  self.m=Match.create(3,'percival',42)
  self.s=Session(self.m)
 def test_director_without_key_still_produces_legal_turns(self):
  with patch.dict('os.environ',{'OPENAI_API_KEY':''}):
   turns,status=direct_turns(3,'4號為什麼反對自己的隊伍',self.m.public(),TableDynamics(),4)
  self.assertEqual(turns[0][0],4)
  self.assertEqual(status,'rule-based')
  self.assertTrue(all(1<=seat<=7 and seat!=3 for seat,_ in turns))
 def test_director_payload_excludes_hidden_roles_and_unrevealed_ballots(self):
  legal=_grounded_public(self.m.public())
  self.assertNotIn('roles',str(legal))
  self.assertNotIn('evil_teammates',str(legal))
  self.assertNotIn('known_evil',str(legal))
  self.assertNotIn('secret',str(legal))
 def test_director_invalid_llm_falls_back(self):
  obj=MagicMock()
  obj.chat.completions.create.return_value.choices[0].message.content='{"turns":[{"seat":3,"intent":"answer"}]}'
  with patch.dict('os.environ',{'OPENAI_API_KEY':'fake'}),patch.dict('sys.modules',{'openai':SimpleNamespace(OpenAI=lambda **kw:obj)}):
   turns,status=direct_turns(3,'4號回答',self.m.public(),TableDynamics(),4)
  self.assertEqual(status,'director-fallback')
  self.assertEqual(turns[0][0],4)
 def test_director_valid_output_target_first(self):
  obj=MagicMock()
  obj.chat.completions.create.return_value.choices[0].message.content='{"turns":[{"seat":5,"intent":"challenge"},{"seat":4,"intent":"answer"}]}'
  with patch.dict('os.environ',{'OPENAI_API_KEY':'fake'}),patch.dict('sys.modules',{'openai':SimpleNamespace(OpenAI=lambda **kw:obj)}):
   turns,status=direct_turns(3,'4號回答',self.m.public(),TableDynamics(),4)
  self.assertEqual(status,'director-llm')
  self.assertEqual(turns[0],(4,'answer'))
 def test_history_guard_shared_with_real_game(self):
  self.assertFalse(guard_response('上三局7號明明就是莫德！').allowed)
 def test_state_does_not_expose_private_role_table(self):
  st=state(self.s)
  self.assertNotIn('roles',st)
  self.assertIn('director_status',st)
 def test_real_game_chat_uses_director(self):
  server.SESSIONS['v09-test']=self.s
  server.SESSION_BIRTH['v09-test']=__import__('time').time()
  try:
   with patch.object(server,'direct_turns',return_value=([(4,'answer')],'director-llm')):
    out=chat(Chat(session='v09-test',text='4號，你怎麼看？',target=4))
   self.assertEqual(out['director_status'],'director-llm')
   self.assertEqual(out['result']['replies'][0]['speaker'],4)
  finally:
   server.SESSIONS.pop('v09-test',None)
   server.SESSION_BIRTH.pop('v09-test',None)
if __name__=='__main__':unittest.main()
