import unittest
from agents import choose_vote, suspicion
from cross_evidence import evaluate, adjusted_probability


def scenario(role='loyal_servant', seat=7, attempt=3, events=None, proposal=None):
    return {'seat':seat,'role':role,'side':'good','known_evil':[1,5,6] if role=='merlin' else [],
       'evil_teammates':[],'merlin_or_morgana':[2,6] if role=='percival' else [],
       'public':{'phase':'voting','mission':1,'attempt':attempt,'captain':2,
                 'team_size':2,'wins_good':0,'wins_evil':0,'proposal':proposal or [2,4],
                 'public_events':events or []},'_behavior_evidence_enabled':True,
                 '_nomination_model_enabled':True,'_cross_evidence_enabled':True,
                 '_behavior_weight_multiplier':2.0}


def public_case():
    proposals=[(1,[1,4],{1:'yes',4:'yes',2:'no',3:'no',5:'no',6:'no',7:'no'}),
               (2,[2,4],{2:'yes',4:'no',5:'yes',6:'yes',1:'no',3:'no',7:'no'}),
               (3,[3,4],{3:'yes',4:'yes',1:'no',2:'no',5:'no',6:'no',7:'no'})]
    events=[]
    for i,(captain,team,votes) in enumerate(proposals):
        events.append({'seq':i*2,'type':'proposal','payload':{'round':1,'attempt':i+1,'captain':captain,'team':team}})
        events.append({'seq':i*2+1,'type':'votes_revealed','payload':{'votes':votes,'yes':sum(v=='yes' for v in votes.values()),'passed':False}})
    return events


class TestV043(unittest.TestCase):
    def test_fifth_attempt_all_good_approve_even_merlin_knows_evil(self):
        for role,seat in [('merlin',7),('loyal_servant',3),('percival',3)]:
            v=scenario(role,seat,5,proposal=[1,2])
            self.assertEqual(choose_vote(v).action,'approve')
            self.assertIn('good_mandatory_approve',choose_vote(v).tags)

    def test_cross_references_captain_two(self):
        v=scenario(events=public_case())
        out=evaluate(v)
        self.assertEqual(out['selected_count'][4],3)
        self.assertEqual(out['selected_by'][4],[1,2,3])
        self.assertEqual(len(out['cross_flags']),1)
        flag=out['cross_flags'][0]
        self.assertEqual(flag['captain'],2)
        self.assertEqual(flag['dissenting_member'],4)
        self.assertEqual(flag['outside_approvers'],[5,6])
        self.assertEqual(flag['other_captains'],[1,3])
        self.assertGreater(adjusted_probability(v,2,.5),.5)
        self.assertAlmostEqual(adjusted_probability(v,1,.5),.5)

    def test_cross_signal_not_guilt_certainty(self):
        v=scenario(events=public_case())
        self.assertLess(adjusted_probability(v,2,.5),.8)

    def test_percival_inherits_cross_signal(self):
        v=scenario(role='percival',events=public_case())
        self.assertGreater(adjusted_probability(v,2,.5),.5)

    def test_cross_only_after_reveal(self):
        events=public_case()[:3]
        v=scenario(events=events)
        self.assertFalse(evaluate(v)['cross_flags'])

    def test_no_fifth_attempt_cross_penalty(self):
        events=public_case()
        events[2]['payload']['attempt']=5
        events[3]['payload']['votes'][4]='no'
        self.assertFalse(evaluate(scenario(events=events))['cross_flags'])

if __name__=='__main__':unittest.main()
