from match import run_automated
from collections import Counter
import json

if __name__=='__main__':
    out={}
    for label,m,p in [('v045',False,False),('only_merlin',True,False),('only_percival',False,True),('both_v046',True,True)]:
        c=Counter()
        for seed in range(1200,1300):
            x=run_automated(seed=seed,v045_enabled=True,v046_enabled=(m or p),
                            v046_merlin_cover_enabled=m,
                            v046_percival_veto_enabled=p,
                            percival_mutual_inference_enabled=True)
            c['games']+=1
            c['good_wins']+=x.game.final_result=='good'
            c['assassinations']+=any(e['type']=='assassination' for e in x.game.events)
            c['assassin_hits']+=any(e['type']=='assassination' and e['payload']['hit'] for e in x.game.events)
            c['merlin_cover_approvals']+=sum('願意承擔這次任務的風險' in d['reason'] for d in x.npc_decisions)
            c['percival_double_thumb_rejections']+=sum('兩位拇指候選者必含莫甘娜' in d['reason'] for d in x.npc_decisions)
            assert x.game.audit()
        out[label]=dict(c)
    print(json.dumps(out,ensure_ascii=False,indent=2))
    with open('benchmark_046_ablation_1200_1299.json','w') as f: json.dump(out,f,ensure_ascii=False,indent=2)
