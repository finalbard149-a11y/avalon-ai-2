"""Roundtable regression: organic reply routing, public-only conflicts, no new secret powers."""
import base64,os,unittest
from fastapi.testclient import TestClient
from server import app,SESSIONS,SESSION_BIRTH,make_history
from groupchat import TableDynamics,choose_speakers,vote_dispute

class V07Tests(unittest.TestCase):
    def setUp(self):
        SESSIONS.clear();SESSION_BIRTH.clear()
        os.environ['AVALON_ACCESS_PASSWORD']='test-password-long-enough-1234'
        os.environ.pop('OPENAI_API_KEY',None)
        auth=base64.b64encode(b'avalon:test-password-long-enough-1234').decode()
        self.client=TestClient(app,headers={'Authorization':'Basic '+auth})
    def create(self):
        r=self.client.post('/api/new',json={'seat':3,'role':'loyal_servant','seed':121})
        self.assertEqual(r.status_code,200,r.text)
        return r.json()['session']
    def test_open_chat_triggers_reaction_and_remembers_dispute(self):
        sid=self.create()
        r=self.client.post('/api/chat',json={'session':sid,'target':4,'text':'4號你為什麼前面懷疑2號，現在反而幫他說話？'})
        self.assertEqual(r.status_code,200,r.text)
        replies=r.json()['result']['replies']
        self.assertGreaterEqual(len(replies),2)
        self.assertEqual(replies[0]['speaker'],4)
        self.assertNotEqual(replies[1]['speaker'],3)
        self.assertEqual(r.json()['table_dynamics']['frictions'][0]['a'],3)
        self.assertEqual(r.json()['table_dynamics']['frictions'][0]['b'],4)
        from server import get
        self.assertGreater(get(sid).dynamics.tension(3,4),0)
    def test_nonconfrontational_short_turn_is_not_forced_argument(self):
        d=TableDynamics()
        turns=choose_speakers(3,'大家好',{'phase':'proposal','captain':1},d)
        self.assertEqual(len(turns),1)
    def test_directed_pivot_and_no_human_npc(self):
        d=TableDynamics();d.note(3,'2號，你投票前後矛盾')
        turns=choose_speakers(3,'2號你為什麼反對4號？',{'phase':'proposal','captain':1},d,target=2)
        self.assertEqual(turns[0],(2,'answer'))
        self.assertTrue(all(s!=3 for s,_ in turns))
    def test_public_speaker_memory_has_no_secret_roles(self):
        d=TableDynamics();d.note(4,'2號你上輪同意現在反對！')
        self.assertNotIn('merlin',str(d.view(4)))
        self.assertEqual(d.tension(2,4),1)
        self.assertEqual(d.tension(2,5),0)
    def test_ballot_conflict_is_public_and_concrete(self):
        hist=[{'round':1,'attempt':1,'captain':1,'team':[1,4],
               'votes':{'1':'no','2':'yes','3':'no','4':'yes','5':'no','6':'yes','7':'no'}}]
        turns=vote_dispute(hist,3)
        self.assertEqual(len(turns),2)
        self.assertIn('1號',turns[0][1]);self.assertIn('投反對',turns[0][1])
        self.assertEqual(turns[1][0],1)
    def test_no_discussion_does_not_create_role_knowledge(self):
        sid=self.create()
        from server import get
        s=get(sid)
        roles_before=s.match.game.roles.copy()
        r=self.client.post('/api/chat',json={'session':sid,'target':2,'text':'2號，你是不是梅林？'})
        self.assertEqual(r.status_code,200)
        self.assertEqual(s.match.game.roles,roles_before)
        self.assertEqual(s.match.discussion_flags,set())
    def test_new_page_is_marked_v07(self):
        r=self.client.get('/')
        self.assertIn('v0.9',r.text)
        self.assertIn('自然接話',r.text)

if __name__=='__main__':unittest.main()
