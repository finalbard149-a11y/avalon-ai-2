import math
import unittest
from behavior_evidence import behavior_penalty, public_behavior
from engine import Game,Role
from agents import suspicion,choose_vote
ROLES={1:Role.MINION,2:Role.MERLIN,3:Role.PERCIVAL,4:Role.LOYAL,5:Role.ASSASSIN,6:Role.MORGANA,7:Role.LOYAL}
class WeightedBehaviorTests(unittest.TestCase):
 def view(self,role='loyal_servant',weight=2,attempt=1):
  events=[{'type':'proposal','payload':{'round':1,'attempt':attempt,'team':[1,4]}},
          {'type':'votes_revealed','payload':{'votes':{'2':'yes','6':'yes','3':'no'}}}]
  return {'seat':3,'role':role,'_behavior_weight_multiplier':weight,'public':{'public_events':events}}
 def test_twice_log_odds(self):
  v=self.view()
  p1=behavior_penalty({**v,'_behavior_weight_multiplier':1},6,0.4)
  p2=behavior_penalty(v,6,0.4)
  def logit(p):return math.log(p/(1-p))
  self.assertAlmostEqual(logit(p2)-logit(0.4),2*(logit(p1)-logit(0.4)),places=8)
 def test_steeper_warning_both_roles(self):
  for role in ('loyal_servant','percival'):
   self.assertGreater(behavior_penalty(self.view(role,2),6,0.4),behavior_penalty(self.view(role,1),6,0.4))
 def test_no_penalty_for_justified_fifth_attempt(self):
  self.assertEqual(behavior_penalty(self.view(attempt=5),6,0.4),0.4)
 def test_no_penalty_for_own_vote(self):
  self.assertEqual(behavior_penalty(self.view(),3,0.4),0.4)
 def test_no_pre_reveal_leak(self):
  v=self.view();v['public']['public_events']=v['public']['public_events'][:1]
  self.assertEqual(behavior_penalty(v,6,0.4),0.4)
 def test_repeat_has_cap_and_diminishing_returns(self):
  v=self.view()
  v['public']['public_events']*=10
  p=behavior_penalty(v,6,0.4)
  expected=1/(1+math.exp(-(math.log(.4/.6)+2*1.15)))
  self.assertAlmostEqual(p,expected,places=8)
if __name__=='__main__':unittest.main()
