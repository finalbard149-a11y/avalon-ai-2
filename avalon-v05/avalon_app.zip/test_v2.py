import unittest
from unittest.mock import patch
from engine import Game,Role,RuleViolation
from match import Match,run_automated
from agents import choose_vote, choose_proposal, choose_mission, assassin_guess, suspicious_approvals

ROLES={1:Role.MINION,2:Role.MERLIN,3:Role.PERCIVAL,4:Role.LOYAL,5:Role.ASSASSIN,6:Role.MORGANA,7:Role.LOYAL}

class V2Tests(unittest.TestCase):
 def test_uninformed_good_off_team_defaults_reject(self):
  g=Game(ROLES)
  g.propose(1,[1,2])
  d=choose_vote(g.player_view(4))
  self.assertEqual(d.action,'reject')
  self.assertIn('off_team_default_reject',d.tags)
 def test_uninformed_good_on_team_may_approve(self):
  g=Game(ROLES)
  g.propose(1,[2,4])
  d=choose_vote(g.player_view(4))
  self.assertEqual(d.action,'approve')
 def test_off_team_yes_without_public_basis_can_be_questioned(self):
  g=Game(ROLES)
  g.propose(1,[1,4])
  for seat in range(1,8):g.vote(seat,seat in (1,2,4))
  g.reveal_votes()
  flags=suspicious_approvals(g.player_view(3))
  self.assertTrue(any(f['voter']==2 and f['round']==1 for f in flags))
  self.assertFalse(any(f['voter']==1 for f in flags))
 def test_merlin_final_veto_unaffected_by_offteam_rule(self):
  g=Game(ROLES)
  g.round_index=4;g.wins_good=2;g.wins_evil=2
  g.propose(1,[1,2,3,7])
  self.assertEqual(choose_vote(g.player_view(2)).action,'reject')
 def test_merlin_reject_final_known_evil(self):
  game=Game(ROLES)
  game.round_index=4;game.wins_good=2;game.wins_evil=2
  game.propose(1,[1,2,3,7])
  d=choose_vote(game.player_view(2))
  self.assertEqual(d.action,'reject');self.assertIn('hard_veto',d.tags)
 def test_merlin_proposes_without_known_evil(self):
  g=Game(ROLES,first_captain=2)
  for i in range(5):
   team=choose_proposal(g.player_view(2))
   self.assertFalse(set(team).intersection({1,5,6}))
 def test_private_info_boundary(self):
  g=Game(ROLES)
  self.assertEqual(g.player_view(4)['known_evil'],[])
  self.assertEqual(g.player_view(3)['merlin_or_morgana'],[2,6])
  self.assertEqual(g.player_view(2)['known_evil'],[1,5,6])
  self.assertNotIn('roles',g.public_view())
  self.assertNotIn('nonce',str(g.public_view()))
 def test_npc_doesnt_see_full_roles(self):
  m=Match(Game(ROLES),3)
  m.auto_propose_if_npc()
  self.assertEqual(m.game.phase,'voting')
  m.human_vote(False)
  self.assertEqual(len([x for x in m.npc_decisions if x['action']=='vote']),6)
 def test_human_votes_first(self):
  m=Match(Game(ROLES),3);m.auto_propose_if_npc()
  events_before=len(m.game.events)
  m.human_vote(True)
  pending=m.game.events[events_before:]
  self.assertEqual(pending[0]['type'],'sealed_ballot')
  self.assertEqual(pending[0]['payload']['seat'],3)
 def test_human_mission_not_automated(self):
  m=Match(Game(ROLES),3)
  m.game.propose(1,[2,3])
  for s in range(1,8):m.game.vote(s,True)
  m.game.reveal_votes()
  self.assertIsNone(m.auto_mission_if_no_human())
  self.assertEqual(m.game.phase,'mission')
  r=m.human_mission(False)
  self.assertTrue(r['success'])
 def test_role_immutability_audit(self):
  m=run_automated(21)
  m.game.roles[1]=Role.MINION if m.game.roles[1]!=Role.MINION else Role.MERLIN
  with self.assertRaises(RuleViolation):m.audit()
 def test_100_end_to_end_matches(self):
  for seed in range(100):
   m=run_automated(seed)
   self.assertEqual(m.game.phase,'finished')
   self.assertTrue(m.audit()['ok'])
   self.assertTrue(m.game.final_result in {'good','evil'})
 def test_all_six_possible_player_roles_end_to_end(self):
  for role in ['merlin','percival','loyal_servant','assassin','morgana','minion']:
   for seed in range(4):
    m=run_automated(seed,role)
    self.assertTrue(m.audit()['ok'])
 def test_assassin_cannot_read_merlin_role(self):
  m=Match(Game(ROLES),3)
  target,scores=assassin_guess(m.game.player_view(5))
  self.assertNotIn(target,{1,5,6})
  self.assertEqual(set(scores),{2,3,4,7})
 def test_fourth_round_threshold(self):
  g=Game(ROLES);g.round_index=3
  g.propose(1,[1,2,3,4])
  for s in range(1,8):g.vote(s,True)
  g.reveal_votes()
  for s in [1,2,3,4]:g.mission_card(s,s==1)
  r=g.reveal_mission()
  self.assertTrue(r['success']);self.assertEqual(r['threshold'],2)
 def test_rejected_captain_rotates_and_fifth_ends(self):
  g=Game(ROLES)
  for i in range(5):
   old=g.captain
   g.propose(old,[1,2])
   for s in range(1,8):g.vote(s,False)
   g.reveal_votes()
   if i<4:self.assertEqual(g.captain,old%7+1)
  self.assertEqual(g.final_result,'evil')

if __name__=='__main__':unittest.main(verbosity=2)
