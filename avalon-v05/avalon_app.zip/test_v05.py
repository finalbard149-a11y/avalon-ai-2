import os
import unittest
import base64
from fastapi.testclient import TestClient
from server import app,SESSIONS
from dialogue import llm_speech,fallback_speech,reason_snapshot
from match import Match

class WebAndDialogueTests(unittest.TestCase):
    def setUp(self):
        os.environ['AVALON_ACCESS_PASSWORD']='only-for-local-tests-password-12345'
        basic=base64.b64encode(b'avalon:only-for-local-tests-password-12345').decode()
        self.c=TestClient(app,headers={'Authorization':'Basic '+basic})
        self.res=self.c.post('/api/new',json={'seat':3,'role':'percival','seed':2026})
        self.assertEqual(self.res.status_code,200)
        self.sid=self.res.json()['session']

    def test_legal_view_never_reveals_others_roles(self):
        data=self.res.json()
        self.assertNotIn('roles',str(data['public']))
        self.assertEqual(len(data['your_private']['merlin_or_morgana']),2)
        self.assertIsNone(data['audit'])

    def test_no_vote_changed_by_conversation(self):
        session=SESSIONS[self.sid];before=list(session.match.game.events)
        d=self.c.post('/api/chat',json={'session':self.sid,'text':'2號，你憑什麼說我壞？','target':2})
        self.assertEqual(d.status_code,200,d.text)
        self.assertEqual(before,session.match.game.events)
        self.assertEqual(d.json()['result']['replies'][0]['speaker'],2)
        self.assertEqual(len(session.talk.private_memory[2]),1)
        self.assertEqual(len(session.talk.private_memory[1]),0)

    def test_user_vote_first_then_reveal(self):
        session=SESSIONS[self.sid]
        self.c.post('/api/advance',json={'session':self.sid})
        self.assertEqual(session.match.game.phase,'voting')
        before=self.c.get('/api/state/'+self.sid).json()
        self.assertFalse(any(e['type']=='votes_revealed' for e in before['public']['public_events']))
        out=self.c.post('/api/vote',json={'session':self.sid,'approve':False})
        self.assertEqual(out.status_code,200,out.text)
        self.assertEqual(out.json()['result']['votes']['3'],'no')
        self.assertEqual(len(out.json()['result']['votes']),7)

    def test_full_game_and_audit(self):
        session=SESSIONS[self.sid]
        from agents import choose_vote,choose_proposal
        for step in range(110):
            pub=session.match.public();phase=pub['phase']
            if phase=='finished':break
            if phase=='proposal':
                if pub['captain']==3:
                    team=choose_proposal(session.match.view())
                    x=self.c.post('/api/propose',json={'session':self.sid,'team':team})
                else:x=self.c.post('/api/advance',json={'session':self.sid})
            elif phase=='voting':
                d=choose_vote(session.match.view())
                x=self.c.post('/api/vote',json={'session':self.sid,'approve':d.action=='approve'})
            elif phase=='mission':
                x=self.c.post('/api/mission',json={'session':self.sid,'fail':False}) if 3 in pub['proposal'] else self.c.post('/api/advance',json={'session':self.sid})
            else:x=self.c.post('/api/advance',json={'session':self.sid})
            self.assertEqual(x.status_code,200,x.text)
        self.assertEqual(session.match.game.phase,'finished')
        self.assertTrue(self.c.get('/api/state/'+self.sid).json()['audit']['ok'])

    def test_llm_receives_only_seat_legal_roles(self):
        from unittest.mock import patch
        from types import SimpleNamespace
        from dialogue import llm_speech
        m=SESSIONS[self.sid].match
        role_of_1=m.game.roles[1].value
        view=m.seat_view(1)
        captured={}
        class FakeCompletion:
            def create(self,**kwargs):
                captured.update(kwargs)
                return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content='我想先觀察投票。'))])
        class FakeClient:
            def __init__(self,**kwargs): self.chat=SimpleNamespace(completions=FakeCompletion())
        with patch.dict(os.environ,{'OPENAI_API_KEY':'test-only'}),patch.dict('sys.modules',{'openai':SimpleNamespace(OpenAI=FakeClient)}):
            text=llm_speech(view,'你覺得4號呢？',[],[])
        self.assertEqual(text,'我想先觀察投票。')
        system=captured['messages'][0]['content']
        self.assertIn(f'"own_role": "{role_of_1}"',system)
        self.assertNotIn('role_commitment',system)
        # Other seat's true role fields must not be serialized.
        self.assertNotIn('"other_roles"',system)
        self.assertNotIn('"roles"',system)

    def test_chat_rejects_self_target_without_mutation(self):
        session=SESSIONS[self.sid]
        out=self.c.post('/api/chat',json={'session':self.sid,'target':3,'text':'testing'})
        self.assertEqual(out.status_code,400)
        self.assertEqual(session.talk.messages,[])

    def test_safe_fallback_no_key(self):
        os.environ.pop('OPENAI_API_KEY',None)
        m=SESSIONS[self.sid].match
        speech=fallback_speech(m.seat_view(2),'為什麼同意？')
        self.assertIn('風險評分',speech)

if __name__=='__main__':unittest.main()
