import csv,json,math
from benchmark_042 import evaluate
from behavior_evidence import behavior_penalty
from pathlib import Path
base=Path(__file__).parent
rows=[];details={};combined={str(w):{'good_wins':0,'evil_wins':0,'first_proposal_passed':0,'assassination_games':0,'different_proposal_sequences':0,'changed_vote_sequences':0} for w in (1.0,1.5,2.0)}
for start in (400,500):
 sm,runs=evaluate(start,100)
 details[str(start)]=sm
 for w,records in runs:
  key=str(w)
  for k in combined[key]: combined[key][k]+=sm[key].get(k,0)
 baseline=runs[0][1]
 for label,comparison in runs[1:]:
  for b,m in zip(baseline,comparison):
   if b['votes']!=m['votes'] or b['proposal_teams']!=m['proposal_teams']:
    rows.append({'seed':b['seed'],'weight':label,'old_winner':b['winner'],'new_winner':m['winner'],'old_votes':json.dumps(b['votes'],ensure_ascii=False),'new_votes':json.dumps(m['votes'],ensure_ascii=False),'old_proposals':json.dumps(b['proposal_teams'],ensure_ascii=False),'new_proposals':json.dumps(m['proposal_teams'],ensure_ascii=False)})
with open(base/'comparison_change_examples.csv','w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
with open(base/'benchmark_042_results.json','w',encoding='utf8') as f:json.dump({'seeds':'400-599','combined':combined,'by_cohort':details,'notes':'同一批種子對照，勝場差距並非真人勝率估計；提名序列/投票序列變動是與1.0權重的比較'},f,ensure_ascii=False,indent=2)
print(json.dumps(combined,ensure_ascii=False,indent=2))
print('changed events',len(rows))
