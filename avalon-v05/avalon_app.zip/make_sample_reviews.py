from match import run_automated
from engine import EVIL
from pathlib import Path

out=['# v0.4.5 三場可稽核時間線', '', '以下包含賽後角色資訊；遊戲當時 NPC 不會看見這份賽後角色表。場內公開發言、投票和任務從實際事件鏈提取。', '']
for seed in (900,901,904):
 m=run_automated(seed=seed,v045_enabled=True,percival_mutual_inference_enabled=True)
 g=m.game
 out.extend([f'## Seed {seed}｜勝方：{"正義" if g.final_result=="good" else "邪惡"}', '', '賽後角色：'+ '、'.join(f'{s}號 {r.value}' for s,r in g.roles.items()),''])
 pending=None
 for e in g.events:
  typ=e['type'];p=e['payload']
  if typ=='proposal':
   pending=p
   out.append(f"- **第 {p['round']} 輪第 {p['attempt']} 次提案**：隊長 {p['captain']}；隊伍 {','.join(map(str,p['team']))}")
  elif typ=='votes_revealed':
   votes={int(k):v for k,v in p['votes'].items()}
   out.append('  - 投票：'+'；'.join(f'{s}號{"同意" if votes[s]=="yes" else "反對"}' for s in sorted(votes))+f"。結果 {p['yes']}: {7-p['yes']}（{'通過' if p['passed'] else '否決'}）")
  elif typ=='mission_revealed':
   out.append(f"  - 任務：{p['success_cards']} 成功／{p['fail_cards']} 失敗；{'成功' if p['succeeded'] else '失敗'}")
  elif typ=='public_statement':
   out.append(f"  - **公開點名**：{p['speaker']}號：{p['text']}（累積上升 {p['risk_increases']} 次，模型分數 {p['risk_score']}）")
  elif typ=='assassination':
   out.append(f"- 刺客刺殺 {p['target']} 號：{'命中梅林' if p['hit'] else '刺錯'}")
 out.append('')
Path('sample_games_v045.md').write_text('\n'.join(out),encoding='utf-8')
