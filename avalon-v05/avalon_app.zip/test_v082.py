import unittest
from unittest.mock import patch
import director_lab as d
from history_guard import guard_response

class HistoryGroundingTests(unittest.TestCase):
 def test_real_audit_examples_blocked(self):
  examples=[
   '上把遊戲我們不是才看到[1,3,5]任務零fail，結果3號後來被驗出梅林假跳？',
   '你還記不記得上把[2、5、6]也假裝很安全，結果後來被翻盤？',
   '你自己不記得上三局7號也是透明人，結果最後居然是莫德？',
   '以前我們玩過的某局，3號投了反對票。',
  ]
  for line in examples:
   with self.subTest(line=line):self.assertFalse(guard_response(line).allowed)
 def test_permitted_speech(self):
  examples=[
   '我以前見過這種打法，不能直接當好人。',
   '如果上一局7號是壞人，也不代表這局7號一定壞。',
   '4號自己提的[3,4,6]又投反對，這說不通。',
   '我懷疑6號在裝無辜，你是不是在帶風向？',
   '假如壞人藏在成功隊伍裡呢？',
  ]
  for line in examples:
   with self.subTest(line=line):self.assertTrue(guard_response(line).allowed)
 def test_rewrite_then_validate(self):
  l=d.create_lab();calls=[]
  def fake(system,payload,max_tokens):
   calls.append(payload)
   return '上把[2,5,6]最後不是翻盤了？' if len(calls)==1 else '2、5、6這種組合我會懷疑有人在藏，你怎麼看？'
  with patch.dict('os.environ',{'OPENAI_API_KEY':'fake'}),patch.object(d,'_call',side_effect=fake):
   line,status=d.speaker(l,4,'質疑',3,'答話')
  self.assertEqual(status,'actor-llm-corrected')
  self.assertEqual(len(calls),2)
  self.assertTrue(guard_response(line).allowed)
 def test_rewrite_failure_uses_safe_fallback(self):
  l=d.create_lab()
  with patch.dict('os.environ',{'OPENAI_API_KEY':'fake'}),patch.object(d,'_call',return_value='上三局7號是莫德，不記得嗎？'):
   line,status=d.speaker(l,4,'質疑',3,'答話')
  self.assertTrue(status.startswith('actor-fallback'))
  self.assertTrue(guard_response(line).allowed)
 def test_existing_ledger_and_private_separation_still_present(self):
  self.assertEqual(d.public_evidence()['proposals'][0]['captain_vote'],'no')
  self.assertNotIn('known_evil',d.PRIVATE[5])
if __name__=='__main__':unittest.main()
