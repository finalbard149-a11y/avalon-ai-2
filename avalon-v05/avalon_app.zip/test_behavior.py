import unittest
from behavior_evidence import public_behavior,behavior_penalty
from match import run_automated

class TestBehavior(unittest.TestCase):
 def view(self,attempt=1,team=(1,4),voter=2,zero_fail=False):
  events=[]
  if zero_fail:
   events.extend([{'type':'proposal','payload':{'captain':1,'round':1,'attempt':1,'team':list(team)}},
                  {'type':'mission_revealed','payload':{'fail_cards':0}}])
  events.extend([{'type':'proposal','payload':{'captain':1,'round':2,'attempt':attempt,'team':list(team)}},
                 {'type':'votes_revealed','payload':{'votes':{str(voter):'yes'}}}])
  return {'seat':3,'role':'loyal_servant','public':{'public_events':events}}
 def test_flag_unexplained_outside_yes(self):
  info=public_behavior(self.view())
  self.assertEqual(info['counts'][2],1)
  self.assertIn('具體公開證據',info['challenges'][0]['question'])
 def test_no_flag_when_on_team(self):
  self.assertEqual(public_behavior(self.view(team=(2,4)))['counts'],{})
 def test_fifth_attempt_exception(self):
  self.assertEqual(public_behavior(self.view(attempt=5))['counts'],{})
 def test_zero_fail_repeat_exception(self):
  self.assertEqual(public_behavior(self.view(zero_fail=True))['counts'],{})
 def test_suspicion_changes(self):
  v=self.view()
  self.assertGreater(behavior_penalty(v,2,0.5),0.5)
  self.assertEqual(behavior_penalty(v,5,0.5),0.5)
 def test_repeat_diminishing(self):
  v=self.view();v['public']['public_events']+=v['public']['public_events']
  self.assertLess(behavior_penalty(v,2,0.5),0.9)
 def test_game_complete(self):
  for seed in (301,302,303):
   m=run_automated(seed);self.assertTrue(m.audit()['ok']); self.assertGreater(len(m.reasoning_trace),0)

if __name__=='__main__':unittest.main()
