"""Percival-only, lawful private view + public history directional role inference.

Not certainty: both visible candidates can bluff or mimic each other. The
zero-or-multiple-evil Merlin nomination policy is an optional strategic model,
not an Avalon rule; it is *not* treated as impossible to deviate from.
"""
from __future__ import annotations
from math import exp


def candidate_morgana_probabilities(view):
    if view.get('role') != 'percival':
        raise ValueError('Percival only')
    pair=view['merlin_or_morgana']
    if len(pair)!=2:raise ValueError('Two candidates required')
    a,b=pair
    # Positive score means public behavior looks more Morgana-like.
    score={a:0.0,b:0.0}
    last=None
    seen_teams=set()
    events=view['public']['public_events']
    for e in events:
        typ=e['type']; p=e['payload']
        if typ=='proposal':
            last=p
            captain=p['captain'];team=set(p['team'])
            if captain not in score:continue
            other=b if captain==a else a
            # Repeated copied proposals are not independent observations.
            key=(captain,tuple(sorted(team)))
            repetition=.25 if key in seen_teams else 1.0
            seen_teams.add(key)
            if other in team:
                score[captain]+=1.15*repetition
            else:
                score[captain]-=.38*repetition
        elif typ=='votes_revealed' and last:
            team=set(last['team']); captain=last['captain']
            votes={int(k):v for k,v in p['votes'].items()}
            for player in (a,b):
                other=b if player==a else a
                if other not in team or player in team:continue
                # One's approval of OTHER candidate's group when outside team
                # is more consistent with Morgana following known good Merlin.
                # Still noisy: loyal players sometimes approve off-team.
                if votes.get(player)=='yes':score[player]+=.53
                elif votes.get(player)=='no':score[player]-=.18
    # Only the differential matters. Bound posterior to avoid a false oracle.
    d=max(-3.0,min(3.0,score[a]-score[b]))
    p_a=.08+.84/(1+exp(-d))
    return {a:p_a,b:1-p_a}


def explain_candidate_evidence(view):
    probs=candidate_morgana_probabilities(view)
    return {'morgana_probabilities':{str(k):round(v,3) for k,v in probs.items()},
            'warning':'根據公開互選與票型的策略假設，並非可確認的真實身分。'}
