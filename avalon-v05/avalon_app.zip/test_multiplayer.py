import os
os.environ.setdefault('AVALON_ACCESS_PASSWORD','averylongtestpassword')
from fastapi.testclient import TestClient
from server import app
from multiplayer import ROOMS, TOKENS

C=TestClient(app)
AUTH=('avalon','averylongtestpassword')
def post(path,body):
    r=C.post(path,json=body,auth=AUTH)
    assert r.status_code==200,(r.status_code,r.text)
    return r.json()
def get(path):
    r=C.get(path,auth=AUTH)
    assert r.status_code==200,(r.status_code,r.text)
    return r.json()

def test_room_two_humans_and_secrecy():
    one=post('/api/multi/create',{'seat':3})
    assert not one['started']
    assert one['your_seat']==3
    two=post('/api/multi/join',{'code':one['code'],'seat':5})
    assert two['started']
    assert one['your_role'] in ['merlin','percival','loyal_servant','assassin','morgana','minion']
    assert two['your_seat']==5
    # Second person cannot join full room, nor access the private state without token.
    assert C.post('/api/multi/join',json={'code':one['code'],'seat':6},auth=AUTH).status_code==409
    assert C.get('/api/multi/state/faketoken',auth=AUTH).status_code==403
    assert 'your_private' in get('/api/multi/state/'+one['token'])
    assert get('/api/multi/state/'+one['token'])['your_private']==one['your_private']
    # First captain is AI (seat 1). Ensure proposal begins vote phase.
    step=post('/api/multi/move',{'token':one['token'],'kind':'advance'})
    assert step['public']['phase']=='voting'
    # First human votes but cannot reveal either human ballot.
    step=post('/api/multi/move',{'token':one['token'],'kind':'vote','approve':True})
    assert step['public']['phase']=='voting' and step['your_submitted']
    assert step['pending_count']==1
    second_view=get('/api/multi/state/'+two['token'])
    assert not second_view['your_submitted']
    assert second_view['history'][-1]['votes'] is None
    events=second_view['public']['public_events']
    assert not any(e['type']=='sealed_ballot' for e in events)
    assert not any(e['type']=='votes_revealed' for e in events)
    assert 'roles' not in str(second_view['public'])
    assert C.post('/api/multi/move',json={'token':one['token'],'kind':'vote','approve':False},auth=AUTH).status_code==400
    step=post('/api/multi/move',{'token':two['token'],'kind':'vote','approve':True})
    assert step['public']['phase'] in ('mission','proposal','finished')
    assert step['history'][-1]['votes'] is not None
    # Ensure vote is synchronized, no private opponent information exposed.
    assert get('/api/multi/state/'+one['token'])['history'][-1]['votes']==step['history'][-1]['votes']
    ROOMS.pop(one['code']); TOKENS.pop(one['token']); TOKENS.pop(two['token'])

def test_no_mission_cards_before_reveal():
    one=post('/api/multi/create',{'seat':1})
    two=post('/api/multi/join',{'code':one['code'],'seat':2})
    s=post('/api/multi/move',{'token':one['token'],'kind':'propose','team':[1,2]})
    assert s['public']['phase']=='voting'
    post('/api/multi/move',{'token':one['token'],'kind':'vote','approve':True})
    s=post('/api/multi/move',{'token':two['token'],'kind':'vote','approve':True})
    # NPC votes may reject the proposal, so only check eligible mission state.
    if s['public']['phase']=='mission':
        s=post('/api/multi/move',{'token':one['token'],'kind':'mission','fail':False})
        assert s['public']['phase']=='mission' and s['your_submitted']
        assert s['history'][-1]['mission'] is None
        assert not any(e['type']=='sealed_mission' for e in s['public']['public_events'])
        s=post('/api/multi/move',{'token':two['token'],'kind':'mission','fail':False})
        assert s['history'][-1]['mission'] is not None
    ROOMS.pop(one['code']);TOKENS.pop(one['token']);TOKENS.pop(two['token'])

def test_full_two_human_game():
    one=post('/api/multi/create',{'seat':3})
    two=post('/api/multi/join',{'code':one['code'],'seat':5})
    tokens={3:one['token'],5:two['token']}
    state=one
    for i in range(80):
        phase=state['public']['phase']
        if phase=='finished':break
        if phase=='proposal':
            captain=state['public']['captain']
            if captain in tokens:
                state=post('/api/multi/move',{'token':tokens[captain],'kind':'propose','team':list(range(1,state['public']['team_size']+1))})
            else:
                state=post('/api/multi/move',{'token':tokens[3],'kind':'advance'})
        elif phase=='voting':
            for seat in (3,5):
                if seat not in ROOMS[state['code']].match.game.commitments:
                    state=post('/api/multi/move',{'token':tokens[seat],'kind':'vote','approve':True})
        elif phase=='mission':
            if not set(state['public']['proposal']).intersection({3,5}):
                state=post('/api/multi/move',{'token':tokens[3],'kind':'advance'})
                continue
            mission_team=state['public']['proposal']
            for seat in (3,5):
                if seat in mission_team and seat not in ROOMS[state['code']].match.game.commitments:
                    state=post('/api/multi/move',{'token':tokens[seat],'kind':'mission','fail':False})
        elif phase=='assassination':
            assassin=next(s for s,r in ROOMS[state['code']].match.game.roles.items() if r.value=='assassin')
            if assassin in tokens:
                target=next(x for x in range(1,8) if x not in ROOMS[state['code']].match.seat_view(assassin)['evil_teammates'])
                state=post('/api/multi/move',{'token':tokens[assassin],'kind':'assassinate','target':target})
            else:
                state=post('/api/multi/move',{'token':tokens[3],'kind':'assassinate'})
        else:raise AssertionError(phase)
    assert state['public']['phase']=='finished'
    assert state['audit']['ok']
    ROOMS.pop(one['code']);TOKENS.pop(one['token']);TOKENS.pop(two['token'])
