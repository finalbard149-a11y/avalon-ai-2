"""Validate NPC references to previous games before publishing dialogue.

The v0.8.2 laboratory has no authoritative cross-match database. It must never
present concrete recollections of previous matches as fact. This checker is
narrow: arguments, hypotheticals, personal impressions and tactical deception
about motives remain permissible. The server checks *every* rewritten line.
"""
from __future__ import annotations
import re
from dataclasses import dataclass

# First-person or shared historical match references, not 'last round' in this game.
PAST_GAME = re.compile(
    r'(?:上(?:一|二|兩|三|四|五|六|七|八|九|十|\d+)?(?:局|場|把)(?:遊戲)?|'
    r'上(?:把|場)(?:遊戲)?|'
    r'前(?:一|二|兩|三|四|五|六|七|八|九|十|\d+)(?:局|場|把)|'
    r'(?:之前|以前|過去|先前)(?:我們|你們|我|你)?(?:玩過|打過|經歷過)(?:的)?(?:那|某|一)?(?:局|場|把)?|'
    r'(?:我們|你們|我|你)(?:之前|以前|上次)(?:玩過|打過|遇過)(?:的)?(?:那|某|一)?(?:局|場|把)?|'
    r'上次(?:玩|打)(?:的)?(?:那|某|一)?(?:局|場|把))'
)
# An entirely hypothetical example does not assert a match existed.
HYPOTHETICAL = re.compile(r'(?:假如|假設|如果|比如|比方說|舉個假例子|想像|假想|假設有)')
# Generic past experience without an identifiable match is allowed.
GENERIC = re.compile(r'(?:以前(?:見過|看過|碰過|遇過)|過去(?:常見|見過)|這種打法(?:以前|之前))')

@dataclass(frozen=True)
class GuardResult:
    allowed: bool
    issues: tuple[str, ...]


def guard_response(text: str) -> GuardResult:
    issues: list[str] = []
    for m in PAST_GAME.finditer(text):
        clause_start = max(text.rfind(c, 0, m.start()) for c in '。！？!?；;\n') + 1
        clause_end_candidates = [text.find(c, m.end()) for c in '。！？!?；;\n']
        clause_end = min((p for p in clause_end_candidates if p >= 0), default=len(text))
        clause = text[clause_start:clause_end]
        prefix = text[clause_start:m.start()]
        # Only permit explicitly fictional framing, not a purported record.
        if HYPOTHETICAL.search(prefix) and not re.search(r'記得|真的|發生過|不是才',clause):
            continue
        if GENERIC.fullmatch(clause.strip()):
            continue
        issues.append('未經證實的跨局歷史：'+clause.strip()[:150])
    return GuardResult(not issues,tuple(issues))
