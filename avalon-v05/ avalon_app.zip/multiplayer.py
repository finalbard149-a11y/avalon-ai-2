"""Two-human five-AI private rooms, in-process experimental multiplayer.

Room access is by independent bearer tokens; invite code ONLY allows claiming
an unoccupied second seat. Deploy with one worker, one replica and private Basic Auth.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from threading import RLock
import json, secrets, time, os
from typing import Any
from fastapi import HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from match import Match
from agents import choose_proposal, choose_vote, choose_mission, assassin_guess, PERSONAS
from evil_strategy import ally_assassination_analysis
from dialogue import Conversation, fallback_speech, llm_speech
from game_director import direct_turns
from groupchat import TableDynamics, choose_speakers
from engine import RuleViolation

ROOMS: dict[str, 'Room'] = {}
TOKENS: dict[str, tuple[str, int]] = {}
TTL = 6 * 3600
LOCK = RLock()

@dataclass
class Room:
    code: str
    match: Match
    host: int
    guest: int | None = None
    created: float = field(default_factory=time.time)
    talk: Conversation = field(default_factory=Conversation)
    dynamics: TableDynamics = field(default_factory=TableDynamics)
    mode: str = 'fallback'
    updated: int = 0
    messages: list[dict[str,Any]] = field(default_factory=list)

    @property
    def humans(self):
        return {self.host} | ({self.guest} if self.guest else set())

class CreateRoom(BaseModel):
    seat: int = Field(default=3, ge=1, le=7)
    role: str | None = None
class JoinRoom(BaseModel):
    code: str
    seat: int = Field(ge=1, le=7)
class Move(BaseModel):
    token: str
    kind: str
    team: list[int] | None = None
    approve: bool | None = None
    fail: bool | None = None
    text: str | None = Field(default=None, max_length=1500)
    target: int | None = None


def expire():
    for code,room in list(ROOMS.items()):
        if time.time() - room.created > TTL:
            del ROOMS[code]
    for tok,(code,_) in list(TOKENS.items()):
        if code not in ROOMS: del TOKENS[tok]


def lookup(token: str) -> tuple[Room,int]:
    if not token or token not in TOKENS: raise HTTPException(403,'無效的玩家憑證')
    code,seat=TOKENS[token]
    room=ROOMS.get(code)
    if not room or seat not in room.humans:raise HTTPException(404,'對局已過期或不存在')
    return room,seat


def run_ai(room:Room):
    """Commit NPC decisions only after all humans have independently acted."""
    m=room.match;g=m.game
    if g.phase=='voting' and all(s in g.commitments for s in room.humans):
        before=m.risk_snapshot(room.humans)
        rn,an=g.round_index+1,g.attempts+1
        for seat in range(1,8):
            if seat not in room.humans:
                d=choose_vote(m.seat_view(seat))
                g.vote(seat,d.action=='approve')
                m._npc(seat,'vote',d.action,d.reason)
        result=g.reveal_votes()
        m.record_public_risk(before,'votes_revealed',rn,an)
        room.messages.append({'type':'votes_revealed','result':result})
    elif g.phase=='mission' and all(s not in g.proposal or s in g.commitments for s in room.humans):
        before=m.risk_snapshot(room.humans)
        rn,an=g.round_index+1,g.attempts+1
        for seat in g.proposal:
            if seat not in room.humans:
                d=choose_mission(m.seat_view(seat))
                g.mission_card(seat,d.action=='fail')
                m._npc(seat,'mission',d.action,d.reason)
        result=g.reveal_mission()
        m.record_public_risk(before,'mission_revealed',rn,an)
        room.messages.append({'type':'mission_revealed','result':result})


def view(room:Room,seat:int)->dict[str,Any]:
    m=room.match;g=m.game
    own=m.seat_view(seat)
    # NO sealed commitments, role table or unrevealed ballots in player response.
    events=[{'type':x['type'],'payload':{
        k:v for k,v in x['payload'].items() if k not in ('proofs','sealed_card_commitments')
    }} for x in g.public_view()['public_events'] if x['type'] not in ('role_commitment',)]
    public=g.public_view().copy();public['public_events']=events
    council=None
    if g.phase=='assassination' and own['side']=='evil':
        # A lawful evil-only advisory view, without actual good roles.
        analysis=ally_assassination_analysis(own)
        ranked_merlin=sorted(analysis['candidates'],key=lambda x:(-analysis['merlin_likelihood'][x],x))
        ranked_percival=sorted(analysis['candidates'],key=lambda x:(-analysis['percival_likelihood'][x],x))
        ranked_loyal=sorted(analysis['candidates'],key=lambda x:(-analysis['loyal_likelihood'][x],x))
        # AI teammates contribute *their own* lawful candidate rankings. Human
        # teammates are never impersonated or given fabricated recommendations.
        advisors=[]
        for evil_seat in sorted(own['evil_teammates']):
            if evil_seat in room.humans:continue
            ally_view=m.seat_view(evil_seat)
            ally_analysis=ally_assassination_analysis(ally_view)
            ranked=sorted(ally_analysis['candidates'],
                key=lambda s:(-ally_analysis['merlin_likelihood'][s],s))
            advisors.append({'seat':evil_seat,'role':ally_view['role'],
                'merlin_candidate':ranked[0],
                'possible_percival':sorted(ally_analysis['candidates'],
                     key=lambda s:(-ally_analysis['percival_likelihood'][s],s))[0],
                'possible_loyal':sorted(ally_analysis['candidates'],
                     key=lambda s:(-ally_analysis['loyal_likelihood'][s],s))[0]})
        council={'ally_reports':advisors,'merlin_candidates':ranked_merlin,
                 'possible_percival':ranked_percival[:2],
                 'possible_loyal':ranked_loyal[:2],
                 'note':'只根據公開投票、提案與邪惡隊友知識推測；排序並非真實身分。'}
    result={'code':room.code,'your_seat':seat,'your_role':own['role'],
        'your_private':{k:own[k] for k in ('known_evil','evil_teammates','merlin_or_morgana')},
        'started':room.guest is not None,'players':sorted(room.humans),
        'available_seats':[s for s in range(1,8) if s not in room.humans],
        'public':public,'dialogue':room.talk.messages[-100:],
        'mode':room.mode,'revision':room.updated,'evil_council':council,
        'waiting_for_you': room.guest is not None and (
          (g.phase=='proposal' and g.captain==seat) or
          (g.phase=='voting' and seat not in g.commitments) or
          (g.phase=='mission' and seat in (g.proposal or ()) and seat not in g.commitments) or
          (g.phase=='assassination' and g.roles[seat].value=='assassin')),
        'your_submitted':g.phase in ('voting','mission') and seat in g.commitments,
        'pending_count':len(g.commitments) if g.phase in ('voting','mission') else 0,
        'history':build_history(g),
        'outcome':build_outcome(g) if g.phase=='finished' else None,
        'audit':g.audit() if g.phase=='finished' else None}
    return result


def build_history(g):
    records=[];last=None
    for ev in g.public_view()['public_events']:
        v=ev['payload']
        if ev['type']=='proposal':
            last={'round':v['round'],'attempt':v['attempt'],'captain':v['captain'],
                'team':v['team'],'votes':None,'mission':None}
            records.append(last)
        elif ev['type']=='votes_revealed' and last is not None:
            last['votes']={str(k):val for k,val in v['votes'].items()}
        elif ev['type']=='mission_revealed' and last is not None:
            last['mission']={'success':v['succeeded'],'fail_cards':v['fail_cards']}
    return records


def build_outcome(g):
    """End-of-game ONLY. Never serialize roles while a match is active."""
    if g.phase != 'finished':
        return None
    final=next((e['payload'] for e in reversed(g.events) if e['type']=='finished'),{})
    assassination=next((e['payload'] for e in reversed(g.events) if e['type']=='assassination'),None)
    return {'winner':g.final_result,'reason':final.get('reason',''),
            'roles':{str(s):r.value for s,r in sorted(g.roles.items())},
            'assassination':assassination,
            'missions':[{ 'round':e['payload']['round'],
                'success':e['payload']['succeeded'],
                'fail_cards':e['payload']['fail_cards']}
                for e in g.events if e['type']=='mission_revealed']}


def attach_multiplayer(app, root: Any, config):
    @app.get('/multiplayer')
    def multi_page():
        return FileResponse(root/'static'/'multiplayer.html')

    @app.post('/api/multi/create')
    def create(req:CreateRoom):
        with LOCK:
            expire()
            if len(ROOMS)>=20:raise HTTPException(429,'房間數量已滿')
            try:
                m=Match.create(req.seat,req.role)
                config(m)
            except (RuleViolation,ValueError) as e:raise HTTPException(400,str(e))
            code=secrets.token_hex(4).upper()
            while code in ROOMS:code=secrets.token_hex(4).upper()
            room=Room(code,m,req.seat,mode='llm' if os.getenv('OPENAI_API_KEY') else 'fallback')
            ROOMS[code]=room
            token=secrets.token_urlsafe(32)
            TOKENS[token]=(code,req.seat)
            return {'token':token,**view(room,req.seat)}

    @app.post('/api/multi/join')
    def join(req:JoinRoom):
        with LOCK:
            expire()
            room=ROOMS.get(req.code.upper().strip())
            if not room:raise HTTPException(404,'房間代碼無效或已過期')
            if room.guest is not None:raise HTTPException(409,'房間已滿')
            if req.seat==room.host:raise HTTPException(400,'這個座位已被房主使用')
            room.guest=req.seat
            room.updated+=1
            token=secrets.token_urlsafe(32)
            TOKENS[token]=(room.code,req.seat)
            return {'token':token,**view(room,req.seat)}

    @app.get('/api/multi/state/{token}')
    def state(token:str):
        with LOCK:
            expire();r,seat=lookup(token)
            return view(r,seat)

    @app.post('/api/multi/move')
    def move(req:Move):
        with LOCK:
            expire();room,seat=lookup(req.token)
            if room.guest is None:raise HTTPException(409,'等待第二位玩家加入')
            m=room.match;g=m.game
            if g.phase=='finished':raise HTTPException(400,'對局已結束')
            try:
                if req.kind=='propose':
                    if req.team is None:raise RuleViolation('需要選擇隊伍')
                    before=m.risk_snapshot(room.humans)
                    rn,an=g.round_index+1,g.attempts+1
                    g.propose(seat,req.team)
                    m.record_public_risk(before,'proposal',rn,an)
                elif req.kind=='advance':
                    if g.phase=='mission' and not set(g.proposal or ()).intersection(room.humans):
                        run_ai(room)
                    elif g.phase=='proposal' and g.captain not in room.humans:
                        captain=g.captain
                        team=choose_proposal(m.seat_view(captain))
                        m._npc(captain,'proposal',team,'依合法資訊決策')
                        before=m.risk_snapshot(room.humans)
                        rn,an=g.round_index+1,g.attempts+1
                        g.propose(captain,team)
                        m.record_public_risk(before,'proposal',rn,an)
                        # Public actual action, not a generated promise about future actions.
                        room.talk.append(captain, f'我這次正式提名{list(team)}，請大家針對這個隊伍投票。', 'verified-action',len(g.events))
                    else:
                        raise RuleViolation('目前無法讓 NPC 自動推進')
                elif req.kind=='vote':
                    if req.approve is None:raise RuleViolation('尚未選擇同意或反對')
                    g.vote(seat,req.approve)
                    run_ai(room)
                elif req.kind=='mission':
                    if req.fail is None:raise RuleViolation('尚未選擇任務牌')
                    g.mission_card(seat,req.fail)
                    run_ai(room)
                elif req.kind=='assassinate':
                    if g.phase!='assassination':raise RuleViolation('尚未到刺殺階段')
                    assassin=next(s for s,r in g.roles.items() if r.value=='assassin')
                    if assassin in room.humans:
                        if seat!=assassin:raise RuleViolation('只有刺客能決定目標')
                        if req.target is None:raise RuleViolation('請指定刺殺目標')
                        m.assassinate(req.target)
                    else:
                        target,scores=assassin_guess(m.seat_view(assassin))
                        # Record independent strategic recommendations from
                        # NPC allies only. Never synthesize a human player's vote.
                        support={k:0.0 for k in scores}
                        for ally in sorted(m.seat_view(assassin)['evil_teammates']):
                            if ally in room.humans or ally==assassin:continue
                            analysis=ally_assassination_analysis(m.seat_view(ally))
                            candidate=max(analysis['candidates'],key=lambda k:
                                (analysis['merlin_likelihood'][k],-k))
                            support[candidate]+=0.18
                            m._npc(ally,'assassination_advice',candidate,
                                '依公開提案與投票比較梅林、派西維爾及忠臣候選。')
                        target=max(scores,key=lambda k:(scores[k]+support[k],-k))
                        m.assassinate(target)
                elif req.kind=='chat':
                    text=(req.text or '').strip()
                    if not text:raise RuleViolation('不能傳送空白訊息')
                    if req.target is not None and (req.target in room.humans or req.target not in range(1,8)):
                        raise RuleViolation('指定對象不是 NPC')
                    seq=len(g.events)
                    room.talk.append(seat,text,'human',seq)
                    m.register_statement(seat,text)
                    room.dynamics.note(seat,text)
                    g._log('chat_statement',{'speaker':seat,'text':text})
                    if room.talk.llm_used<60:
                        targets,_=direct_turns(seat,text,m.public(),room.dynamics,req.target,room.talk.messages)
                    else:
                        targets=choose_speakers(seat,text,m.public(),room.dynamics,req.target)
                    prompt=text
                    for npc,intent in targets[:3]:
                        if npc in room.humans:continue
                        v=m.seat_view(npc)
                        if room.mode=='llm' and room.talk.llm_used<60:
                            try:
                                sentence=llm_speech(v,prompt,room.talk.visible_for(npc),room.talk.private_memory[npc],intent=intent,table_context=room.dynamics.view(npc))
                                room.talk.llm_used+=1
                                mode='llm'
                            except Exception:
                                sentence=fallback_speech(v,prompt,intent=intent);mode='fallback'
                        else:
                            sentence=fallback_speech(v,prompt,intent=intent);mode='fallback'
                        room.talk.append(npc,sentence,mode,seq)
                        m.register_statement(npc,sentence)
                        room.dynamics.note(npc,sentence)
                        g._log('chat_statement',{'speaker':npc,'text':sentence[:900]})
                        prompt=f'{npc}號剛說：{sentence[:350]}。請回應。'
                else:
                    raise RuleViolation('未知操作')
            except (RuleViolation, ValueError) as e:
                raise HTTPException(400,str(e))
            room.updated+=1
            return view(room,seat)
