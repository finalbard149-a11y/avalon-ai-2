import unittest
from multiplayer import build_outcome, view, Room
from match import Match
from game_fact_guard import factual_violations

class V11Regression(unittest.TestCase):
    def test_pre_game_roles_never_revealed(self):
        m=Match.create(2,seed=17)
        room=Room('V11TEST',m,2,guest=4)
        response=view(room,2)
        self.assertIsNone(response['outcome'])
        self.assertIsNone(response['audit'])
        self.assertNotIn('roles',response)

    def test_final_winner_roles_reason(self):
        m=Match.create(2,seed=18)
        g=m.game
        g._finish('evil','five_rejections')
        data=build_outcome(g)
        self.assertEqual(data['winner'],'evil')
        self.assertEqual(data['reason'],'five_rejections')
        self.assertEqual(len(data['roles']),7)
        self.assertEqual(view(Room('V11TEST',m,2,guest=4),2)['outcome'],data)

    def test_failed_mission_seat_grounding(self):
        # The actual uploaded test match had failed teams [2,5] and [4,5,6].
        incident=[{'kind':'mission','round':1,'team':[2,5],'succeeded':False,'fail_cards':1},
                  {'kind':'mission','round':2,'team':[4,5,6],'succeeded':False,'fail_cards':1}]
        import unittest.mock as mock
        with mock.patch('game_fact_guard.public_incidents',return_value=incident):
            v={'seat':1,'public':{'public_events':[]}}
            self.assertTrue(factual_violations(v,'兩次失敗任務裡面明明都有2號和4號'))
            self.assertFalse(factual_violations(v,'兩次失敗任務都有5號'))

if __name__=='__main__':unittest.main()
