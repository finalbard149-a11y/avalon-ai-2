"""Regression checks: risk is updated only by disclosed actions, per match."""
from match import Match, run_automated
from server import config
from multiplayer import ROOMS, TOKENS
from test_multiplayer import post


def test_match_risk_starts_empty_and_proposal_is_observed():
    match=Match.create(seed=13)
    config(match)
    assert match.risk_increase_counts=={}
    assert match.risk_events==[]
    match.auto_propose_if_npc()
    assert match.game.phase=='voting'
    assert match.risk_events
    assert {e['event_type'] for e in match.risk_events}=={'proposal'}
    assert all(e['round']==1 for e in match.risk_events)


def test_vote_not_evaluated_until_both_humans_submit(monkeypatch):
    monkeypatch.setenv('AVALON_ACCESS_PASSWORD','averylongtestpassword')
    host=post('/api/multi/create',{'seat':3})
    guest=post('/api/multi/join',{'code':host['code'],'seat':5})
    room=ROOMS[host['code']]
    try:
        post('/api/multi/move',{'token':host['token'],'kind':'advance'})
        after_proposal=len(room.match.risk_events)
        post('/api/multi/move',{'token':host['token'],'kind':'vote','approve':True})
        assert len(room.match.risk_events)==after_proposal
        assert room.match.game.phase=='voting'
        post('/api/multi/move',{'token':guest['token'],'kind':'vote','approve':True})
        assert len(room.match.risk_events)>after_proposal
        assert any(e['event_type']=='votes_revealed' for e in room.match.risk_events)
        assert set(room.match.risk_increase_counts).isdisjoint(room.humans)
    finally:
        ROOMS.pop(host['code'],None)
        TOKENS.pop(host['token'],None)
        TOKENS.pop(guest['token'],None)


def test_mission_evidence_kept_through_next_round_then_new_match_empty():
    m=run_automated(seed=701,v045_enabled=True,
        percival_mutual_inference_enabled=True, v046_enabled=True)
    event_types={e['event_type'] for e in m.risk_events}
    assert {'proposal','votes_revealed','mission_revealed'}<=event_types
    missions=[e for e in m.risk_events if e['event_type']=='mission_revealed']
    assert len(missions)>0
    assert {e['round'] for e in m.risk_events} >= {1,2}
    assert m.risk_increase_counts  # Observations were kept in the match
    assert m.game.phase=='finished'
    new=Match.create(seed=702)
    config(new)
    assert new.risk_increase_counts=={}
    assert new.risk_events==[]
    assert new.public_accusations==[]
    assert new.reasoning_trace==[]
