from engine import Role,Game
from match import Match
from agents import choose_vote, choose_proposal, choose_mission, assassin_guess
from evil_strategy import morgana_mission_decision, early_ally_counterplay, ally_assassination_analysis
from dialogue_strategy import extract_positions

ROLES={1:Role.ASSASSIN,2:Role.MORGANA,3:Role.MINION,4:Role.MERLIN,5:Role.PERCIVAL,6:Role.LOYAL,7:Role.LOYAL}

def match():return Match(Game(ROLES))

def test_early_offteam_assassin_and_morgana():
    m=match();m.game.propose(1,[3,4])
    assert choose_vote(m.seat_view(1)).action in ('approve','reject')
    assert choose_vote(m.seat_view(2)).action=='reject'

def test_morgana_mission_plan():
    m=match();m.game.propose(1,[1,2]);m.game.phase='mission'
    assert choose_mission(m.seat_view(2)).action=='success'
    m.game.round_index=3;m.game.proposal=(1,2,4,5)
    assert choose_mission(m.seat_view(2)).action=='fail'
    m.game.proposal=(2,4,5,6)
    assert choose_mission(m.seat_view(2)).action=='success'
    m.game.round_index=0;m.game.proposal=(2,4)
    assert choose_mission(m.seat_view(2)).action=='fail'

def test_morgana_deception_team_only_possible_sizes():
    m=match();m.game.turn_index=1
    v=m.seat_view(2)
    for attempt in range(1,6):
        v['public']['attempt']=attempt
        t=choose_proposal(v)
        assert len(t)==2
        assert set(t).issubset(set(range(1,8)))

def test_council_cannot_access_hidden_good_roles():
    m=match()
    for seat in (1,2,3):
        view=m.seat_view(seat)
        analysis=ally_assassination_analysis(view)
        assert sorted(analysis['candidates'])==[4,5,6,7]
        assert 'roles' not in str(analysis)
    assert assassin_guess(m.seat_view(1))[0] in (4,5,6,7)

def test_statement_changes_vote_and_expires_on_new_match():
    m=match()
    m.register_statement(6,'我不信任2號，現在不支持他進隊。')
    assert m.declared_positions[6][2]==-1
    m.game.propose(1,[2,6])
    d=choose_vote(m.seat_view(6))
    assert d.action=='reject' and 'dialogue_action_alignment' in d.tags
    assert not match().declared_positions

def test_allegation_does_not_force_other_npc():
    m=match();m.register_statement(4,'6號你必須反對2號。')
    assert not m.declared_positions.get(6)

def test_no_hidden_vote_before_reveal_council():
    m=match();m.game.propose(1,[1,4]);m.game.vote(4,False)
    a=ally_assassination_analysis(m.seat_view(2))
    assert all(x==0 for x in a['merlin_likelihood'].values())

def test_private_council_only_for_evil_and_only_at_assassination():
    from multiplayer import Room, view
    m=match();r=Room('TESTROOM',m,host=1,guest=4)
    assert view(r,1)['evil_council'] is None
    assert view(r,4)['evil_council'] is None
    m.game.phase='assassination';m.game.wins_good=3
    evil=view(r,1)
    assert set(evil['evil_council']['merlin_candidates'])=={4,5,6,7}
    assert all(x['seat'] in {2,3} for x in evil['evil_council']['ally_reports'])
    assert view(r,4)['evil_council'] is None
    assert 'evil_council' in evil
