"""Conservative guard for *explicit* contradictions of revealed game results.

Does not judge motive, suspicion, or a deliberate interpretation of a ballot.
"""
from __future__ import annotations
import re
from dialogue import public_incidents  # imports dialogue, not its gameplay entrypoints

_NUM={'一':1,'二':2,'三':3,'四':4,'五':5,'1':1,'2':2,'3':3,'4':4,'5':5}

def factual_violations(view:dict,text:str)->list[str]:
    missions=[e for e in public_incidents(view,100) if e['kind']=='mission']
    if not missions:return []
    compact=re.sub(r'\s+','',text)
    problems=[]
    for m in re.finditer(r'第([一二三四五1-5])輪(?:的)?(?:任務)?(?:是|已經|明明|根本)?(成功|失敗|零失敗|沒有失敗牌)',compact):
        idx=_NUM[m.group(1)]
        if idx>len(missions):continue
        actual=missions[idx-1]
        claimed_success=m.group(2) in ('成功','零失敗','沒有失敗牌')
        if claimed_success!=bool(actual['succeeded']):
            problems.append(f'第{idx}輪任務實際是{"成功" if actual["succeeded"] else "失敗"}')
    # Explicit claims that a seat appeared in ALL failed missions are checked
    # against the authoritative team list, not other NPCs' public accusations.
    failed=[e for e in missions if not e['succeeded']]
    if len(failed)>=2:
        for phrase in re.finditer(r'(?:兩次|每次|全部|所有)(?:的)?失敗(?:任務)?(?:裡面|中|都)?(?:明明|其實|確實)?(?:都有|有|包含|帶了)?([^。！？!?；;]{1,38})', compact):
            clause=phrase.group(1)
            mentioned={int(n) for n in re.findall(r'(?<!\d)([1-7])號',clause)}
            for seat in mentioned:
                if not all(seat in e['team'] for e in failed):
                    problems.append(f'{seat}號並非參與全部失敗任務')
    # Specific claimed failed-mission participation for a numbered round.
    for m in re.finditer(r'([1-7])號(?:也|都|曾|之前)?(?:參加|參與|進過)(?:了)?第([一二三四五1-5])輪(?:的)?失敗任務',compact):
        seat=int(m.group(1));rnd=_NUM[m.group(2)]
        if not any(e['round']==rnd and not e['succeeded'] and seat in e['team'] for e in missions):
            problems.append(f'{seat}號沒有參加第{rnd}輪失敗任務')
    return problems
