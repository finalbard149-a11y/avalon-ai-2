import sys,json,time
from collections import Counter
from sim_v112_compare import play
start=int(sys.argv[1]);n=int(sys.argv[2]);c=Counter();t=time.time()
for i in range(start,start+n):
 x=play(1000+i,True);c[x['winner']]+=1;c[x['reason']]+=1
 for k in ('risk_events','rises','proposals','missions'):c['total_'+k]+=x[k]
 if (i-start+1)%100==0:print('PROGRESS',i-start+1,'elapsed',round(time.time()-t,1),flush=True)
name=f'/mnt/data/avalon_v112_batch_{start}_{n}.json'
with open(name,'w') as f:json.dump({'start':start,'n':n,'counts':dict(c)},f)
print('RESULT',name,dict(c),flush=True)
