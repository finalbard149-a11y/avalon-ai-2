import sys,json,time
from collections import Counter
from match import Match
from engine import Role
from agents import choose_proposal,choose_vote,choose_mission,assassin_guess
from server import config

def play(seed, risk=True):
 m=Match.create(human_seat=3, seed=seed); config(m);g=m.game; steps=0
 while g.phase!='finished':
  steps+=1
  if steps>120:raise RuntimeError(('nontermination',seed,g.phase))
  if g.phase=='proposal':
   rn,an=g.round_index+1,g.attempts+1
   before=m.risk_snapshot(()) if risk else None
   captain=g.captain
   g.propose(captain,choose_proposal(m.seat_view(captain)))
   if risk:m.record_public_risk(before,'proposal',rn,an)
  elif g.phase=='voting':
   rn,an=g.round_index+1,g.attempts+1
   before=m.risk_snapshot(()) if risk else None
   decisions={s:choose_vote(m.seat_view(s)) for s in range(1,8)}
   for s in range(1,8):g.vote(s,decisions[s].action=='approve')
   g.reveal_votes()
   if risk:m.record_public_risk(before,'votes_revealed',rn,an)
  elif g.phase=='mission':
   rn,an=g.round_index+1,g.attempts+1
   decisions={s:choose_mission(m.seat_view(s)) for s in g.proposal}
   for s in g.proposal:g.mission_card(s,decisions[s].action=='fail')
   before=m.risk_snapshot(()) if risk else None
   g.reveal_mission()
   if risk:m.record_public_risk(before,'mission_revealed',rn,an)
  elif g.phase=='assassination':
   a=next(s for s,r in g.roles.items() if r==Role.ASSASSIN)
   target,_=assassin_guess(m.seat_view(a))
   g.assassinate(a,target)
 f=next(ev['payload'] for ev in reversed(g.events) if ev['type']=='finished')
 return {'winner':g.final_result,'reason':f['reason'],'risk_events':len(m.risk_events), 'rises':sum(sum(c.values()) for c in m.risk_increase_counts.values()), 'proposals':sum(e['type']=='proposal' for e in g.events),'missions':sum(e['type']=='mission_revealed' for e in g.events)}

def run(n):
 out={};t=time.time()
 for risk in [False,True]:
  c=Counter();samples=[]
  for i in range(n):
   x=play(1000+i,risk);c[x['winner']]+=1;c[x['reason']]+=1
   for k in ['risk_events','rises','proposals','missions']:c['total_'+k]+=x[k]
   if (i+1)%250==0:print('PROGRESS',risk,i+1,round(time.time()-t,1),flush=True)
  out['risk_enabled' if risk else 'old_no_risk']={'counts':dict(c),'n':n}
  print('RESULT',risk,json.dumps(out['risk_enabled' if risk else 'old_no_risk']),flush=True)
 with open('/mnt/data/avalon_v112_winrates.json','w') as f:json.dump(out,f,ensure_ascii=False,indent=2)
if __name__=='__main__':run(int(sys.argv[1]) if len(sys.argv)>1 else 100)
