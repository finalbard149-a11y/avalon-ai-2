"""Conservative per-match statement/action bridge.

Only a speaker's own explicit seat-directed claims enter their plan; no remote
player can force an NPC vote merely by naming a seat. No cross-match storage.
"""
from __future__ import annotations
import re

NEG=r'(?:不信任|不相信|不信|懷疑|質疑|反對|不能選|不要選|別帶|不想帶|排除)'
POS=r'(?:信任|相信|支持|看好|願意帶|想帶|選擇)'
SEAT=r'([1-7])\s*號'


def extract_positions(text, speaker):
    result={}
    for m in re.finditer(r'[^。！？\n，,；;]{0,38}', text):
        phrase=m.group(0).strip()
        if not phrase:continue
        for target in re.findall(SEAT,phrase):
            target=int(target)
            if target==speaker:continue
            # Require explicit personal attitude tied closely to the seat.
            before=phrase.split(f'{target}號')[0]
            after=phrase.split(f'{target}號',1)[-1]
            near=(before[-13:]+after[:13])
            if re.search(NEG,near):result[target]=-1
            elif re.search(POS,near) and not re.search(NEG,near):result[target]=1
    return result


def seat_preferences(view):
    return {int(s):int(x) for s,x in view.get('_declared_positions',{}).items()}
