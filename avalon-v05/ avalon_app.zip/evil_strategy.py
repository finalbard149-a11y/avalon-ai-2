"""Per-seat legal evil heuristics; no access to true Merlin/Percival seats.

Strategies are probabilistic signals, not character oracles. Public decisions are
resolved from the same structured action chosen by the referee.
"""
from __future__ import annotations
import hashlib


def signal(*parts: object) -> int:
    return int(hashlib.sha256(':'.join(map(str, parts)).encode()).hexdigest()[:8], 16) % 100


def early_ally_counterplay(view, team):
    """Assassin/Morgana sometimes oppose a named evil ally, without throwing fifth votes."""
    role=view['role']; public=view['public']; seat=view['seat']
    if role not in ('assassin', 'morgana') or public['mission']!=1 or public['attempt']==5:
        return None
    if seat not in team:
        return ('reject','首輪我沒進這隊，選人依據仍不夠清楚。','early_off_team_dissent')
    partners=sorted(set(view['evil_teammates'])-{seat})
    chosen=partners[signal('opponent',seat)%len(partners)]
    if chosen in team and signal('dissent',seat,public['attempt'],tuple(team)) < 65:
        return ('reject','雖然我進隊，但這個搭配還是讓我猶豫，想先聽其他組合。','early_ally_counterposition')
    return None


def morgana_mission_decision(view):
    if view['role']!='morgana':return None
    public=view['public']; team=set(public['proposal'] or ())
    teammates=set(view['evil_teammates'])-{view['seat']}
    partners=team.intersection(teammates)
    if public['mission']==4:
        if partners:
            return ('fail','第四次任務有隊友共同出場，需要至少兩張失敗牌。','fourth_mission_coordination')
        return ('success','第四次任務單獨一張失敗牌也無法破壞任務，選擇偽裝。','fourth_mission_solo_cover')
    if partners:
        return ('success','隊友也在隊內，由隊友負責破壞；我保留成功牌偽裝。','morgana_partner_cover')
    return ('fail','這隊只有我能破壞任務，選擇失敗牌。','morgana_solo_sabotage')


def ally_assassination_analysis(view):
    """Candidate scores accessible to any evil ally; four good seats remain anonymous.

    Estimate Percival as someone defending Morgana with unusually early public
    support only when Morgana has never joined missions and her proposals have
    exclusively named evil allies. This is a *weak* model assumption.
    """
    allies=set(view['evil_teammates'])
    candidates=[s for s in range(1,8) if s not in allies]
    events=view['public']['public_events']
    votes=[];proposal=None;missions=[];proposals=[]
    for e in events:
        p=e['payload']
        if e['type']=='proposal':proposal=p;proposals.append(p)
        elif e['type']=='votes_revealed' and proposal:votes.append((proposal,p['votes']))
        elif e['type']=='mission_revealed' and proposal:missions.append((set(proposal['team']),p))
    # Do not use Game.roles. The precise Morgana seat is not identified by
    # evil_teammates; infer it from the requesting role only when Morgana herself.
    suspected_percival={s:0.0 for s in candidates}
    if view['role']=='morgana':
        seat=view['seat']
        own_proposals=[p for p in proposals if p['captain']==seat]
        never_mission=all(seat not in t for t,_ in missions)
        all_evil_proposals=bool(own_proposals) and all(set(p['team'])<=allies for p in own_proposals)
        if never_mission and all_evil_proposals:
            for prop, ballots in votes:
                if prop['captain']==seat and set(prop['team'])<=allies:
                    for s in candidates:
                        if ballots.get(s,ballots.get(str(s)))=='yes':
                            suspected_percival[s]+=0.45
    # Loyal servants sometimes approve an evil-heavy team for ordinary public
    # reasons, so signals remain soft rather than marking a confirmed role.
    loyal={s:0.0 for s in candidates}
    merlin={s:0.0 for s in candidates}
    for prop,ballots in votes:
        t=set(prop['team']);has_evil=bool(t&allies)
        for s in candidates:
            b=ballots.get(s,ballots.get(str(s)))
            if b=='no' and has_evil:merlin[s]+=0.85 if prop['round']<=2 else 0.45
            if b=='yes' and not has_evil:merlin[s]+=0.6
            if b=='yes' and has_evil:loyal[s]+=0.35
            if b=='no' and not has_evil:loyal[s]+=0.15
    for p in proposals:
        captain=p['captain']
        if captain in merlin:
            if not set(p['team'])&allies:merlin[captain]+=0.75
            else:loyal[captain]+=0.25
    # Assassin vs ally alignment: among otherwise comparable good seats,
    # somebody who repeatedly opposes a named evil ally but accepts a team
    # with the assassin may be an ordinary loyalist rather than Merlin.
    if view['role']=='assassin':
        own=view['seat']
        for other in allies-{own}:
            rejects={s:0 for s in candidates};accepts={s:0 for s in candidates}
            for prop, ballots in votes:
                team=set(prop['team'])
                for s in candidates:
                    ballot=ballots.get(s,ballots.get(str(s)))
                    if other in team and ballot=='no':rejects[s]+=1
                    if own in team and other not in team and ballot=='yes':accepts[s]+=1
            for s in candidates:
                if rejects[s]>=2 and accepts[s]>=1:
                    loyal[s]+=0.55
    for s in candidates:
        merlin[s]-=0.65*suspected_percival[s]
        merlin[s]-=0.12*loyal[s]
    return {'merlin_likelihood':merlin,'percival_likelihood':suspected_percival,
            'loyal_likelihood':loyal,'candidates':candidates}
