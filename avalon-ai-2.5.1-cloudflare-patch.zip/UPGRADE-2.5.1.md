# Avalon AI 2.5.1 — Cloudflare Workers AI optional provider

This patch does not silently change NPC routes; existing six-model game settings remain unchanged until configured in Railway.

## Apply
`unzip -o avalon-ai-2.5.1-cloudflare-patch.zip && npm test && npm run check && git add src/providers.js src/quota.js public/index.html package.json test/cloudflare251.test.js test/multimodel23.test.js && git commit -m "Add Cloudflare Workers AI optional provider" && git push origin main`

## Railway environment variables
Set `CLOUDFLARE_API_TOKEN` (secret), `CLOUDFLARE_ACCOUNT_ID` (account identifier), and optionally `AVALON_CLOUDFLARE_DAILY_LIMIT=20` (internal number-of-requests safety cap, NOT Cloudflare Neuron cap).

After the patch is deployed and both variables exist, choose ONE route:
- First try a fallback: `AVALON_NPC_4_FALLBACK=cloudflare|@cf/zai-org/glm-4.7-flash` (4 will continue using Groq unless the primary request fails).
- Or direct route: `AVALON_NPC_4_PROVIDER=cloudflare` and `AVALON_NPC_4_MODEL=@cf/zai-org/glm-4.7-flash`.

Do not use both tests simultaneously until confirmed by logs. Secret key must be stored in Railway, never GitHub or chat. Users on Workers Paid may incur charges after free allocation is exhausted. Ensure Workers Free for strict no-fee use, and inspect dashboard Neurons.

Cloudflare official docs: https://developers.cloudflare.com/workers-ai/get-started/rest-api/ and https://developers.cloudflare.com/workers-ai/models/glm-4.7-flash/
