# Avalon AI 2.5 — 六模型競技場

## 更新方式

本 ZIP 以 2.4 已部署的版本為基底，不含 `node_modules`、資料庫或任何金鑰。將 ZIP 上傳 GitHub 專案根目錄，接著於 Codespaces 執行：

```bash
git pull --rebase origin main
unzip -o avalon-ai-2.5-patch.zip
npm test
npm run check
git add src public test package.json
git commit -m "Upgrade Avalon AI 2.5 six-model arena"
git push origin main
```

Railway 會依原設定由 GitHub 自動部署。版本升級**不會自動清除或重置現有遊戲**。

## 重要：先保留原本 Gemini 模式

初次部署先不要設定 `AVALON_SIX_MODEL_MODE`，網站仍使用原先已經能用的 Gemini。完成 Groq/OpenRouter 免費帳戶申請、核對帳號計費設定後，再在 `hospitable-trust → Variables` 填：

```
GROQ_API_KEY=你在 Groq 申請的金鑰
OPENROUTER_API_KEY=你在 OpenRouter 申請的金鑰
AVALON_SIX_MODEL_MODE=1
```

原 `GEMINI_API_KEY` 維持不變。三種金鑰不要貼到 GitHub、對話框、網頁前端或紀錄中。

六席預設配置如下：

| 座位 | Provider | 模型 |
|---|---|---|
| 1 | Gemini | `gemini-3.5-flash-lite` |
| 2 | Groq | `openai/gpt-oss-20b` |
| 4 | Groq | `llama-3.3-70b-versatile` |
| 5 | OpenRouter | `google/gemma-4-26b-a4b-it:free` |
| 6 | OpenRouter | `nvidia/nemotron-3-ultra-550b-a55b:free` |
| 7 | Groq | `qwen/qwen3.8-27b` |

每席可以使用 `AVALON_NPC_2_PROVIDER=groq` 和 `AVALON_NPC_2_MODEL=openai/gpt-oss-20b` 覆蓋預設，座位可選 1、2、4、5、6、7。改提供商時應同時改模型。模型可能停售、額度可能調整；若收到 404 請檢查當時供應商實際模型清單。

## 每日及每局額度

過去設定在 Railway 的 `AVALON_GAME_CALL_LIMIT=30` / `AVALON_DAILY_CALL_LIMIT=50` **不會被覆寫**。如有充足免費額度且希望一次玩完整局，可自行修改為：

```
AVALON_GAME_CALL_LIMIT=80
AVALON_DAILY_CALL_LIMIT=100
AVALON_NPC_CALL_LIMIT=16
AVALON_GEMINI_DAILY_LIMIT=30
AVALON_GROQ_DAILY_LIMIT=45
AVALON_OPENROUTER_DAILY_LIMIT=40
```

這些值是應用程式的請求次數上限，不是供應商保證的免費額度，也不是帳單硬上限。Google Gemini 專案需保持 Free Tier；Groq 帳戶依自身免費方案限制；OpenRouter 請使用 `:free` 並確認沒有充值或其他計費設定。OpenRouter 兩名 NPC 共用一組 OpenRouter 每日上限，並不等於每天各有 50 次。Gemini/Groq/ OpenRouter 不會因程式限制而保證絕對 US$0，Railway 另計。若未確認供應商免費額度，請保留舊有 30/50 較保守設定。

`AVALON_NPC_CALL_LIMIT` 每席每局上限。程式用 PostgreSQL 交易把每局、每日、每席及供應商每日上限一次保留；即使模型失敗也計入請求次數。原本已使用額度不會因部署而清零。模型請求只接收該座位合法視角，主持仍是非 AI 規則引擎。

## 備援（選用，不預設啟用）

例如：

```
AVALON_NPC_2_FALLBACK=groq|llama-3.3-70b-versatile
```

只在超額、找不到模型、網路逾時、空回應或無效 JSON 等可重試錯誤時嘗試。備援也需有金鑰、通過免費模型白名單，且每一次嘗試都占用額度。**沒有設定備援就停下報錯，不會暗中轉換供應商或付費模型。**

## 已知限制

- 原本對話的公開事件仍被保留，但部分早期的舊局 NPC 信念可能不完整。
- 這不是六個不同 AI 公司：是六種模型、三個 API 提供商。
- Groq 的 JSON 格式品質可能隨模型不同而有差異，仍需實機驗證。
- 該版不是完整賽局智慧品質保證；已確認的規則正確性仍須以實戰和稽核資料驗收。
