# Avalon AI 2.3 — 六模型可配置 NPC + 規則主持引擎

## 先看這段（重要）

本升級保留純 JavaScript 規則主持引擎 `src/core.js`，六名 NPC（1、2、4、5、6、7）可**各自**指定模型；目前支援 Gemini、Groq、OpenRouter 三種服務供應商的 API 格式，且每人可以指定不同的模型名稱。

**預設全部沿用已設定的 Gemini Key**，並不代表已經啟用六個不同模型。要六種模型同時運作，必須先在各供應商取得合法可用的 API Key 與模型 ID（免費方案需自行確認帳戶權限），再逐席設定。

不會默默切換到付費模型；OpenRouter 僅容許 `:free` 模型 ID。Groq 和 Gemini API Key 所屬帳戶仍須確認免費計費狀態，程式的每日／每局請求上限**不是帳單硬上限**。Railway 本身另計費。

## 安裝

1. 將 `avalon-ai-2.3-patch.zip` 上傳到 GitHub 儲存庫根目錄，並在 GitHub 完成提交。
2. 到 Codespaces 終端機執行：

```bash
git pull --rebase origin main
unzip -o avalon-ai-2.3-patch.zip
npm test
npm run check
git add src/agents.js src/providers.js src/server.js src/store.js src/quota.js public/index.html package.json test/
git commit -m "Upgrade Avalon AI 2.3 multi-model NPCs"
git push origin main
```

3. Railway 在 GitHub `main` 更新後通常會自動部署，確認最新 Deploy 為 Success/Active。原本 `DATABASE_URL`、`ADMIN_PASSWORD`、`SESSION_SECRET` 保留。
4. 原本已設定的 `GEMINI_API_KEY` 可繼續使用。不要提供 API Key 給其他人，尤其不要上傳 GitHub。

## 逐席配置（Railway → hospitable-trust → Variables）

以下示例用**六個不同的配置位置**，每一個位置都有自己的 provider 和 model，不代表這些模型一定在你的免費方案中可用。`AVALON_NPC_3_*` 不需要，因為 3 號是真人。

| NPC | Provider 變數 | Model 變數 |
|---|---|---|
| 1 | `AVALON_NPC_1_PROVIDER` | `AVALON_NPC_1_MODEL` |
| 2 | `AVALON_NPC_2_PROVIDER` | `AVALON_NPC_2_MODEL` |
| 4 | `AVALON_NPC_4_PROVIDER` | `AVALON_NPC_4_MODEL` |
| 5 | `AVALON_NPC_5_PROVIDER` | `AVALON_NPC_5_MODEL` |
| 6 | `AVALON_NPC_6_PROVIDER` | `AVALON_NPC_6_MODEL` |
| 7 | `AVALON_NPC_7_PROVIDER` | `AVALON_NPC_7_MODEL` |

`PROVIDER` 只接受 `gemini`、`groq` 或 `openrouter`。三種供應商分別讀取 `GEMINI_API_KEY`、`GROQ_API_KEY` 或 `OPENROUTER_API_KEY`。

例子（先試一位，不要一次改六位）：

```env
AVALON_NPC_2_PROVIDER=groq
AVALON_NPC_2_MODEL=openai/gpt-oss-20b
# 在 Railway 的 GROQ_API_KEY 填入你自己的密鑰（不要貼在這裡）
```

回退方式：刪除上面兩個 `AVALON_NPC_2_...` 變數，即會恢復使用共用的 `GEMINI_MODEL`，但只有 Gemini Key 真的可用時才會正常執行。

OpenRouter 模型必須選用後綴 `:free` 的當前可用端點，且仍受該供應商帳戶的免費請求限額；不允許自動選擇付費端點。

## 這次特別修的穩定性問題

- 玩家發言使用 `/api/speak` **先提交資料庫**，不再和 Gemini 回應綁在同一次交易。
- AI 回應使用 `/api/respond` 一名 NPC 一次獨立提交；一名 NPC 失敗不會刪除玩家發言或前一名已成功的回覆。
- 當 JSON 格式無效或 API 超額時，保留尚未回應的 NPC 佇列，畫面顯示錯誤，可按「聽取／重試 NPC 回應」。
- 各模型只能讀取 `perspective(g, seat)` 的合法資訊，不傳完整身分表。
- 新局建立不強制呼叫模型，避免 API 故障造成無法放棄舊局；需要聽取開場發言時按「聽取／重試 NPC 回應」。
- 每局模型請求數在 PostgreSQL 獨立持久化記錄，包括失敗請求（不因遊戲交易 rollback 而歸零）。

## 主要限制

- 每名 NPC **可使用不同模型**，但目前沒有六個模型的真實供應商端對端測試；已通過的是本機格式、隔離與路由測試。
- 投票六名 NPC 仍可能花六次呼叫，30 次／局未必夠完整一局。2.3 不會改成付費模型或悄悄改為離線 AI。
- 如果選了一個沒有 API Key 的供應商，該 NPC 會明確報錯；不要在 Railway 放入明文範例密鑰。
- Google、Groq、OpenRouter 的配額、模型名稱、費用與可用性可能改變，先在各自控制台確認再切換。
- 模型可根據自己資訊推理，但演算法與提示詞測試不能證明所有模型絕不說出不該說的資訊，仍需進行實局審計。
