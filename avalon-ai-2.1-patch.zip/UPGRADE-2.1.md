# Avalon AI 2.1 — Interactive Debate (2026-11-11)

這個版本在已上線的 2.0 Recovery Patch 基礎上升級；**目前只是可部署更新包，不代表已替你部署到 Railway。**

## 功能

- 常駐公開議事廳：無論隊長是誰，真人都可在 DISCUSSION、VOTING、MISSION 發言。結算／刺殺期間公開對話停止，保護隱藏資訊。
- 真人發言後，依發言內容選擇一名被點名的 NPC（例如「2號」），並由另一名 NPC 參與對話。每名 NPC 獨立決策、保存可稽核紀錄。
- NPC 擔任隊長時，先留出討論時間。真人按「請隊長提出隊伍」才進入投票，避免跳過討論。
- 所有七張隊伍選票計完後，先顯示投票詳情，真人確認後才執行任務；任務結算也會先顯示結果。
- 取消任何偷偷自動跳過重要公共結算的流程。老局可沿用 2.0 的「繼續卡住的對局」。
- 修復原有登入錯誤殘留問題並保留管理員重置。
- 20 項 Node.js 自動測試通過，另外完成一輪本地 HTTP 流程測試。

## 特別重要：雲端 AI 與離線測試的差異

**尚未設置 `AVALON_AI_API_KEY` 時**，NPC 的回話只是因人而異的有限模板，並不具有真正的語意推理能力。網站會明確標示「離線測試 NPC」。若要讓 NPC 實際分析公開發言並回答，需要在 Railway 後端服務 Variables 裡設定 `AVALON_AI_API_KEY`，並確保 API 帳號有用量額度；ChatGPT 會員訂閱不包含 API 用量。API 金鑰僅放 Railway，絕不可放 GitHub 或傳給助理。

## iPhone / Codespaces 更新法

1. 將 `avalon-ai-2.1-patch.zip` 當成**單一檔案**上傳到 GitHub 私人儲存庫 `avalon-ai-2` 根目錄，完成 Commit。
2. 回到 Codespaces 終端機，依序執行：

```bash
git pull --rebase origin main
unzip -o avalon-ai-2.1-patch.zip
npm test
git add src/server.js src/core.js src/agents.js public/index.html test package.json
git commit -m "Upgrade Avalon AI 2.1 interactive debate"
git push origin main
```

3. 在 Railway 核對新部署的版本與 Online 狀態後，開啟原 HTTPS 遊戲網址。
4. 先用未結束的舊局測試「指定 NPC 發言」；如遇狀態衝突可按「繼續卡住的對局」，但一般不需按它。若想測試第一輪的新流程，可在確認後選擇「放棄舊局並開始新局」。
5. 測試：隊長 1 號時先向 2 號發問→檢查至少一名 NPC 回應→按請隊長提案→投票前繼續討論→投票→檢查七人投票結果畫面→確認後任務出牌→確認任務結果畫面。

## 改版涉及的檔案

- `src/core.js` — 支援跨階段公開發言（刺殺與遊戲結束除外）
- `src/server.js` — 兩位 NPC 對話、提案控制、投票／任務結算確認
- `src/agents.js` — 依發言情境的模板與雲端 AI 提示詞
- `public/index.html` — 常駐議事廳、操作按鈕與結果確認畫面
- `test/debate21.test.js` — 新增 8 項發言／保密／階段控制相關檢查
- `test/recovery-source.test.js` — 舊版測試更新為兼容變數改名
- `package.json` — 版本 2.1.0-beta.1

## 限制

- 仍是獨立單一管理員、1 真人＋6 NPC。未提供多人真人同時連線。
- 玩家一旦按下投票，後端 NPC 會完成投票後展示結果，不提供「玩家已投票但尚未揭曉」的長時間停留；玩家應在投票前充分討論。
- 任務出牌自動化，只有參與任務的真人需選牌。
- AI 模型失敗時回退離線簡化策略，請到賽後稽核看來源。AI 的策略品質沒有勝率保證。
- 不包含不受竄改的第三方稽核、正式資安滲透測試，也尚未實測 Railway 2.1 正式環境。
- 未更動資料庫 schema；舊局可在升級後恢復，但可能已有無法補回的過去討論歷史。
