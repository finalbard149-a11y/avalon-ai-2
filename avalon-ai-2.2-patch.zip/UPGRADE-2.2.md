# Avalon AI 2.2 · Gemini 免費模型優先版

## 這個版本的範圍

- 將 NPC 雲端推理從原本 OpenAI API 格式改成 **Google Gemini 原生 REST API**。
- 僅允許 `gemini-2.5-flash` / `gemini-2.5-flash-lite` 兩個模型名稱；不會自動改用付費服務或其他模型。
- 後端只傳送單一 NPC 的 `perspective()` 結果，而非完整角色表。
- 每局預設 30 次模型請求、每日（UTC）預設 50 次請求；使用 PostgreSQL 原子計數保留每日用量，重啟後仍存在。
- 每次請求前預先扣次數；失敗也計入用量（保守防超額）。
- 超額、Google API 驗證失敗或回傳格式錯誤會明確提示，**不會靜默切回離線 NPC**。
- 介面顯示本局 AI 呼叫次數 / 上限。原 2.1 互動議事廳保留。

## 這不是供應商帳單硬上限

即使程式限制呼叫次數，**仍不能保證 Google 費用絕對為零**：
若 API Key 所屬 Google Cloud 專案啟用了付費計費，Google 會依該帳戶與供應商計費規則收費。要維持 US$0，必須在 Google AI Studio 確認此 API Key 所在專案是 **Free Tier 且未連結付費計費**。請勿以程式控制取代供應商層級的付款限制。
Railway 的資料庫與伺服器費用亦不包含在模型免費額度中。

## 部署（iPhone / Codespaces）

1. 將 `avalon-ai-2.2-patch.zip` 上傳至私人 GitHub 專案 `avalon-ai-2` 的根目錄並提交。
2. 在 Codespaces 終端機執行：

```bash
git pull --rebase origin main
unzip -o avalon-ai-2.2-patch.zip
npm test
npm run check
git add src/agents.js src/quota.js src/store.js src/server.js public/index.html test/gemini22.test.js package.json
git commit -m "Add Gemini AI and durable free-tier quotas"
git push origin main
```

3. 到 Railway `avalon-ai-2` → `hospitable-trust` → `Variables` 新增：
   - `GEMINI_API_KEY`：你自己建立的 Google AI Studio API Key。
   - `GEMINI_MODEL`：`gemini-2.5-flash`（選填，預設如此）；或改成 `gemini-2.5-flash-lite`。
   - `AVALON_GAME_CALL_LIMIT`：`30`（選填）。
   - `AVALON_DAILY_CALL_LIMIT`：`50`（選填，UTC 日界）。
4. 保留原有 `ADMIN_PASSWORD`、`SESSION_SECRET`、`DATABASE_URL`；**不要**把 API Key 放入 GitHub。
5. 等 Railway 自動部署成功後，重新登入網站。應顯示 `☁ Gemini AI` 而不是 `離線測試 NPC`。
6. 先在非機密測試局發問，例如「2 號，為何你不保留上一局成功隊員？」；查看回應是否具體引用事件。遇到 `GEMINI_QUOTA` / `GEMINI_AUTH` 先停止，不必重複按。

## 尚未做的事情

- 目前未連結你的私人 Google Key，也未在 Railway 實際呼叫 Gemini，因此**沒有真實 API 成功的端到端驗收**。
- 對模型品質、刺客推理的實際表現尚未做系統性盲測。
- 每日額度以 UTC 計算；若使用多個不同資料庫或多個 Google 專案，必須個別稽核。
- 現有架構只支援單一遊戲、單一真人玩家，非完整多人 SaaS。
